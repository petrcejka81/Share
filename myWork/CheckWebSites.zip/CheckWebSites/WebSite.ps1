<#PSScriptInfo

.VERSION 1.0.2.5

.GUID d29b0182-294a-4ce4-82bf-b04139fcff02

.AUTHOR petr_cejka@kb.cz; a5320net@ds.kb.cz

.COMPANYNAME KB, a.s. - .NET MWS Team

.COPYRIGHT

.TAGS

.LICENSEURI

.PROJECTURI

.ICONURI

.EXTERNALMODULEDEPENDENCIES 

.REQUIREDSCRIPTS

.EXTERNALSCRIPTDEPENDENCIES

.RELEASENOTES


.PRIVATEDATA

#>
#Requires -Module pnp.powershell
#Requires -PSEdition Core 
<# 

.DESCRIPTION 
 This is The Script :)
  
#>

Param(
        # Log folder
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [string]$logFolderRootPath = "R:\LogFiles\NETMWS\Monitoring\Tasks\Monitoring\CheckWebSite",
        # Log Name
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [ValidatePattern('^[\w,\s-]+\.[A-Za-z]{3}$')]
        [string]$logFileName = "WebSite.log",
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        #For Sharepoint connection
        [string]$ProxyURL = "http://wproxy.kb.cz:8080",
        #For probe check
        [switch]$Proxy,
        #Sharepoint Variables:
        #Password hash path
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [ValidateScript({Test-Path -Path $_})]
        [string]$SharePointHashPassPath = "D:\App\NETMWS\Monitoring\Tasks\JobsData\xx_netmws_sposync.hash",
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [ValidatePattern('(^.*)@(.*)')]
        [string]$SharePointUserAccountName = "xx_netmws_sposync@ds.kb.cz",
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [ValidatePattern('https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)')]
        [string]$SharePointSiteURL = "https://sgcz.sharepoint.com/sites/mww/",
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [string]$SharePointWebSiteListName = "WebSite",
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [string]$SharePointWebSiteListURL= "Lists/WebSite",
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [string]$SharePointwebAppListName = "WebApp",
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [string]$SharePointWebAppListURL="Lists/WebApp",
        #Default Email Address
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [ValidatePattern('^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$')]
        [string]$DefaultEmail="netmwssp@ds.kb.cz",
        #[string]$DefaultEmail="petr_cejka@kb.cz",
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [string]$SmtpServer="smtpint.ds.kb.cz",
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [ValidateSet("NoListTemplate", "GenericList", "DocumentLibrary", "Survey", "Links", "Announcements", "Contacts", "Events", "Tasks", "DiscussionBoard", "PictureLibrary", "DataSources", "WebTemplateCatalog", "UserInformation", "WebPartCatalog", "ListTemplateCatalog", "XMLForm", "MasterPageCatalog", "NoCodeWorkflows", "WorkflowProcess", "WebPageLibrary", "CustomGrid", "SolutionCatalog", "NoCodePublic", "ThemeCatalog", "DesignCatalog", "AppDataCatalog", "AppFilesCatalog", "DataConnectionLibrary", "WorkflowHistory", "GanttTasks", "HelpLibrary", "AccessRequest", "PromotedLinks", "TasksWithTimelineAndHierarchy", "MaintenanceLogs", "Meetings", "Agenda", "MeetingUser", "Decision", "MeetingObjective", "TextBox", "ThingsToBring", "HomePageLibrary", "Posts", "Comments", "Categories", "Facility", "Whereabouts", "CallTrack", "Circulation", "Timecard", "Holidays", "IMEDic", "ExternalList", "MySiteDocumentLibrary", "IssueTracking", "AdminTasks", "HealthRules", "HealthReports", "DeveloperSiteDraftApps", "ContentCenterModelLibrary", "ContentCenterPrimeLibrary", "ContentCenterSampleLibrary", "AccessApp", "AlchemyMobileForm", "AlchemyApprovalWorkflow", "SharingLinks", "HashtagStore", "RecipesTable", "FormulasTable", "WebTemplateExtensionsList", "ItemReferenceCollection", "ItemReferenceReference", "ItemReferenceReferenceCollection", "InvalidType")]
        [string]$SharePointTemplate="GenericList",
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [int32]$ThrottleLimit = 10,
        # Action
        #monitor = check website error
        #update = update sharepoint lists
        [ValidateSet("monitor", "update")]
        [string]$Action,
        [switch]$Skip_Deserialize
    )

#Global Config
$ErrorActionPreference = "Stop"
#MyLogclass
try 
{
    Enum Severity
    {
        Error
        Information
        Warning
    }
    class Log 
    {
        [string]$logFolderPath
        [string]$logFileName
        Log([string]$logFolderPath,[string]$logFileName)
        {
            $this.logFileName = $logFileName
            $this.logFolderPath = $logFolderPath
            try
            {
                if(!(Test-Path -Path $this.logFolderPath))
                {
                    New-item -Path $this.logFolderPath -ItemType Directory
                }
                if(!(Test-Path -Path "$($this.logFolderPath)\$([datetime]::now.ToString("yyyy_MM_dd"))_$($this.LogFilename)"))
                {
                    New-Item -Path "$($this.logFolderPath)\$([datetime]::now.ToString("yyyy_MM_dd"))_$($this.LogFilename)" -ItemType File 
                } 
            }
            catch
            {
                Throw "This is an error class Log. $_"
            }
        }
        WriteLog([String]$message,[severity]$severity)
        {
            Add-Content -Path "$($this.logFolderPath)\$([datetime]::now.ToString("yyyy_MM_dd"))_$($this.LogFilename)" -Value ([string]::Format("{0};[{1}];[{2}];{3}",[datetime]::Now.ToString("dd.MM.yyyy HH:mm:ss"), [System.Security.Principal.WindowsIdentity]::GetCurrent().Name,$severity,$message))
            switch ($severity) {
                "error" {Write-Error "$([string]::Format("{0};[{1}];[{2}];{3}",[datetime]::Now.ToString("dd.MM.yyyy HH:mm:ss"), [System.Security.Principal.WindowsIdentity]::GetCurrent().Name,$severity,$message))"}
                "warning" {Write-Warning "$([string]::Format("{0};[{1}];[{2}];{3}",[datetime]::Now.ToString("dd.MM.yyyy HH:mm:ss"), [System.Security.Principal.WindowsIdentity]::GetCurrent().Name,$severity,$message))"}
                Default {[System.Console]::WriteLine("$([string]::Format("{0};[{1}];[{2}];{3}",[datetime]::Now.ToString("dd.MM.yyyy HH:mm:ss"), [System.Security.Principal.WindowsIdentity]::GetCurrent().Name,$severity,$message))")}
            }
        }
        WriteLog([String]$message)
        {
            Add-Content -Path "$($this.logFolderPath)\$([datetime]::now.ToString("yyyy_MM_dd"))_$($this.LogFilename)" -Value $message
            [System.Console]::WriteLine("$message")
        }
        WriteLog([String]$message,[severity]$severity,[string]$server)
        {
            Add-Content -Path "$($this.logFolderPath)\$([datetime]::now.ToString("yyyy_MM_dd"))_$($this.LogFilename)" -Value ([string]::Format("{0};[{1}];[{2}];{4};{3}",[datetime]::Now.ToString("dd.MM.yyyy HH:mm:ss"), [System.Security.Principal.WindowsIdentity]::GetCurrent().Name,$severity,$message,$server))
            switch ($severity) {
                "error" {Write-Error "$([string]::Format("{0};[{1}];[{2}];{4};{3}",[datetime]::Now.ToString("dd.MM.yyyy HH:mm:ss"), [System.Security.Principal.WindowsIdentity]::GetCurrent().Name,$severity,$message,$server))" }
                "warning" {Write-Warning "$([string]::Format("{0};[{1}];[{2}];{4};{3}",[datetime]::Now.ToString("dd.MM.yyyy HH:mm:ss"), [System.Security.Principal.WindowsIdentity]::GetCurrent().Name,$severity,$message,$server))"}
                Default {[System.Console]::WriteLine("$([string]::Format("{0};[{1}];[{2}];{4};{3}",[datetime]::Now.ToString("dd.MM.yyyy HH:mm:ss"), [System.Security.Principal.WindowsIdentity]::GetCurrent().Name,$severity,$message,$server))")}
            }
        }
    }
    $log = [log]::new($logFolderRootPath,$LogFileName)
    $log.WriteLog("Start processing CheckWebApp scipt!",[severity]::Information) 
    $log.WriteLog("Loging class instance LOG was set successfully!",[severity]::Information) 
}
catch 
{
    throw 
}
#My class
try 
{
    class ErrorMessage
    {
        ErrorMessage([string]$message,[Severity]$severity,[string]$node)
        {
            $this.Node = $node
            $this.Message = $message
            $this.Severity = $severity
            $this.Message = $message
    
        }
        [string]$Node
        [string]$Message
        [severity]$Severity
        [Int16]$Farm_ID
        [string]WriteLine()
        {
            return "<strong $(if($this.Severity -eq "Error"){"id='Red'"}elseif($this.Severity -eq "Warning"){"id='Orange'"})>[$($this.Severity)]</strong>;[$($this.Node)]:$($this.Message)<br>"
        }
    }
    class Probe_Sharepoint
    {
        [string]$Uri
        [string]$ServerName
        [Int32]$ID
    }
    class Probe:Probe_Sharepoint
    {
        [string]$State
        [string]$SiteName
        [log]$log
        [Int16]$Farm_ID
        Probe([string]$serverName,[string]$siteName,[string]$uri, [log]$log,[Int16]$farm_ID)
        {
            $this.ServerName = $serverName
            $this.SiteName = $siteName
            $this.Uri = $uri
            $this.Log = $log
            $this.Farm_ID = $farm_ID
        }
        [void]GetProbeState([string]$proxy)
        {
            try 
            {
                if((Invoke-WebRequest -Uri $this.Uri -SkipCertificateCheck -Proxy $proxy -ProxyUseDefaultCredentials).StatusCode -eq 200)
                {
                    $this.State = "UP"
                    $this.log.writelog("Uri: '$($this.Uri)' is online",[severity]::Information)
                }else
                {
                    $this.log.writelog("Uri: '$($this.Uri)' is offline",[severity]::Information)
                    $this.State = "DOWN"
                }
            }
            catch 
            {
                $this.log.writelog("Uri: '$($this.Uri)' is offline",[severity]::Information)
                $this.State = "DOWN"
                $this.log.WriteLog("$($_.Exception.Message)",[severity]::Warning)
            }
        }
        [void]GetProbeState()
        {
            try 
            {
                if((Invoke-WebRequest -Uri $this.Uri -SkipCertificateCheck).StatusCode -eq 200)
                {
                    $this.State = "UP"
                    $this.log.writelog("Uri: '$($this.Uri)' is online",[severity]::Information)
                }else
                {
                    $this.log.writelog("Uri: '$($this.Uri)' is offline",[severity]::Information)
                    $this.State = "DOWN"
                }
            }
            catch 
            {
                $this.log.writelog("Uri: '$($this.Uri)' is offline",[severity]::Information)
                $this.State = "DOWN"
                $this.log.WriteLog("$($_.Exception.Message)",[severity]::Warning)
            }
        }
    }
    class WebSite_Sharepoint
    {
        [string]$Title
        $Server = [System.Collections.Generic.List[pscustomobject]]::new()
        [string[]]$Probe
        $Application = [System.Collections.Generic.List[pscustomobject]]::new()
        [string]$Mode
        [string]$Status
        [string]$Date
        [string[]]$Email
        [Int32]$ID
    }
    class WebSite_Item_Sharepoint
    {
        [string]$Name
        [string]$LookupId
    }
    class WebApp_Sharepoint
    {
        [string]$Title
        $Server = [System.Collections.Generic.List[pscustomobject]]::new()
        [string[]]$VirtualDirectory
        [pscustomobject]$WebSite
        [string]$Status
        [string]$Date
        [string[]]$Email
        [Int32]$ID
    }
    class Server_Sharepoint
    {
        [string]$Name
        [String]$Title
        [bool]$CheckCertificate
        [bool]$CheckEventLog
        [bool]$CheckHDD
        [bool]$CheckIISSite
        [bool]$CheckLocalGroup
        [bool]$CheckMSMQ
        [bool]$CheckProbeFile
        [bool]$CheckService
        [bool]$CheckScheduledTask
        [bool]$CheckUptime
        [int32]$ID
        [string]$Maintenance
        [datetime]$StartTime
        [datetime]$StopTime
    }
    class Collection
    {
        [log]$Log
        [int32]$ThrottleLimit
        $IISWebSite = [System.Collections.Generic.List[System.Object]]::new()
        $WebSite_Sharepoint = [System.Collections.Generic.List[WebSite_Sharepoint]]::new()
        $WebApp_Sharepoint = [System.Collections.Generic.List[WebApp_Sharepoint]]::new()
        $Probe_Sharepoint = [System.Collections.Generic.List[Probe_Sharepoint]]::new()
        $Server_Sharepoint = [System.Collections.Generic.List[Server_Sharepoint]]::new()
        $Server_Sharepoint_Maintenance = [System.Collections.Generic.List[Server_Sharepoint]]::new()
        [bool]$Proxy
        [string]$ProxyURL
        Collection([log]$log,[bool]$proxy,[string]$proxyURL,[int32]$throttleLimit)
        {
            try 
            {
                $this.Log = $log
                $this.ThrottleLimit = $throttleLimit
                if(!(Test-Path -Path "$(Get-Location)\Serialize\"))
                {
                    New-Item -Path "$(Get-Location)\Serialize\" -ItemType Directory -Force
                }
                $this.ProxyURL = $proxyURL
                $this.Proxy = $proxy
            }
            catch {
                $log.WriteLog("$_ ",[severity]::Error)
            }
        }
        [void]ConnectToSharepoint([System.Management.Automation.PSCredential]$sharedPointCredential,[string]$SharePointSiteURL)
        {
            try 
            {
                #Proxy
                [System.Net.Http.HttpClient]::DefaultProxy = New-Object System.Net.WebProxy($this.proxyURL)
                [System.Net.Http.HttpClient]::DefaultProxy.Credentials = [System.Net.CredentialCache]::DefaultCredentials 
                [System.Net.Http.HttpClient]::DefaultProxy.BypassProxyOnLocal = $true
                
                $this.log.WriteLog("Connecting to $SharePointSiteURL ...",[severity]::Information)
                Connect-PnPOnline -Url $SharePointSiteURL -Credentials $sharedPointCredential -ClientId "915c0d7a-6a91-4b5a-91b5-8b1a7576e58f"
                $this.log.WriteLog("Connection established",[severity]::Information)
            }
            catch 
            {
                $this.log.WriteLog("ConnectToSharepoint:$($_.Exception.Message)",[severity]::Error)
            }
        }
        [string]GetServerID([string]$serverName)
        {
            return ($this.Server_Sharepoint | Where-Object {$serverName -eq $_.Name}).ID
        }
        [string]GetWebSiteID([string]$siteName)
        {
            return ($this.WebSite_Sharepoint | Where-Object {$siteName -eq $_.Title}).ID
        }
        [string]GetProbeID([string]$probeUri)
        {
            return ($this.Probe_Sharepoint | Where-Object {$probeUri -eq $_.uri}).ID
        }
        [void]GetRemoteData()
        {
            try 
            {
                $this.IISWebSite = [System.Collections.Generic.List[System.Object]]::new()
                $this.Server_Sharepoint | Foreach-Object -ThrottleLimit $this.ThrottleLimit -Parallel {
                    #Action that will run in Parallel. Reference the current object via $PSItem and bring in outside variables with $USING:varname
                    Enum Severity
                    {
                        Error
                        Information
                        Warning
                    }
                    $ErrorActionPreference = "Stop"
                    $Farm_Title = $PSItem.Title
                    ($using:this.log).writelog("Start to collect remote data!",[severity]::Information,$($PSItem.Name))
                    try 
                    {
                        Invoke-Command -ComputerName $PSItem.Name -ScriptBlock {
                            $ErrorActionPreference = "Stop"
                            #My Remote Class
                            class Site
                            {
                                [String]$SiteName
                                [String]$SiteStatus
                                [string]$Env
                                [Int16]$Farm_ID
                                [string]$Farm_Title
                                $Email =[System.Collections.Generic.List[System.Object]]::new()
                                $Probe =[System.Collections.Generic.List[System.Object]]::new()
                                $ListWebApp = [System.Collections.Generic.List[System.Object]]::new()
                                $ErrorMessage = [System.Collections.Generic.List[System.Object]]::new()
                            }
                            try 
                            {
                                Get-IISSite | ForEach-Object {
                                    $Site = [Site]::new()
                                    $Site.SiteName = $_.name
                                    $Site.SiteStatus = $_.State
                                    $Site.Env = if((Get-CimInstance -ClassName "Win32_ComputerSystem" -ErrorAction Stop).Domain -eq "dslab.kb.cz"){"TEST"}else{"PROD"}
                                    $_.Applications | Foreach-Object {
                                        $obj = [psobject]::new()
                                        # Add properties to the PSObject
                                        $obj | Add-Member -MemberType NoteProperty -Name 'Path' -Value $_.Path
                                        $obj | Add-Member -MemberType NoteProperty -Name 'VirtualDirectories' -Value ($_.VirtualDirectories | ForEach-Object {$_.PhysicalPath})
                                        $obj | Add-Member -MemberType NoteProperty -Name 'ApplicationPoolName' -Value $_.ApplicationPoolName
                                        $obj | Add-Member -MemberType NoteProperty -Name 'ApplicationPoolState' -Value (Get-IISAppPool -Name $_.ApplicationPoolName -ErrorAction Stop).State
                                        $obj | Add-Member -MemberType NoteProperty -Name 'WebApp_ID' -value ([int]::Empty)
                                        return $obj
                                    } | ForEach-Object {$Site.ListWebApp.Add($_)}
                                    return $Site
                                }
                            }
                            catch [System.Management.Automation.CommandNotFoundException]
                            {
                                continue
                            }
                            catch 
                            {
                                throw
                            }
                        } | ForEach-Object {
                            $_.Farm_Title =  $Farm_Title
                            ($using:this.IISWebSite).Add($_)}
                        ($using:this.log).writelog("Remote data successfuly finished!",[severity]::Information,$($PSItem.Name))
                    }
                    catch {
                        ($using:this.log).writelog("Get remote data: $($_.Exception.Message)",[severity]::Warning,$($PSItem.Name))
                    }
                }
            }
            catch [System.Management.Automation.ActionPreferenceStopException]
            {
                $this.log.WriteLog("GetRemoteData:$($_.Exception.Message)",[severity]::Warning)
            }
            catch 
            {
                $this.log.WriteLog("GetRemoteData:$($_.Exception.Message)",[severity]::Error)
            }
        }
        [void]ExportToSharepoint_NewWebSiteList([System.Management.Automation.PSCredential]$sharedPointCredential,[string]$SharePointSiteURL,[string]$SharePointWebSiteListName,[string]$SharePointWebSiteListURL,[string]$SharePointTemplate,$sharePoint_FieldSettings_RadioButtons,[string]$SharePointWebAppListName)
        {
            try 
            {
                $this.ConnectToSharepoint($sharedPointCredential,$SharePointSiteURL)
                $this.log.WriteLog("ExportToSharepoint: START",[severity]::Information)
                if(!(Get-PnPList | Where-Object {$_.Title -eq $SharePointWebSiteListName}))
                {
                    New-PnPList -Title $SharePointWebSiteListName -Url $SharePointWebSiteListURL -Template $SharePointTemplate
                    Set-PnPField -List $SharePointWebSiteListName -Identity "Title" -Values @{   Title="Name"
                                                                                                Description="Name of web website"} 
                    Add-PnPField -List $SharePointWebSiteListName -Type Lookup -DisplayName "Server" -InternalName "Server" -AddToDefaultView
                    Set-PnPField -List $SharePointWebSiteListName -Identity "Server" -Values @{ LookupList=(Get-PnPList "Servers").Id.ToString() 
                                                                                                AllowMultipleValues = $true
                                                                                                LookupField="Server"}
                    Add-PnPField -List $SharePointWebSiteListName -Type Lookup -DisplayName "Probe" -InternalName "Probe" -AddToDefaultView
                    Set-PnPField -List $SharePointWebSiteListName -Identity "Probe" -Values @{  LookupList=(Get-PnPList "Check Probe File").Id.ToString() 
                                                                                                AllowMultipleValues = $true
                                                                                                LookupField="Title"}
                    Add-PnPField -List $SharePointWebSiteListName -Type Lookup -DisplayName "Application" -InternalName "Application" -AddToDefaultView
                    Set-PnPField -List $SharePointWebSiteListName -Identity "Application" -Values @{  LookupList=(Get-PnPList "WebApp").Id.ToString() 
                                                                                                AllowMultipleValues = $true
                                                                                                LookupField="Title"}
                    Add-PnPField -List $SharePointWebSiteListName -Type Choice -DisplayName "Env" -InternalName "Env" -AddToDefaultView -Choices "TEST", "PROD"
                    Add-PnPField -List $SharePointWebSiteListName -Type Choice -DisplayName "Mode" -InternalName "Mode" -AddToDefaultView -Choices "Single", "Multi"
                    Add-PnPField -List $SharePointWebSiteListName -Type Choice -DisplayName "Status" -InternalName "Status" -AddToDefaultView -Choices "Active", "Maintenance", "Disable", "New"
                    Set-PnPField -List $SharePointWebSiteListName -Identity "Status" -Values @{ DefaultValue = "New"
                                                                                                EditFormat=$sharePoint_FieldSettings_RadioButtons}
                    Add-PnPField -list $SharePointWebSiteListName -Type DateTime -DisplayName "Date" -InternalName "Date" -AddToDefaultView
                    Add-PnPField -list $SharePointWebSiteListName -Type User -DisplayName "Email" -InternalName "Email" -AddToDefaultView
                    Set-PnPField -List $SharePointWebSiteListName -Identity "Email" -Values @{AllowMultipleValues = $true}
                    $this.log.WriteLog("New list: $SharePointWebSiteListName was created",[severity]::Information)
                    if(Get-PnPList | Where-Object {$_.Title -eq $SharePointWebAppListName})
                    {
                        Add-PnPField -List $SharePointWebAppListName -Type Lookup -DisplayName $SharePointWebSiteListName -InternalName $SharePointWebSiteListName -AddToDefaultView
                        Set-PnPField -List $SharePointWebAppListName -Identity $SharePointWebSiteListName -Values @{  LookupList=(Get-PnPList $SharePointWebSiteListName).Id.ToString() 
                                                                                                AllowMultipleValues = $true
                                                                                                LookupField="Title"}
                    }
                }
            }
            catch {
                $this.log.WriteLog("$($_.Exception.Message)",[severity]::Error)
            }
            finally {
                Disconnect-PnPOnline 
                $this.log.writelog("Disconnected from $SharePointSiteURL",[severity]::Information)
            }
    
        }
        [void]ExportToSharepoint_NewWebAppList([System.Management.Automation.PSCredential]$sharedPointCredential,[string]$SharePointSiteURL,[string]$SharePointWebAppListName,[string]$SharePointWebAppListURL,[string]$SharePointTemplate,$sharePoint_FieldSettings_RadioButtons)
        {
            try 
            {
                $this.ConnectToSharepoint($sharedPointCredential,$SharePointSiteURL )
                $this.log.WriteLog("ExportToSharepoint: START",[severity]::Information)
                if(!(Get-PnPList | Where-Object {$_.Title -eq $SharePointWebAppListName}))
                {
                    New-PnPList -Title $SharePointWebAppListName -Url $SharePointWebAppListURL -Template $SharePointTemplate
                    Set-PnPField -List $SharePointWebAppListName -Identity "Title" -Values @{   Title="Name"
                                                                                                Description="<WebSiteName/WebAppPath>"}                
                    Add-PnPField -List $SharePointWebAppListName -Type Lookup -DisplayName "Server" -InternalName "Server" -AddToDefaultView
                    Set-PnPField -List $SharePointWebAppListName -Identity "Server" -Values @{  LookupList=(Get-PnPList "Servers").Id.ToString() 
                                                                                                AllowMultipleValues = $true
                                                                                                LookupField="Server"}
                    Add-PnPField -List $SharePointWebAppListName -Type Note -DisplayName "VirtualDirectory" -InternalName "VirtualDirectory" -AddToDefaultView
                    
                    Add-PnPField -List $SharePointWebAppListName -Type Text -DisplayName "Pool" -InternalName "Pool" -AddToDefaultView
                    Add-PnPField -List $SharePointWebAppListName -Type Choice -DisplayName "Env" -InternalName "Env" -AddToDefaultView -Choices "TEST", "PROD"
                    Add-PnPField -List $SharePointWebAppListName -Type Choice -DisplayName "Status" -InternalName "Status" -AddToDefaultView -Choices "Active", "Maintenance", "Disable"
                    Set-PnPField -List $SharePointWebAppListName -Identity "Status" -Values @{  DefaultValue = "Active"
                                                                                                EditFormat= $sharePoint_FieldSettings_RadioButtons}
                    Add-PnPField -list $SharePointWebAppListName -Type DateTime -DisplayName "Date" -InternalName "Date" -AddToDefaultView
                    $this.log.WriteLog("New list: $SharePointWebAppListName was created",[severity]::Information)
                }
            }
            catch {
                $this.log.WriteLog("$($_.Exception.Message)",[severity]::Error)
            }
            finally {
                Disconnect-PnPOnline 
                $this.log.writelog("Disconnected from $SharePointSiteURL",[severity]::Information)
            }
    
        }
        [void]ExportToSharepoint_Data([System.Management.Automation.PSCredential]$sharedPointCredential,[string]$SharePointSiteURL,[string]$SharePointWebSiteListName,[string]$SharePointWebAppListName)
        {
            try 
            {
                $this.ConnectToSharepoint($sharedPointCredential,$SharePointSiteURL )
                $this.log.WriteLog("EportToSharepoint_DATA: START",[severity]::Information)
                
                $this.IISWebSite | Group-Object -Property SiteName, Farm_Title | ForEach-Object {
                    $appItem_Add = [System.Collections.Generic.List[WebApp_Sharepoint]]::new()
                    $appItem_Update = [System.Collections.Generic.List[WebApp_Sharepoint]]::new()
                    $_.Group | ForEach-Object {
                        $siteName = $_.SiteName
                        $ServerID = $this.GetServerID($_.PSComputerName)
                        $ServerName = $_.PSComputerName
                        $env = $_.env
                        $_.ListWebApp | ForEach-Object{
                            $path = $_.Path
                            if($appItem = $this.WebApp_Sharepoint | Where-Object {($_.Title -eq "$siteName$path") -and ($_.Server.Name -eq $serverName)})
                            {
                                $appItem | ForEach-Object {
                                    $appItem_Update.Add($_)
                                    $this.log.WriteLog("Skip WebApp: '$($_.Title)' on Node: '$($_.Server.Name)', already exists",[severity]::Information)
                                }
                            }
                            else
                            {
                                $this.log.WriteLog("Add WebApp '$siteName$($_.Path)' on Node: '$serverName'",[severity]::Information)
                                Add-PnPListItem -List $SharePointWebAppListName  -Values @{
                                    "Server"=  $ServerID
                                    "Title" = "$siteName$($_.Path)"
                                    "Env" = $env
                                    "VirtualDirectory" = "<p>$(($_.VirtualDirectories | ForEach-Object {"$_"}) -join '<br/>')<p/>"
                                    "Pool" = $_.ApplicationPoolName
                                    } | ForEach-Object {                        
                                            $WebApp_Sharepoint = [WebApp_Sharepoint]::new()
                                            $WebApp_Sharepoint.Title = $_.FieldValues.Title
                                            $WebApp_Sharepoint.Server = $_.FieldValues.Server.LookupID
                                            $WebApp_Sharepoint.ID = $_.ID
                                            $appItem_Add.Add($WebApp_Sharepoint)
                                        }
                            }
                        }
                    }
                    $serverName = $PSItem.Group.PSComputerName                
                    $SiteName = ($PSItem.Name -split ",")[0]
                    $NewWebsite = $true
                    ##Site uz existuje v sharepoint je mozna potreba update Application field 
                    if($WebSite_Sharepoit = $this.WebSite_Sharepoint | Where-Object {$_.Title -eq $SiteName})
                    {
                        #same Name
                        foreach($WebSite_Item in $WebSite_Sharepoit)
                        {
                            #same server + same name 
                            if(!(Compare-Object -ReferenceObject $WebSite_Item.Server.Name -DifferenceObject $serverName))
                            {
                                $NewWebsite = $false
                                $this.log.WriteLog("WebSite '$SiteName' on Node: '$serverName', already exists",[severity]::Information)
                                $WebSite_SharePoint_ID = $WebSite_Item.ID
                                #No Apps on website 
                                if(!$WebSite_Item.Application)
                                {
                                    #UPDATE
                                    if($appItem_Update)
                                    {
                                        $this.Edit_Sharepoint__UpdateApp_Item($appItem_Update,$siteName,$serverName,$SharePointWebSiteListName,$SharePointWebAppListName,$WebSite_SharePoint_ID )
                                    }
                                    #No Apps on website - add old
                                    if($appItem_Add)
                                    {
                                        if($appItem_Update)
                                        {
                                            $appItem_Update | ForEach-Object {$appItem_Add.add($_)}
                                        }
                                        $this.Edit_Sharepoint__UpdateApp_Item($appItem_Add,$siteName,$serverName,$SharePointWebSiteListName,$SharePointWebAppListName,$WebSite_SharePoint_ID )
    
                                    }
                                    elseif(!($appItem_Update -and $appItem_Add))
                                    {
                                        $this.log.WriteLog("No applications on WebSite '$SiteName' on Node: '$serverName'",[severity]::Information)
                                    }
                                }
                                else #UPDATE
                                {
                                    #UPDATE
                                    if($appItem_Update)
                                    {
                                        if(!(Compare-Object -ReferenceObject $WebSite_Item.Application.Name -DifferenceObject $appItem_Update.Title))
                                        {
                                            $this.log.WriteLog("Skip item '$SiteName' on node: '$serverName', already exists",[severity]::Information)
                                        } 
                                        else #Apps are different - UPDATE
                                        {
                                            $this.Edit_Sharepoint__UpdateApp_Item($appItem_Update,$siteName,$serverName,$SharePointWebSiteListName,$SharePointWebAppListName,$WebSite_SharePoint_ID )
                                        }
                                    }
                                    #Add                           
                                    if($appItem_Add)
                                    {
                                        if($appItem_Update)
                                        {
                                            $appItem_Update | ForEach-Object {$appItem_Add.add($_)}
                                        }
                                        if(!(Compare-Object -ReferenceObject $WebSite_Item.Application.Name -DifferenceObject $appItem_Add.Title))
                                        {
                                            $this.log.WriteLog("Skip item '$SiteName' on node: '$serverName', already exists",[severity]::Information)
                                        } 
                                        else #App different ADD
                                        {
                                            $this.Edit_Sharepoint__UpdateApp_Item($appItem_Add,$siteName,$serverName,$SharePointWebSiteListName,$SharePointWebAppListName,$WebSite_SharePoint_ID )
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if($NewWebsite) #New Site
                    {
                        $this.Edit_Sharepoint__New_WebSite($appItem_Add,$appItem_Update,$siteName,$serverName,$SharePointWebSiteListName,$SharePointWebAppListName)
                    }
                }
                #Update maintenance WebSite
                $this.WebSite_Sharepoint |  Where-Object {$_.Date -and (Get-date) -gt $_.Date} | ForEach-Object {
                    if($_.Status -eq "Maintenance")
                    {
                        Set-PnPListItem -List $SharePointWebSiteListName -Identity $_.ID -Values @{"Status" = "Active"}
                        Set-PnPListItem -List $SharePointWebSiteListName -Identity $_.ID -Values @{"Date" = $null}
                        $this.log.WriteLog("Maintenance has expired, item: $($_.Title) on site: '$SharePointWebSiteListName'!",[severity]::Information) 
                    }
                }    
                #Update maintenance WebApp
                $this.WebApp_Sharepoint |  Where-Object {$_.Date -and (Get-date) -gt $_.Date} | ForEach-Object {
                    if($_.Status -eq "Maintenance")
                    {
                        Set-PnPListItem -List $SharePointWebAppListName -Identity $_.ID -Values @{"Status" = "Active"}
                        Set-PnPListItem -List $SharePointWebAppListName -Identity $_.ID -Values @{"Date" = $null}
                        $this.log.WriteLog("Maintenance has expired, item: $($_.Title) on site: '$SharePointWebAppListName'!",[severity]::Information) 
                    }
                }    
                $this.log.WriteLog("EportToSharepoint_DATA: DONE",[severity]::Information)
            }
            catch {
                $this.log.WriteLog("EportToSharepoint_DATA:$($_.Exception.Message)",[severity]::Error)
            }
            finally {
                Disconnect-PnPOnline 
                $this.log.writelog("Disconnected from '$SharePointSiteURL'",[severity]::Information)
            }
        }
        [void]Edit_Sharepoint__New_WebSite($appItem_Add,$appItem_Update,$siteName,$serverName,$SharePointWebSiteListName,$SharePointWebAppListName )
        {
            #Add new webApp to new website
            if($appItem_Add.ID)
            {
                $NewWebSite = Add-PnPListItem -List $SharePointWebSiteListName  -Values @{
                    "Server"=  $serverName | Foreach-Object {$this.GetServerID($_)}
                    "Title" = $SiteName
                    "Env" = $_.Group.Env | Select-Object -Unique
                    "Application" = $appItem_Add.ID}
                $this.log.WriteLog("New webSite: '$($NewWebSite.Title)' node: '$serverName'",[severity]::Information)
                #Update lookup field (WebSite)
                $appItem_Add | ForEach-Object {
                    Set-PnPListItem -List $SharePointWebAppListName -Identity $_.ID -Values @{"WebSite" = $NewWebSite.ID}
                    $this.log.WriteLog("Add '$($_.Title)' webSite field on list: '$SharePointWebAppListName'",[severity]::Information)
                }
            }
            #Add exist webApp to new website
            elseif($appItem_Update.ID)
            {
                $NewWebSite = Add-PnPListItem -List $SharePointWebSiteListName  -Values @{
                    "Server"=  $serverName | Foreach-Object {$this.GetServerID($_)}
                    "Title" = $SiteName
                    "Env" = $_.Group.Env | Select-Object -Unique
                    "Application" = $appItem_Update.ID}
                $this.log.WriteLog("New webSite: '$($NewWebSite.Title)' node: '$serverName'",[severity]::Information)
                #Update lookup field (WebSite)
                $appItem_Update | ForEach-Object {
                    Set-PnPListItem -List $SharePointWebAppListName -Identity $_.ID -Values @{"WebSite" = $NewWebSite.ID}
                    $this.log.WriteLog("Update '$($_.Title)' webSite field on list: '$SharePointWebAppListName'",[severity]::Information)
                }
            }
            else 
            {
                $this.log.WriteLog("WebSite item: '$SiteName' has not applications on node: '$serverName'",[severity]::Warning)
            }
        }
        [void]Edit_Sharepoint__UpdateApp_Item($appItem,$siteName,$serverName,$SharePointWebSiteListName,$SharePointWebAppListName,$WebSite_SharePoint_ID )
        {
            Set-PnPListItem -List $SharePointWebSiteListName -Identity $WebSite_SharePoint_ID -Values @{
                "Application" = $appItem.ID}
                $this.log.WriteLog("Add item to application field on item: '$SiteName', node: '$serverName'",[severity]::Information)
                #Update lookup field (WebSite)
                $appItem | ForEach-Object {
                    Set-PnPListItem -List $SharePointWebAppListName -Identity $_.ID -Values @{
                    "WebSite" = $WebSite_SharePoint_ID}
                    $this.log.WriteLog("Update: '$($_.Title)' webSite field on list: '$SharePointWebAppListName'",[severity]::Information)
            }
        }  
        [void]ImportFromSharepoint_List([System.Management.Automation.PSCredential]$sharedPointCredential,[string]$SharePointSiteURL,[string]$SharepointServersListName,[string]$SharePointWebSiteListName,[string]$SharePointWebAppListName,[string]$SharePointProbeListName)
        {
            [bool]$online = $false
            try 
            {
                try 
                {
                    $this.ConnectToSharepoint($sharedPointCredential,$SharePointSiteURL)
                    $this.log.WriteLog("ImportFromSharepoint: START",[severity]::Information)
                    $online = $true
                }
                catch 
                {
                    $this.log.WriteLog("ImportFromSharepoint: Connect to Sharepoint error: $($_.Exception.Message)",[severity]::Warning)
                }
                #Clear Variables from Sharepoint!
                $this.ClearSharepointVariables()
                if($online)
                {
                    #Server_Sharepoint
                    $this.log.WriteLog("ImportFromSharepoint: Get '$SharepointServersListName' list",[severity]::Information)
                    #$this.Server_Sharepoint = Get-PnPListItem -List $SharepointServersListName
                    #$list_Server = Get-PnPList -Identity $sharepointServersListName
                    if((Get-CimInstance win32_computersystem).Domain -eq "DS.KB.CZ") 
                    {
                        $listView_Server = Get-PnPView -List $sharepointServersListName -Identity "PS_PROD_Monitoring" -Includes ListViewXml
                        $this.log.WriteLog("ImportFromSharepoint: Get sharepoint view: 'PS_PROD_Monitoring'",[severity]::Information)
                    }    
                    else 
                    {
                        $listView_Server = Get-PnPView -List $sharepointServersListName -Identity "PS_TEST_Monitoring" -Includes ListViewXml
                        $this.log.WriteLog("ImportFromSharepoint: Get sharepoint view: 'PS_TEST_Monitoring'",[severity]::Information)
                    }
                    Get-PnPListItem -List $sharepointServersListName -Query $ListView_Server.ListViewXml | ForEach-Object {
                        $Server_Sharepoint = [Server_Sharepoint]::new()
                        $Server_Sharepoint.Name = $PSItem.FieldValues.Server
                        $Server_Sharepoint.Title = $PSItem.FieldValues.Title
                        $Server_Sharepoint.CheckCertificate = $PSItem.FieldValues.CheckCertificate
                        $Server_Sharepoint.CheckEventLog = $PSItem.FieldValues.CheckEventLog
                        $Server_Sharepoint.CheckHDD = $PSItem.FieldValues.CheckHDD
                        $Server_Sharepoint.CheckIISSite = $PSItem.FieldValues.CheckIISSite
                        $Server_Sharepoint.CheckLocalGroup = $PSItem.FieldValues.CheckLocalGroup
                        $Server_Sharepoint.CheckMSMQ = $PSItem.FieldValues.CheckMSMQ
                        $Server_Sharepoint.CheckProbeFile = $PSItem.FieldValues.CheckProbeFile
                        $Server_Sharepoint.CheckService = $PSItem.FieldValues.CheckService
                        $Server_Sharepoint.CheckScheduledTask = $PSItem.FieldValues.CheckScheduledTask
                        $Server_Sharepoint.CheckUptime = $PSItem.FieldValues.CheckUptime
                        $Server_Sharepoint.ID = $PSItem.FieldValues.ID
                        $Server_Sharepoint.Maintenance = $PSItem.FieldValues.Maintenance
                        if($Server_Sharepoint.CheckIISSite -eq $true -or $_.CheckProbeFile -eq $true)
                        {
                            if($Server_Sharepoint.Maintenance)
                            {
                                try 
                                {                                    
                                    #Parse
                                    $StartTimeString = ([regex]::Matches($Server_Sharepoint.Maintenance,'^\d{2}:\d{2}:\d{2}'))
                                    $PeriodOfTimeString = ([regex]::Matches($Server_Sharepoint.Maintenance,'PT\d{2}.'))
                                    $ReverseDayOfWeekString = ([regex]::Matches($Server_Sharepoint.Maintenance,'D\d{7}'))
                                    if($StartTimeString.Success)
                                    {
                                        #$StartTime = [datetime]::parseexact($StartTimeString.Value, 'hh:mm:ss', $null)
                                        $Server_Sharepoint.StartTime = [datetime]::parseexact($StartTimeString.Value, 'HH:mm:ss', $null)
                                    }
                                    else
                                    {throw "Cannot parse server maintanance window for start time value"}
                                    if($PeriodOfTimeString.Success)
                                    {
                                        $Unit = ([regex]::Matches($PeriodOfTimeString.Value,'.$')).Value
                                        [int]$PeriodOfTime = ([regex]::Matches($PeriodOfTimeString.Value,'\d{2}')).Value
                                        switch ($Unit) 
                                        {
                                            'h' {$Server_Sharepoint.StopTime = ($Server_Sharepoint.StartTime).AddHours($PeriodOfTime) ; break }
                                            'm' {$Server_Sharepoint.StopTime = ($Server_Sharepoint.StartTime).AddMinutes($PeriodOfTime) ; break }
                                            's' {$Server_Sharepoint.StopTime = ($Server_Sharepoint.StartTime).AddSeconds($PeriodOfTime) ; break }
                                            default {throw "Cannot parse server maintanance window for period time value"}
                                        }
                                    }
                                    else
                                    {throw "Cannot parse server maintanance window for period time value"}
                                    if($ReverseDayOfWeekString.Success)
                                    {
                                        #$ReverseDayOfWeek = ([regex]::Matches($ReverseDayOfWeekString.Value,'\d{7}')).Value
                                        [string]$DayOfWeek = ([regex]::Matches($ReverseDayOfWeekString.Value,'\d{7}')).Value
                                        #$DayOfWeek = ([regex]::Matches($ReverseDayOfWeek,'.','RightToLeft')).Value
                                    }
                                    else
                                    {throw "Cannot parse server maintanance window for day of week value"}                                     
                                    if([Int16]::Parse("$($DayOfWeek[[int]([datetime]::Now).DayOfWeek])") -ne 0)
                                    {
                                        "maintenance"
                                        if([datetime]::Now -gt $Server_Sharepoint.StartTime -and [datetime]::Now -lt $Server_Sharepoint.StopTime)    
                                        {
                                            $this.log.WriteLog("ImportFromSharepoint: Server:$($Server_Sharepoint.Name) had been in maintenance by $(($Server_Sharepoint.StopTime).ToString("dd.MM.yyyy HH:mm:ss"))",[severity]::Information)
                                            $this.Server_Sharepoint_Maintenance.Add($Server_Sharepoint)
                                        }
                                        else 
                                        {
                                            $this.Server_Sharepoint.Add($Server_Sharepoint)
                                            $this.log.WriteLog("ImportFromSharepoint: Add Server:$($Server_Sharepoint.Name) to Server_Sharepoint list, no maintanance window set",[severity]::Information)
                                        }
                                    }
                                }
                                catch 
                                {
                                    $this.log.WriteLog("ImportFromSharepoint:$($_.Exception.Message)",[severity]::Warning)
                                    $this.Server_Sharepoint.Add($Server_Sharepoint)
                                    $this.log.WriteLog("ImportFromSharepoint: Add Server:$($Server_Sharepoint.Name) to Server_Sharepoint list, maintenance window parse error",[severity]::Warning)
                                }
                            }
                            else 
                            {
                                $this.Server_Sharepoint.Add($Server_Sharepoint)
                                $this.log.WriteLog("ImportFromSharepoint: Add Server:$($Server_Sharepoint.Name) to Server_Sharepoint list, no maintanance window set",[severity]::Information)
                            }
                        }
                    }
                    #Filter here
                    #$this.Server_Sharepoint = $this.Server_Sharepoint | Where-Object {$_.Name -like "saplab750" -or $_.Name -like "saplab751"}
                    [System.Management.Automation.PSSerializer]::Serialize($this.Server_Sharepoint) | Set-Content -Path "$(Get-Location)\Serialize\Server_Sharepoint.xml"
                    $this.log.WriteLog("ImportFromSharepoint: Serialize Server_Sharepoint property",[severity]::Information)
                    #WebSite_Sharepoint
                    $this.log.WriteLog("ImportFromSharepoint: Get '$SharePointWebSiteListName' list",[severity]::Information)
                    $this.WebSite_Sharepoint = [System.Collections.Generic.List[WebSite_Sharepoint]]::new()
                    #$this.WebSite_Sharepoint = Get-PnPListItem -List $SharePointWebSiteListName
                    Get-PnPListItem -List $SharePointWebSiteListName | ForEach-Object {
                        $WebSite_Sharepoint = [WebSite_Sharepoint]::new()
                        $WebSite_Sharepoint.Title = $PsItem.FieldValues.Title
                        $PsItem.FieldValues.Server | ForEach-Object {
                            $server = [pscustomobject]::new()
                            $server | Add-Member -MemberType NoteProperty -Name "Name" -value $_.LookupValue
                            $server | Add-Member -MemberType NoteProperty -Name "LookupId" -value $_.LookupId
                            $WebSite_Sharepoint.Server.Add($server)
                        }
                        $WebSite_Sharepoint.Probe = $PsItem.FieldValues.Probe.LookupValue
                        #$WebSite_Sharepoint.Application = $PsItem.FieldValues.Application.LookupValue
                        $PsItem.FieldValues.Application | ForEach-Object {
                            $application = [pscustomobject]::new()
                            $application | Add-Member -MemberType NoteProperty -Name "Name" -value $_.LookupValue
                            $application | Add-Member -MemberType NoteProperty -Name "LookupId" -value $_.LookupId
                            $WebSite_Sharepoint.Application.Add($application)
                        }
                        $WebSite_Sharepoint.Mode = $PsItem.FieldValues.Mode
                        $WebSite_Sharepoint.Status = $PsItem.FieldValues.Status
                        $WebSite_Sharepoint.Date = $PSItem.FieldValues.Date
                        $WebSite_Sharepoint.Email = $PSItem.FieldValues.Email.Email
                        $WebSite_Sharepoint.ID = $PSItem.FieldValues.ID
                        $this.WebSite_Sharepoint.Add($WebSite_Sharepoint)
                    }
    
                    [System.Management.Automation.PSSerializer]::Serialize($this.WebSite_Sharepoint) | Set-Content -Path "$(Get-Location)\Serialize\WebSite_Sharepoint.xml"
                    $this.log.WriteLog("ImportFromSharepoint: Serialize WebSite_Sharepoint property",[severity]::Information)
                    
                    #WebApp_Sharepoint
                    $this.log.WriteLog("ImportFromSharepoint: Get '$SharePointWebAppListName' list",[severity]::Information)
                    Get-PnPListItem -List $SharePointWebAppListName | ForEach-Object {
                        $WebApp_Sharepoint = [WebApp_Sharepoint]::new()
                        $WebApp_Sharepoint.Title = $PsItem.FieldValues.Title
                        $PsItem.FieldValues.Server | ForEach-Object {
                            $server = [pscustomobject]::new()
                            $server | Add-Member -MemberType NoteProperty -Name "Name" -value $_.LookupValue
                            $server | Add-Member -MemberType NoteProperty -Name "LookupId" -value $_.LookupId
                            $WebApp_Sharepoint.Server.Add($server)
                        }
                        $WebApp_Sharepoint.VirtualDirectory =  $PsItem.FieldValues.VirtualDirectory -Split ';' -replace '<br>|<p>|.&#58', ''| Where-Object {$_ -ne [string]::empty}
                        $site = [pscustomobject]::new()
                        $site | Add-Member -MemberType NoteProperty -Name "Name" -value $PSItem.FieldValues.WebSite.LookupValue
                        $site | Add-Member -MemberType NoteProperty -Name "LookupId" -value $PSItem.FieldValues.WebSite.LookupId
                        $WebApp_Sharepoint.WebSite = $site
                        $WebApp_Sharepoint.Status = $PsItem.FieldValues.Status
                        $WebApp_Sharepoint.Date = $PSItem.FieldValues.Date
                        $WebApp_Sharepoint.Email = $PSItem.FieldValues.Email.LookupValue
                        $WebApp_Sharepoint.ID = $PSItem.FieldValues.ID
                        $this.WebApp_Sharepoint.Add($WebApp_Sharepoint)
                    }
                
                    #$this.WebApp_Sharepoint = Get-PnPListItem -List $SharePointWebAppListName
                    [System.Management.Automation.PSSerializer]::Serialize($this.WebApp_Sharepoint) | Set-Content -Path "$(Get-Location)\Serialize\WebApp_Sharepoint.xml"
                    $this.log.WriteLog("ImportFromSharepoint: Serialize WebApp_Sharepoint property",[severity]::Information)
                    #Probe_Sharepoint
                    $this.log.WriteLog("ImportFromSharepoint: Get '$SharePointProbeListName' list",[severity]::Information)
                    #$this.Probe_Sharepoint = Get-PnPListItem -List $SharePointProbeListName
                    Get-PnPListItem -List $SharePointProbeListName | ForEach-Object {
                        $Probe_Sharepoint = [Probe_Sharepoint]::new()
                        $Probe_Sharepoint.Uri = $PSItem.FieldValues.Title
                        $Probe_Sharepoint.ServerName = $PSItem.FieldValues.ServerName.LookupValue
                        $Probe_Sharepoint.ID = $PSItem.FieldValues.ID
                        $this.Probe_Sharepoint.Add($Probe_Sharepoint)
                    }
                    [System.Management.Automation.PSSerializer]::Serialize($this.Probe_Sharepoint) | Set-Content -Path "$(Get-Location)\Serialize\Probe_Sharepoint.xml"
                    $this.log.WriteLog("ImportFromSharepoint: Serialize Probe_Sharepoint property",[severity]::Information)
                    $this.log.WriteLog("ImportFromSharepoint: DONE",[severity]::Information)
                }
            }
            catch 
            {
                $this.log.WriteLog("ImportFromSharepoint:$($_.Exception.Message)",[severity]::Error)
            }
            #Load variables from .xml files
            try 
            {
                if(!($online))
                {
                    $this.log.WriteLog("ImportFromSharepoint: SharePoint is offline, loading backup variables! $($_.Exception.Message)",[severity]::Information)
                    
                    [System.Array]$this.Server_Sharepoint = [System.Management.Automation.PSSerializer]::Deserialize((Get-Content -Path "$(Get-Location)\Serialize\Server_Sharepoint.xml"))
                    $this.log.WriteLog("ImportFromSharepoint: Get $SharepointServersListName list from file: 'Server_Sharepoint.xml'",[severity]::Information)
                    [System.Array]$this.WebSite_Sharepoint = [System.Management.Automation.PSSerializer]::Deserialize((Get-Content -Path "$(Get-Location)\Serialize\WebSite_Sharepoint.xml"))
                    $this.log.WriteLog("ImportFromSharepoint: Get $SharePointWebSiteListName list from file: 'WebSite_Sharepoint.xml'",[severity]::Information)
                    [System.Array]$this.WebApp_Sharepoint = [System.Management.Automation.PSSerializer]::Deserialize((Get-Content -Path "$(Get-Location)\Serialize\WebApp_Sharepoint.xml"))
                    $this.log.WriteLog("ImportFromSharepoint: Get $SharePointWebAppListName list from file: 'WebApp_Sharepoint.xml'",[severity]::Information)
                    [System.Array]$this.Probe_Sharepoint = [System.Management.Automation.PSSerializer]::Deserialize((Get-Content -Path "$(Get-Location)\Serialize\Probe_Sharepoint.xml"))
                    $this.log.WriteLog("ImportFromSharepoint: Get $SharePointProbeListName list from file: 'Probe_Sharepoint.xml'",[severity]::Information)
                }
            }
            catch 
            {
                $this.log.WriteLog("ImportFromSharepoint:$($_.Exception.Message)",[severity]::Error)
            }
    
            finally 
            {
                if($online)
                {
                    Disconnect-PnPOnline 
                    $this.log.writelog("Disconnected from $SharePointSiteURL",[severity]::Information)
                }
            }
        }
        [void]ClearSharepointVariables()
        {
            try
            {
                $this.WebSite_Sharepoint = [System.Collections.Generic.List[WebSite_Sharepoint]]::new()
                $this.WebApp_Sharepoint = [System.Collections.Generic.List[WebApp_Sharepoint]]::new()
                $this.Probe_Sharepoint = [System.Collections.Generic.List[Probe_Sharepoint]]::new()
                $this.Server_Sharepoint = [System.Collections.Generic.List[Server_Sharepoint]]::new()
                $this.Server_Sharepoint_Maintenance = [System.Collections.Generic.List[Server_Sharepoint]]::new()
                $this.log.WriteLog("ClearSharepointVariables successfully done!",[severity]::Information)
            }
            catch
            {
                $this.log.WriteLog("ClearSharepointVariables: $($_.Exception.Message)",[severity]::Error)
            }
        }    
        [void]GetWebSiteError()
        {
            try 
            {
                $this.IISWebSite | ForEach-Object {
                    $Site = $PSItem
                    $this.WebSite_Sharepoint | Where-Object {$_.Status -eq "Active"}| Foreach-Object {
                        if($PSItem.Title -eq $Site.Sitename -and ($PSItem.Server.Name).Contains($Site.PSComputerName))
                        {
                            $uri = ($PSItem.Probe | Foreach-Object {
                                $probe = $_
                                $this.Probe_Sharepoint | Where-Object {
                                    $_.Uri -eq $probe -and $_.ServerName -eq $Site.PSComputerName}}).Uri    
                            if($uri)
                            {
                                $this.log.WriteLog("Get Probe status for website name: '$($PSItem.Title)'",[severity]::Information)
                                $probe =  [Probe]::new($Site.PSComputerName,$Site.SiteName,$uri,$this.log,$Site.Farm_ID)
                                if($this.Proxy)
                                {
                                    $probe.GetProbeState($proxyURL)
                                }
                                else 
                                {
                                    $probe.GetProbeState()
                                }
                                $Site.Probe.Add($probe)                        
                            }
                        }
                    }
                }
                $this.IISWebSite | Foreach-Object {
                    $Site = $PSItem
                    $this.WebSite_Sharepoint | Where-Object {$_.Status -eq "Active"}| Foreach-Object {
                        if($PSItem.Title -eq $Site.Sitename -and ($PSItem.Server.Name).Contains($Site.PSComputerName))
                        {
                            $this.log.WriteLog("Get Web Site error for website name: '$($PSItem.Title)'",[severity]::Information)
                            #Check
                            $ProbeState = ($this.IISWebSite | Where-Object {$_.Farm_ID -eq $Site.Farm_ID}).Probe.State
                            switch ($PSItem.Mode) 
                            {
                                "Single" {
                                    switch ($Site.Probe.State) {
                                        "UP" 
                                        {
                                            switch ($site.SiteStatus) {
                                                "Started" { 
                                                    $Site.listWebApp | Foreach-Object {
                                                        $WebApp = $PsItem
                                                        switch ($WebApp.ApplicationPoolState)
                                                        {
                                                            "Started" 
                                                            { 
                                                                break
                                                            }
                                                            Default 
                                                            {
                                                                if(($this.WebApp_Sharepoint | Where-Object {$_.ID -eq $WebApp.WebApp_ID}).Status -eq "Active")
                                                                {
                                                                    $Site.ErrorMessage.Add([ErrorMessage]::new("WebApplication: <a href=""$SharePointSiteURL/Lists/WebApp/DispForm.aspx?ID=$($WebApp.WebApp_ID)"">$($site.SiteName)$($WebApp.Path)</a>, AppPool: $($WebApp.ApplicationPoolName) = $($WebApp.ApplicationPoolState)",[severity]::Error,$Site.PSComputerName))
    
                                                                }
                                                            }
                                                        }
                                                    }
                                                    break
                                                }
                                                Default {
                                                    $Site.ErrorMessage.Add([ErrorMessage]::new("WebSite: '$($Site.SiteName)'status = $($site.SiteStatus)",[severity]::Error,$site.PSComputerName))
                                                }
                                            }
                                        }
                                        "DOWN" 
                                        {
                                            if(($ProbeState | Where-Object {$_ -eq "UP"}).Count -ne 1)
                                            {
                                                $Site.ErrorMessage.Add([ErrorMessage]::new("$(($ProbeState | Where-Object {$_ -eq "UP"}).Count)/$($ProbeState.Count) probes are UP in single mode!",[severity]::Warning,$site.PSComputerName))

                                            }
                                            switch ($site.SiteStatus) {
                                                "Started" { 
                                                    $Site.listWebApp | Foreach-Object {
                                                        $WebApp = $PsItem
                                                        switch ($WebApp.ApplicationPoolState)
                                                        {
                                                            "Started" 
                                                            { 
                                                                break
                                                            }
                                                            Default 
                                                            {
                                                                if(($this.WebApp_Sharepoint | Where-Object {$_.ID -eq $WebApp.WebApp_ID}).Status -eq "Active")
                                                                {
                                                                    $Site.ErrorMessage.Add([ErrorMessage]::new("WebApplication: <a href=""$SharePointSiteURL/Lists/WebApp/DispForm.aspx?ID=$($WebApp.WebApp_ID)"">$($site.SiteName)$($WebApp.Path)</a>, AppPool: $($WebApp.ApplicationPoolName) = $($WebApp.ApplicationPoolState)",[severity]::Error,$Site.PSComputerName))
    
                                                                }
                                                            }
                                                        }
                                                    }
                                                    break
                                                }
                                                Default {
                                                    $Site.ErrorMessage.Add([ErrorMessage]::new("WebSite: '$($Site.SiteName)'status = $($site.SiteStatus)",[severity]::Error,$site.PSComputerName))
                                                }
                                            }
                                        }
                                        #No Probe 
                                        Default 
                                        {
                                            switch ($Site.SiteStatus) 
                                            {
                                                "Started" 
                                                { 
                                                    $Site.listWebApp | Foreach-Object {
                                                        $WebApp = $PsItem
                                                        switch ($WebApp.ApplicationPoolState)
                                                        {
                                                            "Started" 
                                                            { 
                                                                break
                                                            }
                                                            Default 
                                                            {
                                                                if(($this.WebApp_Sharepoint | Where-Object {$_.ID -eq $WebApp.WebApp_ID}).Status -eq "Active")
                                                                {
                                                                    $Site.ErrorMessage.Add([ErrorMessage]::new("WebApplication: <a href=""$SharePointSiteURL/Lists/WebApp/DispForm.aspx?ID=$($WebApp.WebApp_ID)"">$($site.SiteName)$($WebApp.Path)</a>, AppPool: $($WebApp.ApplicationPoolName) = $($WebApp.ApplicationPoolState)",[severity]::Error,$Site.PSComputerName))
    
                                                                }
                                                            }
                                                        }
                                                    }
                                                    break
                                                }
                                                Default 
                                                {
                                                    $Site.ErrorMessage.Add([ErrorMessage]::new("WebSite: '$($Site.SiteName)'status = $($site.SiteStatus)",[severity]::Error,$site.PSComputerName))
                                                }
                                            }
                                        }
                                    }
                                    break
                                }
                                "Multi" {
                                    switch ($Site.Probe.State) {
                                        "UP" 
                                        {
                                            switch ($site.SiteStatus) {
                                                "Started" { 
                                                    $Site.listWebApp | Foreach-Object {
                                                        $WebApp = $PsItem
                                                        switch ($WebApp.ApplicationPoolState)
                                                        {
                                                            "Started" 
                                                            { 
                                                                break
                                                            }
                                                            Default 
                                                            {
                                                                if(($this.WebApp_Sharepoint | Where-Object {$_.ID -eq $WebApp.WebApp_ID}).Status -eq "Active")
                                                                {
                                                                    $Site.ErrorMessage.Add([ErrorMessage]::new("WebApplication: <a href=""$SharePointSiteURL/Lists/WebApp/DispForm.aspx?ID=$($WebApp.WebApp_ID)"">$($site.SiteName)$($WebApp.Path)</a>, AppPool: $($WebApp.ApplicationPoolName) = $($WebApp.ApplicationPoolState)",[severity]::Error,$Site.PSComputerName))
    
                                                                }
                                                            }
                                                        }
                                                    }
                                                    break
                                                }
                                                Default {
                                                    $Site.ErrorMessage.Add([ErrorMessage]::new("WebSite: '$($Site.SiteName)'status = $($site.SiteStatus)",[severity]::Error,$site.PSComputerName))
                                                }
                                            }
                                        }
                                        "DOWN" 
                                        {
                                            if(($ProbeState | Where-Object {$_ -eq "DOWN"}).Count -ne 0)
                                            {
                                                $Site.ErrorMessage.Add([ErrorMessage]::new("$(($ProbeState | Where-Object {$_ -eq "DOWN"}).Count)/$($ProbeState.Count) probes are DOWN in multi mode!",[severity]::Warning,$site.PSComputerName))
                                            }
                                            $Site.ErrorMessage.Add([ErrorMessage]::new("Probe: $($site.Probe.Uri) on server $($site.Probe.ServerName) is $($site.Probe.State)",[severity]::Error,$site.PSComputerName))
                                            switch ($site.SiteStatus) {
                                                'Started' { 
                                                    $Site.listWebApp | Foreach-Object {
                                                        $WebApp = $PsItem
                                                        switch ($WebApp.ApplicationPoolState)
                                                        {
                                                            "Started" 
                                                            { 
                                                                break
                                                            }
                                                            Default 
                                                            {
                                                                if(($this.WebApp_Sharepoint | Where-Object {$_.ID -eq $WebApp.WebApp_ID}).Status -eq "Active")
                                                                {
                                                                    $Site.ErrorMessage.Add([ErrorMessage]::new("WebApplication: <a href=""$SharePointSiteURL/Lists/WebApp/DispForm.aspx?ID=$($WebApp.WebApp_ID)"">$($site.SiteName)$($WebApp.Path)</a>, AppPool: $($WebApp.ApplicationPoolName) = $($WebApp.ApplicationPoolState)",[severity]::Error,$Site.PSComputerName))
    
                                                                }
                                                            }
                                                        }
                                                    }
                                                    break
                                                }
                                                Default {
                                                    $Site.ErrorMessage.Add([ErrorMessage]::new("WebSite: '$($Site.SiteName)'status = $($site.SiteStatus)",[severity]::Error,$site.PSComputerName))
                                                }
                                            }
                                        }
                                        #No Probe 
                                        Default 
                                        {
                                            switch ($site.SiteStatus) 
                                            {
                                                "Started" 
                                                { 
                                                    $Site.listWebApp | Foreach-Object {
                                                        $WebApp = $PsItem
                                                        switch ($WebApp.ApplicationPoolState)
                                                        {
                                                            "Started" 
                                                            { 
                                                                break
                                                            }
                                                            Default 
                                                            {
                                                                if(($this.WebApp_Sharepoint | Where-Object {$_.ID -eq $WebApp.WebApp_ID}).Status -eq "Active")
                                                                {
                                                                    $Site.ErrorMessage.Add([ErrorMessage]::new("WebApplication: <a href=""$SharePointSiteURL/Lists/WebApp/DispForm.aspx?ID=$($WebApp.WebApp_ID)"">$($site.SiteName)$($WebApp.Path)</a>, AppPool: $($WebApp.ApplicationPoolName) = $($WebApp.ApplicationPoolState)",[severity]::Error,$Site.PSComputerName))
    
                                                                }
                                                            }
                                                        }
                                                    }
                                                    break
                                                }
                                                Default 
                                                {
                                                    $Site.ErrorMessage.Add([ErrorMessage]::new("WebSite: '$($Site.SiteName)'status = $($site.SiteStatus)",[severity]::Error,$site.PSComputerName))
                                                }
                                            }
                                        }
                                    }
                                    break
                                }
                                default {
                                    switch ($Site.Probe.State) {
                                        "UP" 
                                        {
                                            switch ($site.SiteStatus) {
                                                "Started" { 
                                                    $Site.listWebApp | Foreach-Object {
                                                        $WebApp = $PsItem
                                                        switch ($WebApp.ApplicationPoolState)
                                                        {
                                                            "Started" 
                                                            { 
                                                                break
                                                            }
                                                            Default 
                                                            {
                                                                if(($this.WebApp_Sharepoint | Where-Object {$_.ID -eq $WebApp.WebApp_ID}).Status -eq "Active")
                                                                {
                                                                    $Site.ErrorMessage.Add([ErrorMessage]::new("WebApplication: <a href=""$SharePointSiteURL/Lists/WebApp/DispForm.aspx?ID=$($WebApp.WebApp_ID)"">$($site.SiteName)$($WebApp.Path)</a>, AppPool: $($WebApp.ApplicationPoolName) = $($WebApp.ApplicationPoolState)",[severity]::Error,$Site.PSComputerName))
    
                                                                }
                                                            }
                                                        }
                                                    }
                                                    break
                                                }
                                                Default {
                                                    $Site.ErrorMessage.Add([ErrorMessage]::new("WebSite: '$($Site.SiteName)'status = $($site.SiteStatus)",[severity]::Error,$site.PSComputerName))
                                                }
                                            }
                                        }
                                        "DOWN" 
                                        {
                                            if(($ProbeState | Where-Object {$_ -eq "DOWN"}).Count -ne 0)
                                            {
                                                $Site.ErrorMessage.Add([ErrorMessage]::new("$(($ProbeState | Where-Object {$_ -eq "DOWN"}).Count)/$($ProbeState.Count) probes are DOWN!",[severity]::Warning,$site.PSComputerName))
                                            }
                                            $Site.ErrorMessage.Add([ErrorMessage]::new("Probe: $($site.Probe.Uri) on server $($site.Probe.ServerName) is $($site.Probe.State)",[severity]::Error,$site.PSComputerName))
                                            switch ($site.SiteStatus) {
                                                'Started' { 
                                                    $Site.listWebApp | Foreach-Object {
                                                        $WebApp = $PsItem
                                                        switch ($WebApp.ApplicationPoolState)
                                                        {
                                                            "Started" 
                                                            { 
                                                                break
                                                            }
                                                            Default 
                                                            {
                                                                if(($this.WebApp_Sharepoint | Where-Object {$_.ID -eq $WebApp.WebApp_ID}).Status -eq "Active")
                                                                {
                                                                    $Site.ErrorMessage.Add([ErrorMessage]::new("WebApplication: <a href=""$SharePointSiteURL/Lists/WebApp/DispForm.aspx?ID=$($WebApp.WebApp_ID)"">$($site.SiteName)$($WebApp.Path)</a>, AppPool: $($WebApp.ApplicationPoolName) = $($WebApp.ApplicationPoolState)",[severity]::Error,$Site.PSComputerName))
                                                                }
                                                            }
                                                        }
                                                    }
                                                    break
                                                }
                                                Default {
                                                    $Site.ErrorMessage.Add([ErrorMessage]::new("WebSite: '$($Site.SiteName)'status = $($site.SiteStatus)",[severity]::Error,$site.PSComputerName))
                                                }
                                            }
                                        }
                                        #No Probe 
                                        Default 
                                        {
                                            switch ($site.SiteStatus) 
                                            {
                                                "Started" 
                                                { 
                                                    $Site.listWebApp | Foreach-Object {
                                                        $WebApp = $PsItem
                                                        switch ($WebApp.ApplicationPoolState)
                                                        {
                                                            "Started" 
                                                            { 
                                                                break
                                                            }
                                                            Default 
                                                            {
                                                                if(($this.WebApp_Sharepoint | Where-Object {$_.ID -eq $WebApp.WebApp_ID}).Status -eq "Active")
                                                                {
                                                                    $Site.ErrorMessage.Add([ErrorMessage]::new("WebApplication: <a href=""$SharePointSiteURL/Lists/WebApp/DispForm.aspx?ID=$($WebApp.WebApp_ID)"">$($site.SiteName)$($WebApp.Path)</a>, AppPool: $($WebApp.ApplicationPoolName) = $($WebApp.ApplicationPoolState)",[severity]::Error,$Site.PSComputerName))
                                                                }
                                                            }
                                                        }
                                                    }
                                                    break
                                                }
                                                Default 
                                                {
                                                    $Site.ErrorMessage.Add([ErrorMessage]::new("WebSite: '$($Site.SiteName)'status = $($site.SiteStatus)",[severity]::Error,$site.PSComputerName))
                                                }
                                            }
                                        }
                                    }
                                    break
                                }
                            }
                        }

                    }
                $Site.ErrorMessage | ForEach-Object {$PSItem.Farm_ID = $Site.Farm_ID}
                }
            }
            catch 
            {
                $this.log.WriteLog("$($_.Exception.Message)",[severity]::Error)
            }
        }        
        [void]GetWebFarmID()
        {
            try
            {
                $this.WebSite_Sharepoint | Where-Object {$_.Status -eq "Active"} | ForEach-Object {
                    $WebSite_Sharepoint = $PSItem
                    $this.IISWebSite | ForEach-Object {
                        if(($WebSite_Sharepoint.Server.Name).Contains($_.PSComputerName) -and $WebSite_Sharepoint.Title -eq $_.SiteName)
                        {
                            $IISWebSite = $PSItem
                            $IISWebSite.Farm_ID = $WebSite_Sharepoint.ID
                            $this.log.WriteLog("Add IISSite name: '$($PSItem.SiteName)' WebFarm_ID: '$($WebSite_Sharepoint.ID)'",[severity]::Information)
                            if($WebSite_Sharepoint.Email)
                            {
                                $WebSite_Sharepoint.Email | ForEach-Object {
                                    $IISWebSite.email.Add($_)
                                }
                                $this.log.WriteLog("Add IISSite name: '$($IISWebSite.SiteName)' to Web email address: '$($WebSite_Sharepoint.Email)'",[severity]::Information)
                            }
                        }
                    } 
                }
            }
            catch
            {
                $this.log.WriteLog("$($_.Exception.Message)",[severity]::Error)
            }
        }
        [void]GetWebAppID()
        {
            try 
            {
                $this.WebApp_Sharepoint | ForEach-Object {
                    $WebApp_Sharepoint = $PSItem
                    $SiteName_Sharepoint = $WebApp_Sharepoint.Title -replace "/.*",""
                    $WebAppName_Sharepoint = $WebApp_Sharepoint.Title -replace $SiteName_Sharepoint,""
                    $this.IISWebSite | ForEach-Object {
                        $IISWebSite = $PSItem
                        if($IISWebSite.Sitename -eq $SiteName_Sharepoint -and $WebApp_Sharepoint.Server.Name -eq $IISWebSite.PSComputerName)
                        {
                            $IISWebSite.ListWebApp | ForEach-Object {
                                $ListWebApp = $PSItem
                                if($ListWebApp.Path -eq $WebAppName_Sharepoint)
                                {
                                    $ListWebApp.WebApp_ID = $WebApp_Sharepoint.ID
                                    $this.log.WriteLog("Add WebAppID: '$($WebApp_Sharepoint.ID)' to IISWebApp: '$($ListWebApp.Path)' from Sharepoint list WebApp item: '$($WebApp_Sharepoint.Title)'",[severity]::Information)
                                }
                            }
                        }
                    }
                }
            }
            catch 
            {
                $this.log.WriteLog("$($_.Exception.Message)",[severity]::Error)
            }
        }
        [string]GetErrorTable([System.Array]$errorMessage)
        {
            $ErrorTable = $errorMessage | ForEach-Object {
                $PSItem | Select-Object -Property   @{L= "SiteName" ;E= {"<a href=""$SharePointSiteURL/Lists/WebSite/DispForm.aspx?ID=$(($_.Name -split ",").Trim()[1])"">$(($_.Name -split ",").Trim()[0])</a><br>"}},`
                                                        @{L= "Node" ;E= {$_.Group.PSComputerName | ForEach-Object {"<a href=""$SharePointSiteURL/Lists/Servers/DispForm.aspx?ID=$($this.GetServerID($_))"">$($_)</a><br>"}}},`
                                                        @{L= "ProbeStatus" ;E= {$_.Group.Probe | ForEach-Object {"<a $(if($_.State -eq "UP"){"id='Green'"}else{"id='Red'"}) href=""$SharePointSiteURL/Lists/CheckProbeFile/DispForm.aspx?ID=$($this.GetProbeID($_.uri))"">$(if($_.State -eq "UP"){"ONLINE"}elseif($_.State -eq "DOWN"){"OFFLINE"})</a><br>"}}},`
                                                        @{L= "SiteStatus" ;E= {$_.Group | ForEach-Object {"<div $(if($_.SiteStatus -eq "Started"){"id='Green'>$($_.SiteStatus)"}else{"id='Red'>$($_.SiteStatus)"})</div>"}}},`
                                                        @{L= "Message" ;E= {$_.Group.ErrorMessage | ForEach-Object {$PSItem.WriteLine()}}}                   
            } | ConvertTo-Html -Fragment 
            $ErrorTable = [System.Web.HttpUtility]::HtmlDecode($ErrorTable)
            $this.log.WriteLog("New ErrorTable was created",[severity]::Information)
            return $ErrorTable
        }
        [string]GetErrorTable([System.Array]$errorMessage_Deserialize,[System.Array]$errorMessage_Message_Deserialize,[System.Array]$errorMessage_Probe_Deserialize)
        {
            $ErrorTable = $errorMessage_Deserialize | ForEach-Object {
                $errorMessage_Deserialize_Group = $PSItem
                $errorMessage_Deserialize_Group | Select-Object -Property   @{L= "SiteName" ;E= {"<a href=""$SharePointSiteURL/Lists/WebSite/DispForm.aspx?ID=$(($_.Name -split ",").Trim()[1])"">$(($_.Name -split ",").Trim()[0])</a><br>"}},`
                                                        @{L= "Node" ;E= {$_.Group.PSComputerName | ForEach-Object {"<a href=""$SharePointSiteURL/Lists/Servers/DispForm.aspx?ID=$($this.GetServerID($_))"">$($_)</a><br>"}}},`
                                                        @{L= "ProbeStatus" ;E= {$errorMessage_Probe_Deserialize  | Where-Object {($errorMessage_Deserialize_Group.Group.Farm_id | Select-Object -Unique) -eq $_.Farm_ID} | ForEach-Object {"<a $(if($_.State -eq "UP"){"id='Green'"}else{"id='Red'"}) href=""$SharePointSiteURL/Lists/CheckProbeFile/DispForm.aspx?ID=$($this.GetProbeID($_.uri))"">$(if($_.State -eq "UP"){"ONLINE"}elseif($_.State -eq "DOWN"){"OFFLINE"})</a><br>"}}},`
                                                        @{L= "SiteStatus" ;E= {$_.Group | ForEach-Object {"<div $(if($_.SiteStatus -eq "Started"){"id='Green'>$($_.SiteStatus)"}else{"id='Red'>$($_.SiteStatus)"})</div>"}}},`
                                                        #<@{L= "Message" ;E= {$_.Group.ErrorMessage | ForEach-Object {$PSItem.WriteLine()}}}  #>
                                                        @{L= "MonitorStatus" ;E= {($this.WebSite_Sharepoint | Where-Object {$_.ID -eq ($errorMessage_Deserialize_Group.Group.Farm_ID | Select-Object -Unique) }).Status}},`
                                                        @{L= "Message" ;E= {    $errorMessage_Message_Deserialize  | Where-Object {($errorMessage_Deserialize_Group.Group.Farm_id | Select-Object -Unique) -eq $_.Farm_ID} | ForEach-Object {"<strong $(if($_.Severity -eq "Error"){"id='Red'"}elseif($_.Severity -eq "Warning"){"id='Orange'"})>[$($_.Severity)]</strong>;[$($_.Node)]:$($_.Message)<br>"} }}                 
            } | ConvertTo-Html -Fragment 
            $ErrorTable = [System.Web.HttpUtility]::HtmlDecode($ErrorTable)
            $this.log.WriteLog("New last ErrorTable was created",[severity]::Information)
            return $ErrorTable
        }
        [string]GetNewWebSiteTable([System.Array]$newWebSite)
        {
            $NewWebSiteTable = $NewWebSite | ForEach-Object {
                $PSItem | Select-Object -Property   @{L= "SiteName" ;E= {"<a href=""$SharePointSiteURL/Lists/WebSite/DispForm.aspx?ID=$($_.ID)"">$($_.Title)</a><br>"}},`
                                                    @{L= "Node" ;E= {$_.Server |ForEach-Object {"<a href=""$SharePointSiteURL/Lists/Servers/DispForm.aspx?ID=$($_.LookupID)"">$($_.Name)</a><br>"}}},`
                                                    @{L= "MonitorStatus" ;E= {$_.Status}}
            } | ConvertTo-Html -Fragment
            $NewWebSiteTable = [System.Web.HttpUtility]::HtmlDecode($NewWebSiteTable)
            $this.log.WriteLog("New NewWebSiteTable was created",[severity]::Information)
            return $NewWebSiteTable
        }
        [string]GetServerMaintenanceTable()
        {
            $ServerMaintenanceTable = $this.Server_Sharepoint_Maintenance | ForEach-Object {
                $PSItem | Select-Object -Property   @{L= "Name"; E = {"<a href=""$SharePointSiteURL/Lists/Servers/DispForm.aspx?ID=$($this.GetServerID($PSItem.Name))"">$($PSItem.Name)</a><br>"}},`
                                                    @{L= "Start" ;E= {$PSItem.StartTime}},`
                                                    @{L= "End" ;E= {$PSItem.StopTime}}
            } | ConvertTo-Html -Fragment
            $ServerMaintenanceTable = [System.Web.HttpUtility]::HtmlDecode($ServerMaintenanceTable)
            $this.log.WriteLog("New ServerMaintenanceTable was created",[severity]::Information)
            return $ServerMaintenanceTable
        }
        [void]SendMailMessage([string]$smtpServer,[string]$defaultEmail,[string]$csS_header,[System.Array]$ErrorMessage_Deserialize,[System.Array]$ErrorMessage_Message_Deserialize,[System.Array]$ErrorMessage_Probe_Deserialize,[string]$SharePointSiteURL)
        {
            try 
            {
                if([System.Array]$ErrorMessage = $this.IISWebSite | Where-Object {$_.ErrorMessage})
                {
                    [System.Management.Automation.PSSerializer]::Serialize($ErrorMessage) | Set-Content -Path "$(Get-Location)\Serialize\ErrorMessage.xml"
                    $this.log.WriteLog("SendMailMessage: Serialize 'ErrorMessage' variable",[severity]::Information)
                    [System.Management.Automation.PSSerializer]::Serialize($ErrorMessage.ErrorMessage) | Set-Content -Path "$(Get-Location)\Serialize\ErrorMessage_Message.xml"
                    $this.log.WriteLog("SendMailMessage: Serialize 'ErrorMessage_Message' variable",[severity]::Information)
                    [System.Management.Automation.PSSerializer]::Serialize($ErrorMessage.Probe) | Set-Content -Path "$(Get-Location)\Serialize\ErrorMessage_Probe.xml"
                    $this.log.WriteLog("SendMailMessage: Serialize 'ErrorMessage_Probe' variable",[severity]::Information)
                    $ErrorTable = $this.GetErrorTable(($ErrorMessage | Group-Object -Property SiteName, Farm_ID))
                    $this.log.WriteLog("SendMailMessage:Found Error!",[severity]::Information)

                }else
                {
                    $ErrorTable = $null
                    [System.Management.Automation.PSSerializer]::Serialize($ErrorMessage) | Set-Content -Path "$(Get-Location)\Serialize\ErrorMessage.xml"
                    $this.log.WriteLog("SendMailMessage: Serialize empty 'ErrorMessage' variable",[severity]::Information)
                    $this.log.WriteLog("SendMailMessage:All Web Sites are OK!",[severity]::Information)
                }
                if([System.Array]$NewWebSite = $this.WebSite_Sharepoint | Where-Object {$_.Status -eq "New"})
                {
                    $NewWebSiteTable = $this.GetNewWebSiteTable($newWebSite)
                }else
                {
                    $NewWebSiteTable = $null
                }
                if ($this.Server_Sharepoint_Maintenance) 
                {
                    $ServerMaintenanceTable = $this.GetServerMaintenanceTable()
                }
                else 
                {
                    $ServerMaintenanceTable = $null
                }
                if(($ErrorMessage -and !$ErrorMessage_Deserialize) -or (!$ErrorMessage -and $ErrorMessage_Deserialize) -or (($ErrorMessage -and $ErrorMessage_Deserialize) -and (Compare-Object -ReferenceObject $ErrorMessage -DifferenceObject $ErrorMessage_Deserialize)))
                {
                    $PostContent = "<div class='Notice'>Log <a href='$($this.log.logFolderPath -replace "^[a-z]:\\","\\$((Get-CimInstance win32_computersystem).Name).$((Get-CimInstance win32_computersystem).Domain)\")'>here</a><br />"
                    
                    if(!$ErrorMessage)
                    {
                        $ErrorTable = $this.GetErrorTable(($ErrorMessage_Deserialize| Group-Object -Property SiteName, Farm_ID),$ErrorMessage_Message_Deserialize,$ErrorMessage_Probe_Deserialize)
                        [string]$MailMessage = ConvertTo-HTML -Body "<h1>All web sites are <span id='InvertGreen'>ONLINE</span> </h1><h2>Last known error web sites:</h2>$ErrorTable$(if($NewWebSiteTable){"<h2>New web sites:</h2>$NewWebSiteTable"})$(if($ServerMaintenanceTable){"<h2>Servers in maintenance:</h2>$ServerMaintenanceTable"})" -Head $CSS_header -PostContent $PostContent
                    }
                    else 
                    {
                        [string]$MailMessage = ConvertTo-HTML -Body "<h1><span id='InvertRed'>OFFLINE</span> web sites found</h1><h2>Error web sites:</h2>$ErrorTable$(if($NewWebSiteTable){"<h2>New web sites:</h2>$NewWebSiteTable"})$(if($ServerMaintenanceTable){"<h2>Servers in maintenance:</h2>$ServerMaintenanceTable"})" -Head $CSS_header -PostContent $PostContent
                    }
                    #Uncomment
                    Send-MailMessage -Body $MailMessage -Subject "[$(if((Get-CimInstance win32_computersystem).Domain -eq "DS.KB.CZ") {"PROD"} else {"LAB"})] Monitoring web sites" -To $DefaultEmail -From "no@reply.cz" -SmtpServer $SmtpServer -BodyAsHtml
                    #
                    ## Testovani na serveru kde neni povolena smtp gateway
                    #Invoke-Command -ComputerName saplab629.dslab.kb.cz -ScriptBlock {Send-MailMessage -Body $using:MailMessage -Subject "[$(if((Get-CimInstance win32_computersystem).Domain -eq "DS.KB.CZ") {"PROD"} else {"LAB"})] Monitoring web sites" -To $using:DefaultEmail -From "no@reply.cz" -SmtpServer $using:SmtpServer -BodyAsHtml}                
                    ##
                    $this.log.WriteLog("SendMailMessage:Message was sent to $DefaultEmail!",[severity]::Information)
                    $uniqueEmailsAddress = [System.Collections.Generic.List[String]]::new()
                    $ErrorMessage.Email | Select-Object -Unique | ForEach-Object {$uniqueEmailsAddress.Add($_)}

                    if($uniqueEmailsAddress)
                    {
                        $uniqueEmailsAddress | ForEach-Object {
                            $uniqueEmailsAddres_item = $PSItem
                            $errorTable = $this.GetErrorTable(($ErrorMessage | Where-Object {$_.email -contains $uniqueEmailsAddres_item}))
                            if($errorTable)
                            {
                                $PostContent = "<div class='Notice'>Log <a href='$($this.log.logFolderPath -replace "^[a-z]:\\","\\$((Get-CimInstance win32_computersystem).Name).$((Get-CimInstance win32_computersystem).Domain)\")'>here</a><br />"
                                [string]$MailMessage = ConvertTo-HTML -Body "<h1><span id='InvertRed'>OFFLINE</span> web sites found</h1><h2>Error web sites:</h2>$ErrorTable$(if($NewWebSiteTable){"<h2>New web sites:</h2>$NewWebSiteTable"})" -Head $CSS_header -PostContent $PostContent
                                #
                                Send-MailMessage -Body $MailMessage -Subject "[$(if((Get-CimInstance win32_computersystem).Domain -eq "DS.KB.CZ") {"PROD"} else {"LAB"})] Monitoring web sites" -To $uniqueEmailsAddres_item -From "no@reply.cz" -SmtpServer $SmtpServer -BodyAsHtml
                                ## Testovani na serveru kde neni povolena smtp gateway
                                #Invoke-Command -ComputerName xxx -ScriptBlock {Send-MailMessage -Body $using:MailMessage -Subject "[$(if((Get-CimInstance win32_computersystem).Domain -eq "DS.KB.CZ") {"PROD"} else {"LAB"})] Monitoring Web Site" -To $using:uniqueEmailsAddres_item -From "no@reply.cz" -SmtpServer $using:SmtpServer -BodyAsHtml}                
                                ##
                                $this.log.WriteLog("SendMailMessage:Message was sent to $uniqueEmailsAddres_item!",[severity]::Information)
                            }
                        }
                    }
                }
            }
            catch 
            {
                $this.log.WriteLog("SendMailMessage:$($_.Exception.Message)",[severity]::Error)
            }
        }
    }
}
catch {
    $log.WriteLog("$($_.Exception.Message)",[severity]::Error)
}
#Load Variables
try
{
    #Module
    import-module -Name pnp.powershell
    $sharePoint_FieldSettings_RadioButtons = [Microsoft.SharePoint.Client.ChoiceFormatType]::RadioButtons
    #Assembly
    Add-Type -AssemblyName System.Web
    #
    $SharePointHashPassPath | ForEach-Object {$path = $_; Get-item -Path $path | Out-Null}
    #
    $sharedPointCredential = New-Object System.Management.Automation.PsCredential($SharePointUserAccountName,(Get-Content -Path $SharePointHashPassPath | ConvertTo-SecureString))
    # Comment if do not test
    #$sharedPointCredential = Get-Credential "l2_pcejka@ds.kb.cz"
    #CSS codes
    $CSS_header = @"
                <style>
                h1 {
                    font-family: Arial, Helvetica, sans-serif;
                    color: #3e3e3e;
                    font-size: 16px;
                }
                h2 {
                    font-family: Arial, Helvetica, sans-serif;
                    color: #4e4e4e;
                    font-size: 14px;
                }
                table {
                    font-size: 12px;
                    border: 2px;
                    font-family: Arial, Helvetica, sans-serif;
                } 
                td {
                    padding: 4px;
                    color: #5e5e5e;
                    margin: 0px;
                    border: 0;
                }
                th {
                    background: #3e3e3e;
                    color: #fff;
                    font-size: 11px;
                    text-transform: uppercase;
                    padding: 10px 15px;
                    vertical-align: middle;
                }
                #CreationDate {
                    font-family: Arial, Helvetica, sans-serif;
                    color: #703939;
                    font-size: 14px;
                    font-weight: bold;
                }
                #Notice {
                    font-family: Arial, Helvetica, sans-serif;
                    font-size: 12px;
                    font-style: italic;
                }
                #Green { color: Green; }
                #Orange { color: Orange; }
                #Red { color: DarkRed; }
                #InvertGreen {color: White; background-color: Green;font-weight:bold; }
                #InvertRed {color: White; background-color: DarkRed;font-weight:bold; }
                </style>
"@  
    $log.WriteLog("Variables were load successfully",[severity]::Information)
}
catch
{
    $log.WriteLog("Cannot load variable in path: $path exception: $_ ",[severity]::Error)
}
#Clear error history
if($Skip_Deserialize)
{ 
    try 
    {
        if(Test-Path -Path "$(Get-Location)\Serialize\ErrorMessage.xml")
        {
            Get-Item -path "$(Get-Location)\Serialize\ErrorMessage.xml" | Remove-Item
            $log.WriteLog("Deserialize: Remove: '$(Get-Location)\Serialize\ErrorMessage.xml'",[severity]::Information)
        }
    }
    catch 
    {
        $log.WriteLog("Deserialize: $($_.Exception.Message)",[severity]::Error)
    }
}
else 
{
    #Deserealize
    try{
        [System.Array]$ErrorMessage_Deserialize = [System.Management.Automation.PSSerializer]::Deserialize((Get-Content -Path "$(Get-Location)\Serialize\ErrorMessage.xml"))
        $log.WriteLog("Deserialize:'ErrorMessage_Deserialize'",[severity]::Information)
        [System.Array]$ErrorMessage_Message_Deserialize = [System.Management.Automation.PSSerializer]::Deserialize((Get-Content -Path "$(Get-Location)\Serialize\ErrorMessage_Message.xml"))
        $log.WriteLog("Deserialize:'ErrorMessage_Message_Deserialize'",[severity]::Information)
        [System.Array]$ErrorMessage_Probe_Deserialize = [System.Management.Automation.PSSerializer]::Deserialize((Get-Content -Path "$(Get-Location)\Serialize\ErrorMessage_Probe.xml"))
        $log.WriteLog("Deserialize:'ErrorMessage_Probe_Deserialize'",[severity]::Information)
    }
    catch{$log.WriteLog("Deserialize: '$_'",[severity]::Warning)}
}
#Main
try 
{
    $collection = [Collection]::new($log,$Proxy,$ProxyURL,$ThrottleLimit)
    #Create New List
    switch ($action) {
        monitor {   
            $log.WriteLog("Start check WebSite!",[severity]::Information)
            $collection.ImportFromSharepoint_List($sharedPointCredential,$SharePointSiteURL,"Servers","WebSite","WebApp","Check Probe File")
            $collection.GetRemoteData() 
            break}
        update { 
            $collection.ExportToSharepoint_NewWebAppList($sharedPointCredential,$SharePointSiteURL,$SharePointWebAppListName,$SharePointWebAppListURL,$SharePointTemplate,$sharePoint_FieldSettings_RadioButtons)
            $collection.ExportToSharepoint_NewWebSiteList($sharedPointCredential,$SharePointSiteURL,$SharePointWebSiteListName,$SharePointWebSiteListURL,$SharePointTemplate,$sharePoint_FieldSettings_RadioButtons,$SharePointWebAppListName)
            $log.WriteLog("Start check WebSite!",[severity]::Information)
            $collection.ImportFromSharepoint_List($sharedPointCredential,$SharePointSiteURL,"Servers","WebSite","WebApp","Check Probe File")
            $collection.GetRemoteData()
            $log.WriteLog("Start update Sharepoint list!",[severity]::Information)
            $collection.ExportToSharepoint_Data($sharedPointCredential,$SharePointSiteURL,$SharePointWebSiteListName,$SharePointWebAppListName)
            $collection.ImportFromSharepoint_List($sharedPointCredential,$SharePointSiteURL,"Servers","WebSite","WebApp","Check Probe File")
            break }
        Default {
            #$collection.ExportToSharepoint_NewWebAppList($sharedPointCredential,$SharePointSiteURL,$SharePointWebAppListName,$SharePointWebAppListURL,$SharePointTemplate,$sharePoint_FieldSettings_RadioButtons)
            #$collection.ExportToSharepoint_NewWebSiteList($sharedPointCredential,$SharePointSiteURL,$SharePointWebSiteListName,$SharePointWebSiteListURL,$SharePointTemplate,$sharePoint_FieldSettings_RadioButtons,$SharePointWebAppListName)        
            $log.WriteLog("Start check WebSite!",[severity]::Information)
            $collection.ImportFromSharepoint_List($sharedPointCredential,$SharePointSiteURL,"Servers","WebSite","WebApp","Check Probe File")
            $collection.GetRemoteData()
            #$log.WriteLog("Start update Sharepoint list!",[severity]::Information)
            #$collection.ExportToSharepoint_Data($sharedPointCredential,$SharePointSiteURL,$SharePointWebSiteListName,$SharePointWebAppListName)
            #$collection.ImportFromSharepoint_List($sharedPointCredential,$SharePointSiteURL,"Servers","WebSite","WebApp","Check Probe File")
        }
    }
    #Need SubSet Site
    $collection.GetWebFarmID()
    #Pair IDs
    $collection.GetWebAppID()
    $collection.GetWebSiteError()
    $collection.SendMailMessage($SmtpServer,$DefaultEmail,$csS_header,$ErrorMessage_Deserialize,$ErrorMessage_Message_Deserialize,$errorMessage_Probe_Deserialize,$SharePointSiteURL)
}
catch 
{
    $log.WriteLog("$($_.Exception.Message)",[severity]::Error)
}