# WebSite Monitoring Script

This repository folder contains the PowerShell script used to monitor IIS websites and synchronize their status with SharePoint.

## Contents

- `WebSite.ps1` — main monitoring script
- `Serialize/` — serialized backup XML data for SharePoint and error state

## Notes

- The script collects IIS website information from remote servers.
- It updates SharePoint lists with website and web application status.
- It sends email notifications when issues are detected.
