
<#PSScriptInfo

.VERSION 1.0.0.0

.GUID 8c752c62-b7af-452e-b399-f90002fc6710

.AUTHOR petr_cejka@kb.cz; a5320net@ds.kb.cz

.COMPANYNAME KB, a.s. - .NET MWS Team

.COPYRIGHT 

.TAGS 

.LICENSEURI 

.PROJECTURI 

.ICONURI 

.EXTERNALMODULEDEPENDENCIES 

.REQUIREDSCRIPTS 

.EXTERNALSCRIPTDEPENDENCIES 

.RELEASENOTES


#>
#Requires -PSEdition Desktop
#Requires -Version 5.1
#Requires -Modules KB-MWS
<# 

.DESCRIPTION 
    Generates and deploys a DSC Local Configuration Manager configuration for SMB clients. The script
    loads the client configuration data and SMB repository share, compiles the SMBClient configuration
    into MOF files, and applies those files to configure the local LCM. Server names can be supplied
    with -serverName; otherwise, configuration data is obtained from the client configuration data script.

.EXAMPLE
    .\SMBClient.ps1 -serverName "SERVER01", "SERVER02"

    Compiles and deploys the SMB client LCM configuration for the specified servers, using the default
    configuration file paths.

.EXAMPLE
    .\SMBClient.ps1 -serverName "SERVER01" `
        -configurationDataPath "D:\DSC\SMBClient.Configuration.ps1" `
        -SMBSharePath "D:\DSC\SMBSharePath.json" `
        -clientConfigurationDataScriptPath "D:\DSC\Get-Client.ps1" `
        -OutputMofFolderName "MOFClients-Test"

    Uses the specified configuration files and writes the generated MOFs to a folder named
    MOFClients-Test under the script directory.

#> 
Param(
    # Config File Name
    [ValidateNotNullOrEmpty()]
    [ValidateScript({Test-Path -Path $_})]
    [string]$ServerListPath,
    [ValidateNotNullOrEmpty()]
    [ValidateScript({Test-Path -Path $_})]
    [string]$configurationDataPath = "D:\App\NETMWS\DSC\Client\SMBClient.Configuration.ps1",
    [ValidateNotNullOrEmpty()]
    [ValidateScript({Test-Path -Path $_})]
    [string]$SMBSharePath = "D:\App\NETMWS\DSC\Client\SMBSharePath.json",
    [ValidateScript({Test-Path -Path $_})]
    [string]$clientConfigurationDataScriptPath = "D:\App\NETMWS\DSC\Client\Get-Client.ps1",
    $ErrorActionPreference = "Stop",
    [string[]]$serverName,
    [ValidateNotNullOrEmpty()]
    [string]$OutputMofFolderName = "MOFClients"
)

try 
{
    function MAIN
    {  
        
        #Script logic
        $log.WriteLog("Start processing configuration block!",[severity]::Information)
        # Import configuration data
        . $configurationDataPath
        $log.WriteLog("Configuration data imported successfully!",[severity]::Information)
        $OutputPath = Join-Path -Path $PSScriptRoot -ChildPath $OutputMofFolderName
        $log.WriteLog("Output path for MOF files set successfully! OutputPath: $OutputPath",[severity]::Information)
        
        # Compile configuration and generate MOFs
        $log.WriteLog("Configuration block was processed successfully!",[severity]::Information)
        $log.WriteLog("Start processing configuration block!",[severity]::Information)
        
        # Prepare LCM MOFs
        $share = Get-Content -Path $SMBSharePath -Raw | ConvertFrom-Json
        $log.WriteLog("Share for LCM configuration was set successfully! Share: $share",[severity]::Information)
        
        if($serverName)
        {
            $log.WriteLog("Server names provided via parameter: $($serverName -join ', ')", [Severity]::Information)
            $clientConfigurationData = & $clientConfigurationDataScriptPath -serverName $serverName
            $log.WriteLog("Client configuration data obtained from Get-Client.ps1 script.", [Severity]::Information)
            # Set the AllNodes property to an array of objects
            [object[]]$clientConfigurationData.AllNodes = $clientConfigurationData.AllNodes
        }
        elseif($clientConfigurationData = & $clientConfigurationDataScriptPath)
        {
            $log.WriteLog("Server names obtained from client configuration data script.", [Severity]::Information)
        }
        else
        {
            $log.WriteLog("No server names provided and client configuration data script did not return any servers.", [Severity]::Error)
        }
        # Trigger configuration compilation
        $log.WriteLog("Start processing configuration data block!",[severity]::Information) 
        
        # Compile configuration and generate MOFs
        SMBClient -RepositoryShare $share -ConfigurationData $ClientConfigurationData -OutputPath $OutputPath
        $log.WriteLog("Configuration block was processed successfully!",[severity]::Information)
        
        # Deploy LCM MOFs
        $log.WriteLog("Starting deployment of LCM MOFs!",[severity]::Information)
        Set-DscLocalConfigurationManager -Path $OutputPath -Verbose -Force
        $log.WriteLog("LCM MOFs deployed successfully!",[severity]::Information)
        <#
        #Check configuration on client
            $session = New-CimSession -ComputerName <servername>
            Get-DscLocalConfigurationManager -CimSession $session
            (Get-DscLocalConfigurationManager -CimSession $session).ResourceModuleManagers 
        
        #>
    }
}
catch 
{
    $log.WriteLog("An error occurred while processing the script: $PSItem",[severity]::Error)
}
#MyLogclass
try 
{
    [string]$logFolderRootPath = Join-Path -Path $PSScriptRoot -ChildPath 'Logs'
    [string]$logFileName = "SMBClient.log"
    Enum Severity
    {
            Error
            Information
            Warning
            Verbose
            Debug
        }
    # Import the KB-MWS module
    import-module -Name 'KB-MWS' -Force 
    # Define a logging class to handle log messages
    class Log
    {
            [string]$logFolderPath
            [string]$logFileName
            [Severity]$severity
            Log([string]$logFolderPath, [string]$logFileName)
            {
                $this.logFolderPath = $logFolderPath
                $this.logFileName = $logFileName
                $this.Severity = [Severity]::Information
            }
            # Method to write log messages with severity
            [void] WriteLog([string]$message, [Severity]$severity)
            {
                Write-kbLog -logFolderPath $this.logFolderPath -logFileName $this.logFileName -message $message -severity $severity -RotateLogs
            }
            # Overloaded method to write log messages with severity and server name
            [void] WriteLog([string]$server,[string]$message, [Severity]$severity)
            {
                Write-kbLog -logFolderPath $this.logFolderPath -logFileName $this.logFileName -message $message -severity $severity -Server $server -RotateLogs
            }
        }
    [Log]$log = [Log]::new($logFolderRootPath, $logFileName)    
    $log.WriteLog("Start processing SMBPullServer script!",[severity]::Information) 
    $log.WriteLog("Loging class instance LOG was set successfully!",[severity]::Information) 
}
catch 
{
    throw "An error occurred while processing the script: $PSItem"
}
try
{
    $log.WriteLog("Starting MAIN function!",[severity]::Information)
    Main
    $log.WriteLog("MAIN function executed successfully!",[severity]::Information)
}
catch 
{
    $log.WriteLog("An error occurred while processing the script: $PSItem",[severity]::Error)
}
finally 
{
    $log.WriteLog("Finished processing SMBClient script!",[severity]::Information)
}



