# DSC Client Configuration

`SMBClient.ps1` compiles DSC Local Configuration Manager (LCM) settings for client nodes and applies them using `Set-DscLocalConfigurationManager`.

## Requirements

- Windows PowerShell 5.1 Desktop
- The `KB-MWS` module
- Existing configuration, share JSON, and client-data files
- Appropriate permissions to configure the local LCM

## Usage

Run from this folder:

```powershell
.\SMBClient.ps1
```

To target specific servers through the client-data script:

```powershell
.\SMBClient.ps1 -serverName 'SERVER01','SERVER02'
```

To provide alternate input paths:

```powershell
.\SMBClient.ps1 `
    -configurationDataPath 'D:\App\NETMWS\DSC\Client\SMBClient.Configuration.ps1' `
    -SMBSharePath 'D:\App\NETMWS\DSC\Client\SMBSharePath.json' `
    -clientConfigurationDataScriptPath 'D:\App\NETMWS\DSC\Client\Get-Client.ps1'
```

## Parameters

| Parameter | Default | Purpose |
|---|---|---|
| `ServerListPath` | `D:\App\NETMWS\Monitoring\Tasks\servers-deploy.csv` | Server-list path; accepted by the script but not directly used in its current flow. |
| `configurationDataPath` | `D:\App\NETMWS\DSC\Client\SMBClient.Configuration.ps1` | PowerShell configuration script to load. |
| `SMBSharePath` | `D:\App\NETMWS\DSC\Client\SMBSharePath.json` | JSON file containing the repository share value passed to the DSC configuration. |
| `clientConfigurationDataScriptPath` | `D:\App\NETMWS\DSC\Client\Get-Client.ps1` | Script that supplies node configuration data. |
| `serverName` | None | Optional server names passed to the client-data script. |
| `OutputMofFolderName` | `MOFClients` | Output folder for generated MOF files, relative to this script’s folder. |

## Processing

1. Loads the DSC configuration script and reads the repository share from the JSON file.
2. Gets node data from `Get-Client.ps1`, optionally passing the supplied server names.
3. Compiles LCM MOF files into the output folder.
4. Runs `Set-DscLocalConfigurationManager` against that output folder.

Logs are written to `Client\Logs\SMBClient.log`. Check the log if configuration or LCM application fails.