[DscLocalConfigurationManager()]
Configuration SMBClient
{
    param(
            [Parameter(Mandatory = $true)]
            [string] $RepositoryShare
        )
    Node $AllNodes.NodeName
    {
        Settings
        {
            RefreshMode = 'Pull'
            ConfigurationID = $Node.Guid
            ConfigurationMode = 'ApplyAndAutoCorrect'
            ConfigurationModeFrequencyMins = 15
            RefreshFrequencyMins = 30
            RebootNodeIfNeeded = $false
            ActionAfterReboot = 'ContinueConfiguration'
        }
        ConfigurationRepositoryShare SMBRepository
        {
            SourcePath = Join-Path -Path $RepositoryShare -ChildPath "Configuration"
        }

        ResourceRepositoryShare SMBRepository
        {
            SourcePath = Join-Path -Path $RepositoryShare -ChildPath "Modules"
        }
    }
}