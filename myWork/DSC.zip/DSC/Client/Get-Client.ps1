
<#PSScriptInfo

.VERSION 1.0.0.0

.GUID 24d53c1e-540c-4b42-8410-45de77efb379

.AUTHOR petr_cejka@kb.cz; a5320net@ds.kb.cz

.COMPANYNAME KB, a.s. - .NET MWS Team

.COPYRIGHT 

.TAGS 

.LICENSEURI 

.PROJECTURI 

.ICONURI 

.EXTERNALMODULEDEPENDENCIES 

.REQUIREDSCRIPTS 

.EXTERNALSCRIPTDEPENDENCIES 

.RELEASENOTES  

#>
#Requires -PSEdition Desktop
#Requires -Modules ActiveDirectory
#Requires -Version 5.1

<# 
.SYNOPSIS
Retrieves client information and builds the DSC configuration data for one or more servers.

.DESCRIPTION
This script reads a list of server names from either the -serverName parameter or a CSV file defined by
-ServerListPath. For each server, it queries Active Directory to retrieve the computer ObjectGUID and
creates the configuration data structure used by the DSC deployment workflow.

The script is intended to prepare the nodes for an LCM MOF configuration and can be used as a helper
for client inventory and deployment automation.

.EXAMPLE
.\Get-Client.ps1 -ServerListPath "D:\App\NETMWS\Monitoring\Tasks\servers-deploy.csv"

.EXAMPLE
.\Get-Client.ps1 -serverName "SAPLAB001","SAPLAB002"

#> 
Param(
    # Config File Name
    [ValidateNotNullOrEmpty()]
    [ValidateScript({Test-Path -Path $_})]
    [string]$ServerListPath = "D:\App\NETMWS\Monitoring\Tasks\servers-deploy.csv",
    $ErrorActionPreference = "Stop",
    [Parameter(
                ValueFromPipeline=$true,
                ValueFromPipelineByPropertyName=$true, 
                Position=0,
                ParameterSetName='Parameter Set 1')]
    [string[]]$serverName
)
begin 
{
    try 
    {
        function MAIN
        {  
            $log.WriteLog("Global configuration was set successfully!",[severity]::Information)
            if ($serverName) 
            {
                $servers = $serverName | ForEach-Object { [PSCustomObject]@{ server = $_ } }
            } 
            else 
            {
                $servers = Import-Csv -Path $ServerListPath -Delimiter ';'
            }
            # Prepare LCM MOFs
            $ConfigurationData = @{
                AllNodes = foreach ($server in $servers.server) {
                    @{
                        NodeName = $server
                        Guid     = (Get-ADComputer -Identity $server -Properties ObjectGUID).ObjectGUID.Guid
                    }
                }
            }

            return $ConfigurationData
        }
    }
    catch 
    {
        $log.WriteLog("An error occurred while processing the script: $PSItem",[severity]::Error)
    }
    #MyLogclass
    try 
    {
        [string]$logFolderRootPath = Join-Path -Path $PSScriptRoot -ChildPath 'Logs'
        [string]$logFileName = "Get-Client.log"
        # Define an enumeration for log severity levels
        Enum Severity
        {
            Error
            Information
            Warning
            Verbose
            Debug
        }
        # Import the KB-MWS module
        import-module -Name 'KB-MWS' -Force 
        # Define a logging class to handle log messages
        class Log
        {
            [string]$logFolderPath
            [string]$logFileName
            [Severity]$severity
            Log([string]$logFolderPath, [string]$logFileName)
            {
                $this.logFolderPath = $logFolderPath
                $this.logFileName = $logFileName
                $this.Severity = [Severity]::Information
            }
            # Method to write log messages with severity
            [void] WriteLog([string]$message, [Severity]$severity)
            {
                Write-kbLog -logFolderPath $this.logFolderPath -logFileName $this.logFileName -message $message -severity $severity -RotateLogs 
            }
            # Overloaded method to write log messages with severity and server name
            [void] WriteLog([string]$server,[string]$message, [Severity]$severity)
            {
                Write-kbLog -logFolderPath $this.logFolderPath -logFileName $this.logFileName -message $message -severity $severity -Server $server -RotateLogs
            }
        }
        [Log]$log = [Log]::new($logFolderRootPath, $logFileName)
        $log.WriteLog("Start processing Get-Client script!",[severity]::Information) 
        $log.WriteLog("Loging class instance LOG was set successfully!",[severity]::Information) 
    }
    catch 
    {
        throw "An error occurred while processing the script: $PSItem"
    }
}
process 
{
    try
    {
        Main
    }
    catch 
    {
        $log.WriteLog("An error occurred while processing the script: $PSItem",[severity]::Error)
    }
    finally 
    {
        $log.WriteLog("Finished processing Get-Client script!",[severity]::Information)
    }

}
end {
    $log.WriteLog("End of Get-Client script execution.",[severity]::Information)
}