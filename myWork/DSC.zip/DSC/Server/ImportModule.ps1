
<#PSScriptInfo

.VERSION 1.0.0.0

.GUID 85d312a0-7a9d-429e-8512-68d4a5a5547e

.AUTHOR petr_cejka@kb.cz; a5320net@ds.kb.cz

.COMPANYNAME KB, a.s. - .NET MWS Team

.COPYRIGHT 

.TAGS 

.LICENSEURI 

.PROJECTURI 

.ICONURI 

.EXTERNALMODULEDEPENDENCIES 

.REQUIREDSCRIPTS 

.EXTERNALSCRIPTDEPENDENCIES 

.RELEASENOTES
- Initial release of the ImportModule script

#>
#Requires -PSEdition Desktop
#Requires -Version 5.1
#Requires -Modules KB-MWS
<# 
.DESCRIPTION 
 This script manages the importing and installation of PowerShell modules for the KB, a.s. - .NET MWS Team environment.

Primary Functions:
- Imports modules from a specified source folder to the system's PowerShell module path
- Implements automatic module installation and verification
- Provides comprehensive logging of all operations
- Handles duplicate module detection and skipping

Parameters:
    PSModuleFolderName
        - Default: "PSModules"
        - Source directory containing modules to be imported
        - Must exist in the script's root directory

Directory Structure:
    Root/
    ├── PSModules/
    │   └── [Module Folders]
    └── Logs/
        └── YYYY_MM_DD_ImportModule.log

Logging Features:
- Creates dated log files with detailed operation tracking
- Supports multiple severity levels:
  - Error
  - Information
  - Warning
- Includes timestamp and user context in logs
- Provides both console and file output

Error Handling:
- Validates source module folder existence
- Checks for destination folder conflicts
- Implements comprehensive exception management
- Provides detailed error logging and reporting

Module Installation Process:
1. Validates source module folder
2. Checks for existing module installation
3. Copies modules to system PowerShell module path
4. Logs all operations and any errors encountered

The script maintains idempotency by checking for existing modules before installation 
and provides detailed feedback through its logging system. 

#> 
Param(
    # Config File Name
    [ValidateNotNullOrEmpty()]
    [ValidateScript({Test-Path -Path "$(Join-Path -Path $PSScriptRoot -ChildPath $PSModuleFolderName)"})]
    [string]$PSModuleFolderName = "PSModules",
    $ErrorActionPreference = "Stop"
    )
try 
{
    function Main {
        $log.WriteLog("Expanding module archives in $PSModuleFolderName",[severity]::Information)
        Get-ChildItem -Path (Join-Path -Path $PSScriptRoot -ChildPath $PSModuleFolderName) -Filter *.zip | Expand-Archive -DestinationPath (Join-Path -Path $PSScriptRoot -ChildPath $PSModuleFolderName) -Force
        # Import each module found in the PSModuleFolderName
        $log.WriteLog("Importing modules from $PSModuleFolderName",[severity]::Information)
        Get-ChildItem -Path (Join-Path -Path $PSScriptRoot -ChildPath $PSModuleFolderName) | ForEach-Object {
            $destinationFolder = Join-Path -Path ([Environment]::GetEnvironmentVariable('PSModulePath').split(';')[1]) -ChildPath $PSItem.Name
            if (-not (Test-Path -Path $destinationFolder)) 
            {
                $log.WriteLog("Copying module $($PSItem.Name) to $destinationFolder",[severity]::Information)
                Copy-Item -Path $_.FullName -Destination (Split-Path -Path $destinationFolder) -Recurse -Force
            }
            else 
            {
                $log.WriteLog("Destination folder $destinationFolder exist. Skipping module $($PSItem.Name).",[severity]::Information)
            }
        }
        $log.WriteLog("All modules imported successfully from $PSModuleFolderName",[severity]::Information) 
    }
}
catch 
{
    $log.WriteLog("An error occurred in the Main function: $($_.Exception.Message)",[severity]::Error)
}
#MyLogclass
try 
{
    [string]$logFolderRootPath = Join-Path -Path $PSScriptRoot -ChildPath 'Logs'
    [string]$logFileName = "ImportModule.log"
    Enum Severity
    {
            Error
            Information
            Warning
            Verbose
            Debug
    }
    # Import the KB-MWS module
    import-module -Name 'KB-MWS' -Force 
    # Define a logging class to handle log messages
    class Log
    {
        [string]$logFolderPath
        [string]$logFileName
        [Severity]$severity
        Log([string]$logFolderPath, [string]$logFileName)
        {
            $this.logFolderPath = $logFolderPath
            $this.logFileName = $logFileName
            $this.Severity = [Severity]::Information
        }
        # Method to write log messages with severity
        [void] WriteLog([string]$message, [Severity]$severity)
        {
            Write-kbLog -logFolderPath $this.logFolderPath -logFileName $this.logFileName -message $message -severity $severity -RotateLogs
        }
        # Overloaded method to write log messages with severity and server name
        [void] WriteLog([string]$server,[string]$message, [Severity]$severity)
        {
            Write-kbLog -logFolderPath $this.logFolderPath -logFileName $this.logFileName -message $message -severity $severity -Server $server -RotateLogs
        }
    }
    [Log]$log = [Log]::new($logFolderRootPath, $logFileName)    
    $log.WriteLog("Start processing ImportModule script!",[severity]::Information) 
    $log.WriteLog("Loging class instance LOG was set successfully!",[severity]::Information) 
}
catch 
{
    throw "An error occurred while processing the script: $PSItem"
}
#Main
try 
{
    Main
}
catch 
{
    $log.WriteLog("An error occurred in the Main function: $($_.Exception.Message)",[severity]::Error)
}