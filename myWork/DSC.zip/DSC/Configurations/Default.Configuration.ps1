configuration DefaultConfiguration
{
    param([string[]] $computerName)

    Import-DscResource -ModuleName 'PSDesiredStateConfiguration'

    node $computerName
    {
        # KB-MWS module deployment
        Script KB-MWS
        {
            GetScript  = { @{ Result = "N/A" } }
            TestScript = {
                $result = robocopy `
                "\\SAPLAB916.dslab.kb.cz\DSCRepository\Source\KB-MWS\KB-MWS" `
                "C:\Program Files\WindowsPowerShell\Modules\KB-MWS" `
                /MIR /L /NJH /NJS /NS /NC

                # robocopy exit codes:
                # 0 = no differences
                # 1 = files copied (difference existed)
                $LASTEXITCODE -eq 0
            }
            SetScript = {
                robocopy `
                  "\\SAPLAB916.dslab.kb.cz\DSCRepository\Source\KB-MWS\KB-MWS" `
                  "C:\Program Files\WindowsPowerShell\Modules\KB-MWS" `
                  /MIR /R:2 /W:2 /NFL /NDL
            }
        }
        # KB-MWSRemote module deployment
        Script KB-MWSRemote
        {
            GetScript  = { @{ Result = "N/A" } }
            TestScript = {
                $result = robocopy `
                "\\SAPLAB916.dslab.kb.cz\DSCRepository\Source\KB-MWSRemote\KB-MWSRemote" `
                "C:\Program Files\WindowsPowerShell\Modules\KB-MWSRemote" `
                /MIR /L /NJH /NJS /NS /NC

                # robocopy exit codes:
                # 0 = no differences
                # 1 = files copied (difference existed)
                $LASTEXITCODE -eq 0
            }
            SetScript = {
                robocopy `
                  "\\SAPLAB916.dslab.kb.cz\DSCRepository\Source\KB-MWSRemote\KB-MWSRemote" `
                  "C:\Program Files\WindowsPowerShell\Modules\KB-MWSRemote" `
                  /MIR /R:2 /W:2 /NFL /NDL
            }
        }
        # KB-MWSCore module deployment
        Script KB-MWSCore
        {
            GetScript  = { @{ Result = "N/A" } }
            TestScript = {
                $result = robocopy `
                "\\SAPLAB916.dslab.kb.cz\DSCRepository\Source\KB-MWSCore\KB-MWSCore" `
                "C:\Program Files\PowerShell\Modules\KB-MWSCore" `
                /MIR /L /NJH /NJS /NS /NC

                # robocopy exit codes:
                # 0 = no differences
                # 1 = files copied (difference existed)
                $LASTEXITCODE -eq 0
            }
            SetScript = {
                robocopy `
                  "\\SAPLAB916.dslab.kb.cz\DSCRepository\Source\KB-MWSCore\KB-MWSCore" `
                  "C:\Program Files\PowerShell\Modules\KB-MWSCore" `
                  /MIR /R:2 /W:2 /NFL /NDL
            }
        }

    }
}
# SIG # Begin signature block
# MIISUgYJKoZIhvcNAQcCoIISQzCCEj8CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUSu2Ks6YUtTX/Qc42oWP4Fh99
# /H6ggg83MIIGUTCCBDmgAwIBAgITGAAAAAPxHzKTREPq4gAAAAAAAzANBgkqhkiG
# 9w0BAQ0FADBeMQswCQYDVQQGEwJDWjEXMBUGA1UEYRMOTlRSQ1otNDUzMTcwNTQx
# HzAdBgNVBAoMFktvbWVyxI1uw60gYmFua2EsIGEucy4xFTATBgNVBAMTDEtCIFJv
# b3QgMyBDQTAeFw0yMTAzMTIxMjA2MzBaFw0zMTAzMTIxMjE2MzBaME0xCzAJBgNV
# BAYTAkNaMRwwGgYDVQQKExNLb21lcmNuaSBiYW5rYSBhLnMuMSAwHgYDVQQDExdL
# QiBJbnRlcm5pIENBIFRlY2huaWNrYTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCC
# AgoCggIBALAXa8OgCCIhwLkEcP4YZZCUnZAKr6AZaAI6NBBQdyAwQ3c7sOXyuz1e
# qLdu2QR/Mtueh49tDujlCZWtkOEAB9N23xW3icioQP7t2nQf2xw7Dg56zIV8bVAX
# aImBNKAUsL5tONBqGFE1WbKLwv1o8JoBzBiNssuMhP0v0L3s6DwfBYoEfRy2STJC
# 7/WWkKHLjMhF+eP+pEW50KvXjALbBXrcpSbz9ivDWKk64Lj2e2xwnPOEhrxrSJFn
# WmiFqu/i5i6AbIy9+8moKmP1G7/AvmCibif/XqFnG7Lm4z/FIb60meubnp+PDe3N
# WWn1svRJ8TicoZNhYoLiMHtV1IfcBkmk3BDklewQ0iBfd0Lr7J7xbTeJmLdWgjTd
# U9na+Z8Ljri70bcO5yoy6a6GFj4G5ogxqtL7U+U1GqYtftR79HtygOZ/WyiTqoQL
# VLpmL80107QsKOaVkCPPF/kC8XY65KqgsIfj4vBsvNiZnfLF0jk9enryXaKGHhIQ
# FrtmGon3VX+0n98oF3wPrt9GjFLExwigE0RKv8Y9az0Z2mNDkpwf/Z+s+pf9vP3U
# sE48aXFTEycuEgP28ArezVn2X+wCezKEtB8RI8lZgWLqOspMJqsyxAg8C6uLongt
# ZTWXJ0Bj6L02Fb6EYwdoCQS42b4n3j3xblbj5cOlD2XrdaMJcHzDAgMBAAGjggEX
# MIIBEzAOBgNVHQ8BAf8EBAMCAQYwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYE
# FC90+3iSVLobKF6Dw3BQmWkypwa8MBEGA1UdIAQKMAgwBgYEVR0gADAZBgkrBgEE
# AYI3FAIEDB4KAFMAdQBiAEMAQTASBgNVHRMBAf8ECDAGAQH/AgEAMB8GA1UdIwQY
# MBaAFPQ+2dWZi7przRUKmNiAxkcRmY+yMDAGA1UdHwQpMCcwJaAjoCGGH2h0dHA6
# Ly93d3cua2IuY3ovcGtpL3JjYWtiMy5jcmwwOwYIKwYBBQUHAQEELzAtMCsGCCsG
# AQUFBzAChh9odHRwOi8vd3d3LmtiLmN6L3BraS9yY2FrYjMuY3J0MA0GCSqGSIb3
# DQEBDQUAA4ICAQB7ey6Jb3Eg8v6Iba3oaYeUbwy4YnU8tv9HCtsON62E3/Zj5QwT
# OXW1u2cHtUCgJRM6m4BtVxi+S1KDOTmesb6Omz2Mj/l/93z/AIbnXG+/wAywNjhw
# r2IyF4VcNUfwDaPU6GS2DPJDiVUMXjWwuoH0cm5t5orfe5x96bHSRSyF/3Bd9ule
# Ki0EGoFnInEl2XZ8dNTzPu+bi87nhU07imbuE58jGgK5Qr2j8TcGK9lxEGuKDQNg
# 8mXD6qQBdenPK8ukjOpc4ZHEeanCHVkh6V8m9d5aDZ0thqEAEJG3YP3A1K8b96s+
# T45kIDPGpRuaOVw7RXc4artBQXWcmcR1L8PcLxE+sn249oWllTDh3VFCDqkVXIyu
# tNXnYDn2p4B+s6272Hcswa0OUO4XbvUm/VwPSURLMUVjePjmXv50BB4ef8lAytFN
# zA1gPSr/wW9cW39LDf8yFQrqijjLzYoACrIUa+YWVcrOqr26Iyx6VsBTjw+MWyN+
# UC40D/IXn0es0iuzlHyMFdhfchTEOJ85dvjT2M4DyszsGATj9RvN5wDfAlgl+Nru
# Hi89xIKZ7GwXz/2umvCdBp7pJYD1abMaqcbgJg9mQnvRquy2XupTzeUwWMA1cAZU
# L4zjNnwG6v3yvrnxzb9aV84JEOWRkV2L998iOxtVI3G3Dlyyi8fdvQneWDCCCN4w
# ggbGoAMCAQICE30AAXjsq3Lk/UZotXQAAAABeOwwDQYJKoZIhvcNAQELBQAwTTEL
# MAkGA1UEBhMCQ1oxHDAaBgNVBAoTE0tvbWVyY25pIGJhbmthIGEucy4xIDAeBgNV
# BAMTF0tCIEludGVybmkgQ0EgVGVjaG5pY2thMB4XDTI0MDEzMDE1MDg1OVoXDTI3
# MDEyOTE1MDg1OVowTzELMAkGA1UEBhMCQ1oxFzAVBgNVBAoTDktvbWVyY25pIGJh
# bmthMScwJQYDVQQDDB5ORVRNV1NfVGVhbV9TaWduaW5nQ2VydGlmaWNhdGUwggGi
# MA0GCSqGSIb3DQEBAQUAA4IBjwAwggGKAoIBgQDKum/YnkMJNS+yGqtDq+sf/XMI
# EsUoJUOlkKarGaGQr+rl/u2/nHkuTNeTS7EIkq+LlqQWMwsRKiiSNahAo1rNYWSi
# YC3fo7RyF1VliRRTx3SjoAGGbriIJkNeJdC/KPDDcHrLTOl7LIHlR5cx11EtEyjf
# RFOIU1rfFm4VgHO9URYdlVvFOrkydNoG09SBol26lb9tMTDodGKQXIJyg3D/rR0k
# LEUIt1/NuZ5gKOXVrFme5OICV7xfjBgnZoeQ/RE2HRQEarc0gPZaEJUPxjvKPQrh
# E2UCMmqtiRBa/BMETuZkEkiDmuW4dFUxmm6U8+ZWl3lZM0Ams4/dVK6wMLRYx9H7
# QmTbYpTgLNP3y1r5ATZ0ZeLKUDpzBBLM+JDcW6rBiOpzz6zAlKp/JBi3jqXQ5tHZ
# nFlXq9REMR92QMaDUZExXjkzI5LBQj7tIwD6/TRUFgy4Zy4CNr2lRcOD1ZvTNlI4
# 3hfmwKr6nuAGtbWWL5U8BZfbv6vC+xBnLc98JyUCAwEAAaOCBDMwggQvMA4GA1Ud
# DwEB/wQEAwIGwDCBlAYJKoZIhvcNAQkPBIGGMIGDMAsGCWCGSAFlAwQBKjALBglg
# hkgBZQMEAS0wCwYJYIZIAWUDBAEWMAsGCWCGSAFlAwQBGTALBglghkgBZQMEAQIw
# CwYJYIZIAWUDBAEFMAoGCCqGSIb3DQMHMAcGBSsOAwIHMA4GCCqGSIb3DQMCAgIA
# gDAOBggqhkiG9w0DBAICAgAwHQYDVR0OBBYEFHcz6TVvH6QWQWA0MEqyGcj9zPQK
# MBwGA1UdEQQVMBOBEWE1MzIwbmV0QGRzLmtiLmN6MB8GA1UdIwQYMBaAFC90+3iS
# VLobKF6Dw3BQmWkypwa8MIIBAQYDVR0fBIH5MIH2MIHzoIHwoIHthoHEbGRhcDov
# Ly9DTj1LQiUyMEludGVybmklMjBDQSUyMFRlY2huaWNrYSxDTj1TTUtCMTk1LENO
# PUNEUCxDTj1QdWJsaWMlMjBLZXklMjBTZXJ2aWNlcyxDTj1TZXJ2aWNlcyxDTj1D
# b25maWd1cmF0aW9uLERDPWRzLERDPWtiLERDPWN6P2NlcnRpZmljYXRlUmV2b2Nh
# dGlvbkxpc3Q/YmFzZT9vYmplY3RDbGFzcz1jUkxEaXN0cmlidXRpb25Qb2ludIYk
# aHR0cDovL3d3dy5rYi5jei9wa2kvY2FrYmludHRlY2guY3JsMIIBOgYIKwYBBQUH
# AQEEggEsMIIBKDCBvAYIKwYBBQUHMAKGga9sZGFwOi8vL0NOPUtCJTIwSW50ZXJu
# aSUyMENBJTIwVGVjaG5pY2thLENOPUFJQSxDTj1QdWJsaWMlMjBLZXklMjBTZXJ2
# aWNlcyxDTj1TZXJ2aWNlcyxDTj1Db25maWd1cmF0aW9uLERDPWRzLERDPWtiLERD
# PWN6P2NBQ2VydGlmaWNhdGU/YmFzZT9vYmplY3RDbGFzcz1jZXJ0aWZpY2F0aW9u
# QXV0aG9yaXR5MDAGCCsGAQUFBzAChiRodHRwOi8vd3d3LmtiLmN6L3BraS9jYWti
# aW50dGVjaC5jcnQwNQYIKwYBBQUHMAGGKWh0dHA6Ly9wa2lvY3NwLmtiLmN6L2Nh
# a2JpbnR0ZWNoL2FwaS9vY3NwMD0GCSsGAQQBgjcVBwQwMC4GJisGAQQBgjcVCIKY
# /SGHp9sogt2fGoHSy0mDo+54XYLsrHSBlOE3AgFkAgEDMCsGA1UdJQQkMCIGCisG
# AQQBgjcKAwEGCisGAQQBgjcCARUGCCsGAQUFBwMDMDcGCSsGAQQBgjcVCgQqMCgw
# DAYKKwYBBAGCNwoDATAMBgorBgEEAYI3AgEVMAoGCCsGAQUFBwMDMEAGA1UdIAQ5
# MDcwNQYOK4Ealc33PodoAQMBAwEwIzAhBggrBgEFBQcCARYVaHR0cHM6Ly9wa2ku
# a2IuY3ovcGtpMA0GCSqGSIb3DQEBCwUAA4ICAQAgyauxpY9LfFXEat4AJaAm2LPO
# 6QCHdkBOB6SsCymHnvD3nLTvqG+H0tpUgQzZ1e2QVlVfGhMJ3KIIWxcoYCCLz2ib
# MJwiooj+tZN/MR2u5sScMlQg45Smv918SVkNyAF4hNlDJlpR55kvSZdMxOQbarko
# xCiMcJcu/R6TSEQSNf3A/PEuqazBw+X0wCUEoUiGvb9ZALwVd9nWMzEkfLOwvoY1
# xQBsxFU9C83HHN8gFmbdSqI++eeCqPrvMx/to9SJLqAqOI+vzODG1FtJuiCyCDEo
# UxQlDwg89EnZ+yTBVRKoeQxDUAi47UhIFugiLu5mMtEt5cJpzsNgD1sUyhndaR9/
# LPwaYALLP+MKTSq0ODGRFPkrPS7kviEgCVxCqwATrCZVKmyU0R7kfnMSh/q8eIOq
# 4qqOOiX3EWg6c1dn5TCl+CQFfet0gptsqJGaP+r0gGJ3hsEmTtkxfttqkyuY72P1
# daewWJYuniKB0wbP6glXdj2tGHLvKyJpXHHZkKMsdUcEG55o9YOu5ioE0uUU/YNq
# ndFDJIqbaNnCwdU6QOIkjnv05E3w/MxcnMSy81uwJ2XJsWmNhRjIUiJ391lysRaQ
# /LVX8aD0NzfSFpMwEhC7TojTQWy9NBLQ+gi7BwdYoeDOpaw2WurSARCaACm7l8GU
# CSH47DKVukYpJcONvjGCAoUwggKBAgEBMGQwTTELMAkGA1UEBhMCQ1oxHDAaBgNV
# BAoTE0tvbWVyY25pIGJhbmthIGEucy4xIDAeBgNVBAMTF0tCIEludGVybmkgQ0Eg
# VGVjaG5pY2thAhN9AAF47Kty5P1GaLV0AAAAAXjsMAkGBSsOAwIaBQCgeDAYBgor
# BgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEE
# MBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBQs
# E19zpS5x3efOyqQxLrfMrQ5PGjANBgkqhkiG9w0BAQEFAASCAYCtdQ+hPispiZvO
# 62jCcdZxts8Tk4WB4+OHGc0B3GC49knUulpNTYdcMU88OJp8KIDCLkQ41uIZF2sp
# mP2jfAdyiagbKs67G682D5wWKKqVM+xUDGCV5HLAtvfwYvq5bcvZSMhP/9z7dJw1
# sSpkclA+6rR7TDbEWxMPgoI2+u2F6Asz15odBUw4604dGyBEy8lH5bwrF9Vstx6m
# AN4W4TD12dOmlLtO+GtB2DF+h0C+DruUtRRGH9snJ53duXk4s3Vm+snDaYusoDBE
# 9AdmGCIZX7Fm9a3uUfrdhAlBys30g9G1KF3SJ0wXoh7j400unryhBzB8GhE/a1Jq
# 72iebVFtcgCEzNnGuq+XnZ9yEaoWiwDJ31Zmr9rqeJIehqR5aRHiBABQDenRDEoB
# 2z+nFl564PFUiA9YqWs+PXc9mGF+LLOBXEVNOsKyvNzizvCiAYsNuGVkP7BX8506
# Pzp+T1MuzxP3mmRqgnZHmiks5W69pPyT6FpvMelu1wJv//oNZe0=
# SIG # End signature block
