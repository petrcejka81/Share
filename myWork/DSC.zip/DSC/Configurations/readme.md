# DSC Client Configurations

`Configuration.ps1` generates DSC MOF files for client computers and publishes them to the pull server configured in `SMBConfig.xml`.

## Requirements

- Windows PowerShell 5.1 Desktop
- The `KB-MWS` module
- Valid configuration data and client-list scripts
- Access to the configured DSC pull server

## Usage

Run from this folder:

```powershell
.\Configuration.ps1
```

By default, the script gets client data by running `D:\App\NETMWS\DSC\Client\Get-Client.ps1`, generates MOF files using `Default.Configuration.ps1`, and publishes them to the pull server.

To specify computers directly:

```powershell
.\Configuration.ps1 -serverName 'SAPLAB001','SAPLAB002'
```

To override paths:

```powershell
.\Configuration.ps1 `
    -configurationDataPath 'D:\App\NETMWS\DSC\Configurations\Default.Configuration.ps1' `
    -clientConfigurationDataScriptPath 'D:\App\NETMWS\DSC\Client\Get-Client.ps1' `
    -SMBConfigPAth 'D:\App\NETMWS\DSC\Server\SMBConfig.xml' `
    -OutputMofFolderName 'MOFClients'
```

## Parameters

| Parameter | Default | Purpose |
|---|---|---|
| `logFolderPath` | `R:\LogFiles\NETMWS\DSC` | Log folder. |
| `logFileName` | `Configuration.log` | Log file name. |
| `configurationDataPath` | `D:\App\NETMWS\DSC\Configurations\Default.Configuration.ps1` | Configuration data script to load. |
| `clientConfigurationDataScriptPath` | `D:\App\NETMWS\DSC\Client\Get-Client.ps1` | Script that supplies client configuration data when `-serverName` is not provided. |
| `ServerListPath` | `D:\App\NETMWS\Monitoring\Tasks\servers-deploy.csv` | Currently logged by the script, but not used to load the server list. |
| `serverName` | None | Optional list of computer names to configure. |
| `SMBConfigPAth` | `D:\App\NETMWS\DSC\Server\SMBConfig.xml` | Pull server XML configuration file. |
| `OutputMofFolderName` | `MOFClients` | Output folder for generated MOFs, relative to this script’s folder. |

## Output and processing

- Generated MOF files are written to the `OutputMofFolderName` folder.
- MOFs are published to the pull server’s configuration path.
- Published MOFs are renamed to each node’s GUID; a node-name symbolic link is also created.
- Logs are written using the configured log folder and file name.

Review the configuration data, client list, and pull server settings before running. The script requires paths to its configuration and client-data scripts to exist.