<#PSScriptInfo

.VERSION 1.0.0.0

.GUID eed929cf-aff2-4f9c-bc75-9401749ee760

.AUTHOR petr_cejka@kb.cz; a5320net@ds.kb.cz

.COMPANYNAME KB, a.s. - .NET MWS Team

.COPYRIGHT 

.TAGS 

.LICENSEURI 

.PROJECTURI 

.ICONURI 

.EXTERNALMODULEDEPENDENCIES 

.REQUIREDSCRIPTS 

.EXTERNALSCRIPTDEPENDENCIES 

.RELEASENOTES


#>
#Requires -PSEdition Desktop
#Requires -Version 5.1
#Requires -Modules KB-MWS
<# 
.SYNOPSIS
Creates and publishes DSC MOF configuration files for the specified client computers.

.DESCRIPTION
This script prepares the configuration data for DSC clients, imports the default configuration,
requests the client list from Get-Client.ps1 or from the provided server list, generates MOF files,
publishes them to the pull server, and renames them according to each node GUID.

The script is intended for automated DSC client onboarding and deployment across managed servers.


.EXAMPLE
.\Configuration.ps1 -serverName "SAPLAB001","SAPLAB002"

.EXAMPLE
.\Configuration.ps1 -ServerListPath "D:\App\NETMWS\Monitoring\Tasks\servers-deploy.csv"

#> 
Param(
    [ValidateNotNullOrEmpty()]
    $logFolderPath = "R:\LogFiles\NETMWS\DSC",
    [ValidateNotNullOrEmpty()]
    [ValidatePattern('^[\w,\s-]+\.[A-Za-z]{3}$')]
    [string]$logFileName = "Configuration.log",
    $ErrorActionPreference = 'Stop',
    [ValidateNotNullOrEmpty()]
    [ValidateScript({Test-Path -Path $_})]
    [string]$configurationDataPath = "D:\App\NETMWS\DSC\Configurations\Default.Configuration.ps1",
    [ValidateNotNullOrEmpty()]
    [ValidateScript({Test-Path -Path $_})]
    [string]$clientConfigurationDataScriptPath = "D:\App\NETMWS\DSC\Client\Get-Client.ps1",
    [ValidateNotNullOrEmpty()]
    [ValidateScript({Test-Path -Path $_})]
    [string]$ServerListPath = "D:\App\NETMWS\Monitoring\Tasks\servers-deploy.csv",
    [string[]]$serverName,
    [ValidateNotNullOrEmpty()]
    [ValidateScript({Test-Path -Path $_})]
    [string]$SMBConfigPAth ="D:\App\NETMWS\DSC\Server\SMBConfig.xml",
    [ValidateNotNullOrEmpty()]
    [string]$OutputMofFolderName = "MOFClients"
)

try
{
    # Define an enumeration for log severity levels
    Enum Severity
    {
        Error
        Information
        Warning
        Verbose
        Debug
    }
    # Import the KB-MWS module
    import-module -Name 'KB-MWS' -Force 
    # Define a logging class to handle log messages
    class Log
    {
        [string]$logFolderPath
        [string]$logFileName
        [Severity]$severity
        Log([string]$logFolderPath, [string]$logFileName)
        {
            $this.logFolderPath = $logFolderPath
            $this.logFileName = $logFileName
            $this.Severity = [Severity]::Information
        }
        # Method to write log messages with severity
        [void] WriteLog([string]$message, [Severity]$severity)
        {
            Write-kbLog -logFolderPath $this.logFolderPath -logFileName $this.logFileName -message $message -severity $severity -RotateLogs
        }
        # Overloaded method to write log messages with severity and server name
        [void] WriteLog([string]$server,[string]$message, [Severity]$severity)
        {
            Write-kbLog -logFolderPath $this.logFolderPath -logFileName $this.logFileName -message $message -severity $severity -Server $server -RotateLogs
        }
    }
    # Initialize logging
    [Log]$log = [Log]::new($logFolderPath, $logFileName)
    $log.WriteLog("Starting Configuration.ps1 script execution.", [Severity]::Information)
    $log.WriteLog("Log folder path: $logFolderPath", [Severity]::Information)
    $log.WriteLog("Log file name: $logFileName", [Severity]::Information)
    $log.WriteLog("Configuration data path: $configurationDataPath", [Severity]::Information)
    $log.WriteLog("Client configuration data script path: $clientConfigurationDataScriptPath", [Severity]::Information)
    $log.WriteLog("Server list path: $ServerListPath", [Severity]::Information)
    $log.WriteLog("Server names: $($serverName -join ', ')", [Severity]::Information)
    $log.WriteLog("SMB config path: $SMBConfigPAth", [Severity]::Information)
    $log.WriteLog("Output MOF folder name: $OutputMofFolderName", [Severity]::Information)
    # Import configuration data
    $log.WriteLog("Importing configuration data from path: $configurationDataPath", [Severity]::Information)
    . $configurationDataPath
    $log.WriteLog("Configuration data imported successfully.", [Severity]::Information)
    if($serverName)
    {
        $log.WriteLog("Server names provided via parameter: $($serverName -join ', ')", [Severity]::Information)
        $clientConfigurationData = & $clientConfigurationDataScriptPath -serverName $serverName
    }
    elseif($clientConfigurationData = & $clientConfigurationDataScriptPath)
    {
        
        $log.WriteLog("Server names obtained from client configuration data script.", [Severity]::Information)
    }
    else
    {
        $log.WriteLog("No server names provided and client configuration data script did not return any servers.", [Severity]::Error)
    }
    $computers = $clientConfigurationData.AllNodes.nodename
    $OutputPath = Join-Path -Path $PSScriptRoot -ChildPath $OutputMofFolderName
    # Prepare MOFs
    $log.WriteLog("Preparing MOFs for computers: $computers", [Severity]::Information)
    DefaultConfiguration -computerName $computers -OutputPath $OutputPath
    $log.WriteLog("MOFs prepared successfully at path: $OutputPath", [Severity]::Information)
    
    # Copy MOFs to the repository
    $log.WriteLog("Publishing MOFs to pull server using configuration path: $SMBConfigPAth", [Severity]::Information)
    Get-ChildItem -Path $OutputPath -File -Filter *.mof |
        Where-Object Name -NotLike *.meta.mof |
        Publish-MofToPullServer -PullServerWebConfig $SMBConfigPAth
    $log.WriteLog("MOFs published successfully to pull server.", [Severity]::Information)
    # Rename MOFs to Node GUIDs
    $log.WriteLog("Renaming MOFs to Node GUIDs.", [Severity]::Information)
    [string] $ConfigDirectory = (Select-Xml -Path $SMBConfigPAth -XPath '/configuration/appSettings/add[@key="ConfigurationPath"]/@value').Node.Value
    [hashtable[]] $nodes = $clientConfigurationData.AllNodes

    Push-Location -Path $configDirectory
    foreach($node in $nodes)
    {
        try
        {
            $nodeGuid = [Guid]::Parse($node.Guid)
            $log.WriteLog("Renaming MOF for node '$($node.NodeName)' to GUID: $($node.Guid)", [Severity]::Information)
            Move-Item -Path ($node.NodeName + '.mof') -Destination ($node.Guid + '.mof') -Force 
            Move-Item -Path ($node.NodeName + '.mof.checksum') -Destination ($node.Guid + '.mof.checksum') -Force 
            New-Item -name ($node.NodeName) -ItemType SymbolicLink -Value ($node.Guid + '.mof')  -Force | out-null
            $log.WriteLog("MOF for node '$($node.NodeName)' renamed to GUID: $($node.Guid) successfully.", [Severity]::Information)
        }
        catch
        {
            $log.WriteLog("An unexpected error occurred while processing node '$($node.NodeName)': $($_.Exception.Message)", [Severity]::Warning)
        }
    }
    Pop-Location
    $log.WriteLog("MOFs renamed to Node GUIDs successfully.", [Severity]::Information)
    # Trigger configuration update and remediation on target computers
    <#
        # Trigger configuration update
        Update-DscConfiguration -ComputerName $computers -Wait -Verbose

        # Trigger configuration remediation
        Start-DscConfiguration -ComputerName $computers -Wait -Verbose -UseExisting

        # Check the state
        Test-DscConfiguration -ComputerName $computers -Detailed
    #>
}
catch
{
    $log.WriteLog("An error occurred while executing the script.", [Severity]::Error)
    $log.WriteLog($_.Exception.Message, [Severity]::Error)
}



