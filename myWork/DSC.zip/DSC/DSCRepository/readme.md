# DSC Repository

This folder contains the files served by the SMB-based DSC pull server. Its location is configured by the `RootPath` value in `SMBConfig.xml`.

## Subfolders

### `Modules`

Contains PowerShell modules made available to DSC nodes. The `SMBPullServer.ps1` script checks modules in the configured `PSModules` source folder and publishes available modules to the pull server.

Add or update modules in the source folder, then run the script to publish them. Ensure required modules are installed locally so the script can find them.

### `Configuration`

Contains DSC configuration files, such as compiled MOF files, used by nodes that retrieve configurations from the pull server. The server configuration or deployment process populates this folder.

## Using the repository

1. Set `RootPath` in `SMBConfig.xml` to the full path of this repository.
2. Place publishable modules in the `PSModules` source folder.
3. Run `SMBPullServer.ps1` from the `Server` folder with administrator privileges.
4. Configure DSC nodes to use this pull server and request their assigned configurations.

Keep the `Modules` and `Configuration` folders in place; the DSC configuration manages the repository structure and permissions.

## SMB configuration

`Server\SMBConfig.xml` defines the repository root and the paths to the configuration and module folders:

```xml
<configuration>
  <appSettings>
    <add key="RootPath" value="REPLACE_WITH_DSC_REPOSITORY_ROOT" />
    <add key="ConfigurationPath" value="REPLACE_WITH_CONFIGURATION_FOLDER_PATH" />
    <add key="ModulePath" value="REPLACE_WITH_MODULES_FOLDER_PATH" />
  </appSettings>
</configuration>
```

Update these values if the repository is located elsewhere. The `Source` folder is under `RootPath` and is not configured as a separate XML setting.