<#PSScriptInfo

.VERSION 1.0.0.1

.GUID 79e41a42-70c1-49b1-9a33-16550d21f3e6

.AUTHOR petr_cejka@kb.cz; a5320net@ds.kb.cz

.COMPANYNAME KB, a.s. - .NET MWS Team

.COPYRIGHT

.TAGS

.LICENSEURI

.PROJECTURI

.ICONURI

.EXTERNALMODULEDEPENDENCIES 

.REQUIREDSCRIPTS

.EXTERNALSCRIPTDEPENDENCIES

.RELEASENOTES


.PRIVATEDATA

#>
#Requires -PSEdition Core 

<# 

.DESCRIPTION 
 The script is used to automate the secure processing of reports from GPE 

#> 
Param(
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [ValidateScript({Test-Path -Path $_ -PathType Container})]
        [string]$OpenSSLFolder_Path = "C:\'Program Files'\OpenSSL-Win64\bin",
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [ValidateScript({Test-Path -Path $_ -PathType Leaf})]
        [string]$rsa_gpe_public_key_prod = "$(Split-path  -path (Split-Path -Path (Get-location)))\Technical\Keys\rsa_public_prod\rsa_public_prod.pem",
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [ValidateScript({Test-Path -Path $_ -PathType Leaf})]
        [string]$rsa_gpe_public_key_test = "$(Split-path  -path (Split-Path -Path (Get-location)))\Technical\Keys\rsa_public_test\rsa_public_test.pem",
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [ValidateScript({Test-Path -Path $_ -PathType Leaf})]
        [string]$rsa_private_key_prod = "$(Split-path  -path (Split-Path -Path (Get-location)))\Technical\Keys\rsa_private_prod\rsa_private_key.pem",
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [ValidateScript({Test-Path -Path $_ -PathType Leaf})]
        [string]$rsa_private_key_test = "$(Split-path  -path (Split-Path -Path (Get-location)))\Technical\Keys\rsa_private_test\rsa_private_key.pem",

        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [ValidateScript({Test-Path -Path $_ -PathType Container})]
        [string]$tempDir_AesKey_Path = "$(Split-path  -path (Split-Path -Path (Get-location)))\Technical\Keys\TEMP",
        # Adresář, kde se nacházejí vstupní .zip soubory
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [ValidateScript({Test-Path -Path $_ -PathType Container})]
        [string]$inputDir_Path ="$(Split-Path -Path (Get-location))\B2B",
        
        # Adresář pro rozbalení archivů do dočasných adresářů
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [ValidateScript({Test-Path -Path $_ -PathType Container})]
        [string]$tempDir_Path ="$(Split-Path -Path (Get-location))\TEMP",
        # Adresář pro neroztridene soubory
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [ValidateScript({Test-Path -Path $_ -PathType Container})]
        [string]$OthersDir_Path ="$(Split-path -path (Split-Path -Path (Get-location)))\Card_Services\Reports\OTHERS",
        # Cílový adresář pro produkční soubory
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [ValidateScript({Test-Path -Path $_ -PathType Container})]
        [string]$reportsDir_Path ="$(Split-path -path (Split-Path -Path (Get-location)))\Card_Services\Reports\REPORTS_PROD",

        # Cílový adresář pro testovací soubory
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [ValidateScript({Test-Path -Path $_ -PathType Container})]
        [string]$reportsDirTest_Path ="$(Split-path -path (Split-Path -Path (Get-location)))\Card_Services\Reports\REPORTS_TEST",
        
        # Adresář pro logování aktivit skriptu
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [string]$logDir_Path ="$(Split-Path -Path (Get-location))\LOGS",

        # Doba uchování logů ve dnech
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [Int16]$logRetentionDays = 31,

        # Počáteční znaky .zip souboru s produkčními reporty
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [string]$archiveNameProd = "POP0100",               
        # Počáteční znaky .zip souboru s testovacími reporty
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [string]$archiveNameTest = "POT0100",    
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [ValidateScript({Test-Path -Path $_ -PathType Leaf})]
        [string]$maskMapping_Path = "$(Get-location)\maskMapping.JSON"      
)
#Global Config
$ErrorActionPreference = "Stop"
#MyLogclass
try 
{
    Enum Severity
    {
        Error
        Information
        Warning
    }
    class Log 
    {
        [string]$logFolderPath
        [string]$logFileName
        Log([string]$logFolderPath)
        {
            $this.logFileName = Join-Path -Path $logFolderPath -ChildPath "log_$(Get-Date -Format "yyyyMMdd").txt"
            $this.logFolderPath = $logFolderPath
            try
            {
                if(!(Test-Path -Path $this.logFolderPath))
                {
                    New-item -Path $this.logFolderPath -ItemType Directory
                }
            }
            catch
            {
                Throw "This is an error class Log. $_"
            }
        }
        NewLogFile()
        {
            try 
            {
                if(!(Test-Path -Path $this.logFileName))
                {
                    New-Item -Path $this.logFileName -ItemType File 
                } 
            }
            catch {
                Throw "This is an error class Log. $_"
            }
        }
        WriteLog([String]$message,[severity]$severity)
        {
            $this.NewLogFile()
            Add-Content -Path $this.logFileName -Value ([string]::Format("{0} - [{1}] - {2}",[datetime]::Now.ToString("yyyy-MM-dd HH:mm:ss"),$severity,$message))
            switch ($severity) {
                "error" {Write-Error "$([string]::Format("{0} - [{1}] - {2}",[datetime]::Now.ToString("yyyy-MM-dd HH:mm:ss"),$severity,$message))"}
                "warning" {Write-Warning "$([string]::Format("{0} - [{1}] - {2}",[datetime]::Now.ToString("yyyy-MM-dd HH:mm:ss"),$severity,$message))"}
                Default {[System.Console]::WriteLine("$([string]::Format("{0} - [{1}] - {2}",[datetime]::Now.ToString("yyyy-MM-dd HH:mm:ss"),$severity,$message))")}
            }
        }
        CleanUP([Int16]$logRetentionDays)
        {
            $this.WriteLog("Start cleanUp logs older than $logRetentionDays days!",[Severity]::Information)
            $cutoffDate = (Get-Date).AddDays(-$logRetentionDays)
            $logFiles = Get-ChildItem -Path $this.logFolderPath -Filter "log_*.txt"
            
            $logFiles | Where-Object {$PSItem.Name -match 'log_(\d{8})\.txt' -and ([datetime]::ParseExact($matches[1], 'yyyyMMdd',$null) -lt $cutoffDate)} | ForEach-Object {
                Remove-Item -Path $PSitem.FullName -Force
                $this.WriteLog("Removed item:'$($PSitem.FullName)'.",[Severity]::Information)
            }        
            $this.WriteLog("CleanUp finished!",[Severity]::Information)
        }
    }
    $log = [log]::new($logDir_Path)
    $log.WriteLog("Start processing scipt!",[severity]::Information) 
    $log.WriteLog("Log class instance LOG was set successfully!",[severity]::Information)
    $log.CleanUP($logRetentionDays)
}
catch 
{
    throw 
}
#Variables
try 
{
    #Validate directories
    if((Get-CimInstance -ClassName win32_computersystem).domain -eq "dslab.kb.cz")
    {
        $inputDir_Path, $tempDir_Path, $reportsDirTest_Path, $tempDir_AesKey_Path, $OthersDir_Path | ForEach-Object {
            if(!(Test-Path -Path $PSItem -PathType Container))
            {
                New-item -Path $PSItem -ItemType Directory | Out-Null
                $log.WriteLog("New directory: $PSItem",[severity]::Information)
            }
        }
    }
    else #PROD
    {
        $inputDir_Path, $tempDir_Path, $reportsDir_Path, $tempDir_AesKey_Path, $OthersDir_Path | ForEach-Object {
            if(!(Test-Path -Path $PSItem -PathType Container))
            {
                New-item -Path $PSItem -ItemType Directory | Out-Null
                $log.WriteLog("New directory: $PSItem",[severity]::Information)
            }
        }
    }
    #Validate NetMask File
    if(!(Test-Path -Path $maskMapping_Path -PathType Leaf)){Throw "Cannot find path '$PSitem' because it does not exist."}    
    #Validate Cert Files
    if((Get-CimInstance -ClassName "Win32_ComputerSystem").Domain -eq "ds.kb.cz")
    {
        $rsa_gpe_public_key_prod, $rsa_private_key_prod | ForEach-Object {
            if(!(Test-Path -Path $PSItem -PathType Leaf))
            {
                Throw "Cannot find path '$PSitem' because it does not exist."
            }
        }
        $rsa_gpe_public_key = $rsa_gpe_public_key_prod
        $rsa_private_key = $rsa_private_key_prod
    }
    else
    {
        $rsa_gpe_public_key_test, $rsa_private_key_test | ForEach-Object {
            if(!(Test-Path -Path $PSItem -PathType Leaf))
            {
                Throw "Cannot find path '$PSitem' because it does not exist."
            }
        }
        $rsa_gpe_public_key = $rsa_gpe_public_key_test
        $rsa_private_key = $rsa_private_key_test
    }
    $maskMapping = Get-Content -path $maskMapping_Path | ConvertFrom-Json
}
catch {
    $log.WriteLog("$($_.Exception.Message)",[severity]::Error)
}
try 
{
    class File_List
    {
        [string]$Name
        $list = [System.Collections.ArrayList]::new()
        [log]$Log
        File_List([string]$Name,[log]$Log)
        {
            try 
            {
                $this.Name = $name
                $this.Log = $log
            }
            catch 
            {
                $log.WriteLog("$_ ",[severity]::Error)
            }
        }
    }
    class File 
    {
        [System.IO.FileSystemInfo]$File
        [string]$type
        [log]$Log
        File([System.IO.FileSystemInfo]$file,[string]$type,[log]$Log)
        {
            try 
            {
                $this.File = $file
                $this.type = $type
                $this.Log = $log
            }
            catch 
            {
                $log.WriteLog("$_ ",[severity]::Error)
            }
        }
    }
    class TransferFile
    {
        [log]$Log
        $TransferFiles_Group_List = [System.Collections.ArrayList]::new()
        TransferFile([log]$log)
        {
            try 
            {
                $this.Log = $log
            }
            catch 
            {
                $log.WriteLog("$_ ",[severity]::Error)
            }
        }
        [void]GetFiles([string]$inputDir_Path)
        {
            try 
            {
                
                Get-ChildItem -Path $inputDir_Path | Group-Object -Property {"$(($PSItem.Name).split('.')[0]).$(($PSItem.Name).split('.')[1]).$(($PSItem.Name).split('.')[2])"} | ForEach-Object {
                    $Group = $PSItem
                    $this.log.WriteLog("GetFiles: Start process group files'$($Group.Name)' ",[severity]::Information)
                    $File_List = [File_List]::new($Group.Name,$this.log)
                    $Group.Group | ForEach-Object {
                        if($PSItem | Where-Object {$_.name -match '.dat.enc$'}){$file = [file]::new($PSItem,"encrypted_transfer_file",$this.log)}
                        if($PSItem | Where-Object {$_.name -match '.key.enc$'}){$file = [file]::new($PSItem,"encrypted_aes_ephemeral",$this.log)}
                        if($PSItem | Where-Object {$_.name -match '.sig$'}){$file = [file]::new($PSItem,"signature",$this.log)}
                        if($PSItem | Where-Object {$_.name -match '.flg$'}){$file = [file]::new($PSItem,"flag",$this.log)}
                        $File_List.list.Add($file)
                    }
                    [bool]$missingFile = $false
                    if(!($File_List.list | Where-Object {$PSItem.Type -eq "encrypted_transfer_file"}))
                    {
                        $missingFile = $true
                        $this.log.WriteLog("GetFiles:'$($Group.Name)' group miss encrypted transfer file!",[severity]::Warning)
                    }
                    if(!($File_List.list | Where-Object {$PSItem.Type -eq "encrypted_aes_ephemeral"}))
                    {
                        $missingFile = $true
                        $this.log.WriteLog("GetFiles:'$($Group.Name)' group miss aes ephemeral key file!",[severity]::Warning)
                    }
                    if(!($File_List.list | Where-Object {$PSItem.Type -eq "signature"}))
                    {
                        $missingFile = $true
                        $this.log.WriteLog("GetFiles:'$($Group.Name)' group miss signature file!",[severity]::Warning)
                    }
                    if(!($File_List.list | Where-Object {$PSItem.Type -eq "flag"}))
                    {
                        $missingFile = $true
                        $this.log.WriteLog("GetFiles:'$($Group.Name)' group miss flag file!",[severity]::Warning)
                    }
                    if(!$missingFile)
                    {
                        $this.TransferFiles_Group_List.Add($File_List)
                        $this.Log.WriteLog("Add $($Group.Name) group to transfer list",[Severity]::Information)
                    }
                }
                if($this.TransferFiles_Group_List.count -eq 0)
                {
                    $this.log.WriteLog("No files to process in folder: $inputDir_Path",[severity]::Warning)
                    Exit 0
                }
            }
            catch 
            {
                $this.log.WriteLog("GetFiles:$($_.Exception.Message)",[severity]::Error)
            }
        }
        [void]Decrypt([string]$tempDir_Path,[string]$OpenSSLFolder_Path,[string]$rsa_private_key,[string]$rsa_gpe_public_key,[string]$tempDir_AesKey_Path)
        {
            try 
            {
                $this.TransferFiles_Group_List | ForEach-Object {
                    $TransferFiles_Group_List = $PSItem
                    $encrypted_transfer_file = ($TransferFiles_Group_List.list | Where-Object {$_.type -eq "encrypted_transfer_file"}).File.Fullname
                    $encrypted_aes_ephemeral = ($TransferFiles_Group_List.list | Where-Object {$_.type -eq "encrypted_aes_ephemeral"}).File.Fullname
                    $signature = ($TransferFiles_Group_List.list | Where-Object {$_.type -eq "signature"}).File.Fullname

                    $aes_ephemeral = "$tempDir_AesKey_Path\aes_ephemeral.key"
                    $transfer_file = "$tempDir_Path\$($TransferFiles_Group_List.name).zip"
                    try 
                    {
                        #Validation
                        $output = Invoke-Expression -Command "$($OpenSSLFolder_Path)\openssl.exe dgst -sha256 -verify $rsa_gpe_public_key -signature $signature $encrypted_transfer_file 2>&1"
                        $errors = [System.Collections.ArrayList]::new()
                        $output | ForEach-Object {
                            if ($PSItem -like "*error*" ) 
                            {
                                $Errors.Add($PSItem)
                            }
                            else
                            {
                                $this.log.WriteLog("Transferd files. Group name:'$($TransferFiles_Group_List.name)' openSSL: $PSItem",[severity]::Information)
                            }
                        }
                        if($Errors)
                        {
                            
                            $Errors | ForEach-Object {$this.log.WriteLog("OpenSSL: $PSItem",[severity]::Warning)}
                            Throw "Failed validity/integrity of the Signature of Transfer file $($TransferFiles_Group_List.name)"
                        }
                        #Decrypt
                        #Decrypt "AES ephemeral" key to allow decryption of the "Transfer File"
                        $output = Invoke-Expression -Command "$($OpenSSLFolder_Path)\openssl.exe rsautl -decrypt -in $encrypted_aes_ephemeral -inkey $rsa_private_key -out $aes_ephemeral 2>&1"
                        $errors = [System.Collections.ArrayList]::new()
                        $output | ForEach-Object {
                            if ($PSItem -like "*error*" ) 
                            {
                                $Errors.Add($PSItem)
                            }
                            else
                            {
                                $this.log.WriteLog("Decrypt AES ephemeral key. Group name: '$($TransferFiles_Group_List.name)' openSSL: $PSItem",[severity]::Information)
                            }
                        }
                        if($Errors)
                        {
                            
                            $Errors | ForEach-Object {$this.log.WriteLog("OpenSSL: $PSItem",[severity]::Warning)}
                            Throw "Failed decrypt AES ephemeral key to allow decryption of the Transfer File '$($TransferFiles_Group_List.name)'"
                        }
                        #Decrypt "Transfer File zip" 
                        $output = Invoke-Expression -Command "$($OpenSSLFolder_Path)\openssl.exe  aes-256-cbc -d -a -in $encrypted_transfer_file -out $transfer_file -kfile $aes_ephemeral 2>&1"
                        $errors = [System.Collections.ArrayList]::new()
                        $output | ForEach-Object {
                            if ($PSItem -like "*error*" ) 
                            {
                                $Errors.Add($PSItem)
                            }
                            else
                            {
                                $this.log.WriteLog("Decrypt Transfer File. Group name: '$($TransferFiles_Group_List.name)' openSSL: $PSItem",[severity]::Information)
                            }
                        }
                        if($Errors)
                        {
                            
                            $Errors | ForEach-Object {$this.log.WriteLog("OpenSSL: $PSItem",[severity]::Warning)}
                            Throw "Failed decrypt Transfer File $($TransferFiles_Group_List.name)"
                        }
                        #Remove files
                        $TransferFiles_Group_List.list.File | ForEach-Object {
                            $this.log.WriteLog("File: '$($PSItem.Name)' is removed",[severity]::Information)
                            $PSItem | Remove-Item -Force
                        }
                        $aes_ephemeral | Remove-Item -Force
                        $this.log.WriteLog("AES ephemeral key: '$aes_ephemeral' is removed",[severity]::Information)
                    }
                    catch 
                    {
                        $this.log.WriteLog("Decrypt:$($_.Exception.Message)",[severity]::Warning)
                    }
                }
            }
            catch 
            {
                $this.log.WriteLog("Decrypt:$($_.Exception.Message)",[severity]::Error)
            }
        }
    }
    class Archives 
    {
        [log]$Log
        $ZipFile_List = [System.Collections.ArrayList]::new()
        Archives([log]$log)
        {
            try 
            {
                $this.Log = $log
            }
            catch 
            {
                $log.WriteLog("$_ ",[severity]::Error)
            }
        }
        [void]GetFiles([string]$inputDir_Path)
        {
            try 
            {    
                Get-ChildItem -Path $inputDir_Path -Filter *.zip | ForEach-Object {
                    $this.ZipFile_List.Add($PSItem)
                    $this.log.WriteLog("GetFiles: Add '$($PSItem.Name)' zip file to be processed",[severity]::Information)  
                }
                $this.log.WriteLog("GetFiles: Got $($this.ZipFile_List.Count) zip files",[severity]::Information)
                if(($this.ZipFile_List).Count -eq 0)
                {
                    throw [System.IO.FileNotFoundException]::new("Could not find ZIP files in folder: $inputDir_Path")
                }
            }
            catch [System.IO.FileNotFoundException]
            {
                $this.log.WriteLog("GetFiles:$($_.Exception.Message)",[severity]::Warning)
                Exit 0
            }
            catch 
            {
                $this.log.WriteLog("GetFiles:$($_.Exception.Message)",[severity]::Error)
            }
        }
        [void]ExpandArchives([string]$tempDir_Path,[string]$archiveNameProd,[string]$reportsDir_Path,[string]$reportsDirTest_Path,$maskMapping,[string]$othersDir_Path)
        {
            try 
            {
                $this.ZipFile_List | Foreach-Object {
                    
                    $ZipFile = $PSItem
                    $extractPath = Join-Path -Path $tempDir_Path -ChildPath $PSItem.BaseName
                    New-Item -Path $extractPath -ItemType Directory -Force
                    Expand-Archive -Path $PSItem.FullName -DestinationPath $extractPath -Force
                    $this.log.WriteLog("ExpandArchives: Extract '$($PSItem.BaseName)' file ",[severity]::Information)
                    foreach($file in Get-ChildItem -Path $extractPath)
                    {
                        $this.log.WriteLog("Processing '$($file.Name)' file.",[severity]::Information)
                        $fileType = if($ZipFile.BaseName.StartsWith($archiveNameProd)){'PROD'}else{'TEST'}
                        $targetDir = [string]::Empty
                        forEach($item in $maskMapping)
                        {
                            $this.log.WriteLog("Processing mask '$($item.Type):$($item.mask)'.",[severity]::Information)
                            if ($File.Name.StartsWith($item.Mask) -and $item.Type -eq $fileType) 
                            {
                                if ($fileType -eq 'PROD') 
                                {
                                    $targetDir = Join-Path -Path $reportsDir_Path -ChildPath "$($item.Directory)\$((Get-date).ToString("yyyyMM"))"
                                } 
                                else 
                                {
                                    $targetDir = Join-Path -Path $reportsDirTest_Path -ChildPath "$($item.Directory)\$((Get-date).ToString("yyyyMM"))"
                                }
                                break
                            }
                        }
                        if (!$targetDir) 
                        {
                            $targetDir = $OthersDir_Path
                            $this.log.WriteLog("ExpandArchives: No mask for '$($file.Name)' file. It will be moved to $targetDir",[severity]::Warning)
                        }
                        if (!(Test-Path -Path $targetDir)) 
                        {
                            New-Item -Path $targetDir -ItemType Directory -Force
                            $this.log.WriteLog("ExpandArchives: New folder '$targetDir'",[severity]::Information)
                        }
                        $DestinationFile = Join-Path -Path $targetDir -ChildPath $File.Name
                        $this.CopyFiles($file.FullName,$destinationFile,$targetDir)
                    }
                    $extractPath | Remove-Item -Recurse -Force
                    $this.log.WriteLog("Folder '$extractPath' is removed",[severity]::Information)
                    $zipFile.FullName | Remove-Item -Recurse -Force
                    $this.log.WriteLog("File '$($zipFile.FullName)' is removed",[severity]::Information)
                }
            }
            catch 
            {
                $this.log.WriteLog("ExpandArchives:$($_.Exception.Message)",[severity]::Error)
            }
        }
        [void]CopyFiles([string]$sourceFile,[string]$destinationFile,[string]$targetDir)
        {
            try 
            {
                if (Test-Path -Path $destinationFile) 
                {
                    $fileName = [System.IO.Path]::GetFileName($sourceFile)
                    $newFileName = "${fileName}.dupl"
                    $destinationFile = Join-Path -Path $targetDir -ChildPath $newFileName
                    $this.log.WriteLog("CopyFiles:File $fileName already exist, it is renamed as $destinationFile",[severity]::Warning)
                }
                Copy-Item -Path $sourceFile -Destination $destinationFile
                $this.log.WriteLog("CopyFiles:Copy file $sourceFile to $destinationFile",[severity]::Information)
            }
            catch 
            {
                $this.log.WriteLog("CopyFiles:$($_.Exception.Message)",[severity]::Error)
            }

        }
    }
}
catch 
{
    $log.WriteLog("$($_.Exception.Message)",[severity]::Error)
}
#Main
try 
{
    $TransferFile = [TransferFile]::new($log)
    $TransferFile.GetFiles($inputDir_Path)
    $TransferFile.Decrypt($tempDir_Path,$OpenSSLFolder_Path,$rsa_private_key,$rsa_gpe_public_key,$tempDir_AesKey_Path)
    $Archives =  [Archives]::new($log)
    $Archives.GetFiles($tempDir_Path)
    $Archives.ExpandArchives($tempDir_Path,$archiveNameProd,$reportsDir_Path,$reportsDirTest_Path,$maskMapping,$OthersDir_Path)
}
catch 
{
    $log.WriteLog("$($_.Exception.Message)",[severity]::Error)
}
