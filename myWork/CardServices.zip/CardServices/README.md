# PAN Report Processing System

## Overview
This is an automated PowerShell-based report processing system for handling secure GPE reports from KB, a.s. The system processes encrypted reports and manages file routing based on predefined mask mappings.

## Files

### `panreport.ps1`
Main PowerShell script that automates secure processing of reports from GPE.

**Requirements:**
- PowerShell Core edition
- OpenSSL-Win64 (default: `C:\Program Files\OpenSSL-Win64\bin`)
- RSA public key for GPE in production environment

**Key Features:**
- Secure report encryption/decryption using RSA keys
- Configurable paths for OpenSSL and cryptographic keys
- Support for both production and test environments

### `run_script.cmd`
Batch script that launches the PowerShell report processing script.

**Usage:**
Execute this batch file to run the `panreport.ps1` PowerShell script via PowerShell Core.

### `maskMapping.json`
Configuration file containing mask-to-directory mappings for report routing.

**Structure:**
- `Mask`: Report identifier/code (e.g., EPRI, EPRO, VIS)
- `Type`: Environment type (PROD, TEST)
- `Directory`: Target directory for routing

**Example Masks:**
- EPRI → EP INCOMING
- EPRO → EP OUTGOING
- RIL → MC CLEARING
- BIM → MC ABU
- VIS → VAU DAILY
- VIE → VAU MONTHLY

## Setup Instructions

1. Ensure OpenSSL is installed in the default location or specify an alternate path when running the script
2. Ensure RSA public keys are available in the specified directory
3. Configure `maskMapping.json` with appropriate directory paths for your environment
4. Run `run_script.cmd` to execute the report processing workflow

## Author
- petr_cejka@kb.cz
- a5320net@ds.kb.cz

## Company
KB, a.s. - .NET MWS Team

## Version
1.0.0.1
