# For more information on the Azure DevOps Task SDK:
# https://github.com/Microsoft/vsts-task-lib
Trace-VstsEnteringInvocation $MyInvocation
$global:ErrorActionPreference = 'Stop'
$global:__vstsNoOverrideVerbose = $true
try 
{
    Import-VstsLocStrings "$PSScriptRoot\task.json"
    # Get all inputs for the task
    $input_Folder = Get-VstsInput -Name "Folder" -Require 
    $input_Recurse = Get-VstsInput -Name "Recurse" -AsBool -Require
    $input_Include = Get-VstsInput -Name "Include"
    $input_Exclude = Get-VstsInput -Name "Exclude"
    $input_Certificate = Get-VstsInput -Name "Certificate"
    $input_SecuredPassword = (Get-VstsInput -Name "Password" | ConvertTo-SecureString -AsPlainText -Force)
    $input_TimeStamp = Get-VstsInput -Name "TimeStamp"
    $input_TimeStampServer = Get-VstsInput -Name "TimeStampServer"
    #Set current directory
    if($env:BUILD_SOURCESDIRECTORY)
    {
        Set-Location -Path $env:BUILD_SOURCESDIRECTORY
    }
    elseif($env:AGENT_RELEASEDIRECTORY)
    {
        Set-Location -Path $env:AGENT_RELEASEDIRECTORY
    }
    else
    {
        throw "Cannot process because both variables AGENT_SOURCESDIRECTORY and AGENT_RELEASEDIRECTORY are null or empty"
    }
    if($input_ProfilePath -eq (Get-location)){$input_ProfilePath = [string]::Empty} 
    # Write input varibles
     Write-Output "input_Folder: $input_Folder"
     Write-Output "input_Recurse: $input_Recurse"
     Write-Output "input_Include: $input_Include"
     Write-Output "input_Exclude: $input_Exclude"
     Write-Output "input_Certificate: $input_Certificate"
     Write-Output "input_SecuredPassword: $input_SecuredPassword"
     Write-Output "input_TimeStamp: $input_TimeStamp"
     Write-Output "input_TimeStampServer: $input_TimeStampServer"
    #Param
    try 
    {
        $param = @{}
        $param.Path = (Resolve-Path -Path $input_Folder).ProviderPath
        $param.Recurse = $input_Recurse
        $param.Include = $input_Include -split ","
        $param.Exclude = $input_Exclude -split ","        
        Write-Output "Parameters:"
        $param | ForEach-Object {Write-Output $_}  
        $files = Get-ChildItem @param
        if($files)
        {
            Write-Output "$($files.count) files to process:"
            $files | ForEach-Object {Write-Output "`t$($_.Name)"}
        }
        else 
        {
            Write-Warning "$($files.count) files to process!"
        }        
        #Resolve cert path
        $path_certificate = (Resolve-Path -Path $input_Certificate).ProviderPath
        #URL adress format
        if(!($input_TimeStampServer -match '(http[s]?|[s]?ftp[s]?)(:\/\/)([^\s,]+)' -or [string]::IsNullOrEmpty($input_TimeStampServer)))
        {
            Throw "Invalid URL Format"
        }
        $Item_Certificate = [System.Security.Cryptography.X509Certificates.X509Certificate2]::new($path_certificate,([System.Net.NetworkCredential]::new("", $input_SecuredPassword).Password))
    }
    catch 
    {
        Write-Error -Message "$($_.Exception.ToString())"
        throw
    }
    #process
    try 
    {
        $list_Signature = [System.Collections.ArrayList]::new()
        if($input_TimeStamp)
        {
            $files | ForEach-Object {
                $signature = Set-AuthenticodeSignature -Certificate $Item_Certificate -FilePath $_.FullName  -TimestampServer $input_TimeStampServer
                Write-Output "Adds an Authenticode signature to a PowerShell script: $($signature.Path) status: $($signature.Status)"
                $list_signature.Add($signature) | Out-Null
            }    
        }
        else 
        {
            $files | ForEach-Object {
                $signature = Set-AuthenticodeSignature -Certificate $Item_Certificate -FilePath $_.FullName
                Write-Output "Adds an Authenticode signature to a PowerShell script: $($signature.Path) status: $($signature.Status)"
                $list_signature.Add($signature) | Out-Null
            }
        }
    }
    catch 
    {
        Write-Error -Message "$($_.Exception.ToString())"
    }
    #Summary
    if($list_signature | Where-Object {$_.Status -ne "valid"})
    {
        $list_signature | Where-Object {$_.Status -ne "valid"} | ForEach-Object {Write-Output "##vso[task.logissue type=error]$([string]::Format("ScriptName:{0} Status:{1}",$_.Path,$_.Status))"}
        Write-Output "##vso[task.complete result=warning;]"
    }
    else {
        Write-Output "All $($list_Signature.count) signature(s) have valid status"
        Write-Output "##vso[task.complete result=Succeeded;]"
    }
} 
catch 
{
    Write-Verbose "Exception caught from task: $($_.Exception.ToString())"
    throw
}
finally 
{
    Trace-VstsLeavingInvocation $MyInvocation
}