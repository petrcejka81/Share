# For more information on the Azure DevOps Task SDK:
# https://github.com/Microsoft/vsts-task-lib
Trace-VstsEnteringInvocation $MyInvocation
$global:ErrorActionPreference = 'Stop'
$global:__vstsNoOverrideVerbose = $true
try {
    Import-VstsLocStrings "$PSScriptRoot\task.json"
    #CSS codes
    $header = 
@"
    <style>
    h1 {
        font-family: Arial, Helvetica, sans-serif;
        color: #703939;
        font-size: 28px;
    }
    h2 {
        font-family: Arial, Helvetica, sans-serif;
        color: #703939;
        font-size: 16px;
    }
   table {
		font-size: 12px;
		border: 0px; 
		font-family: Arial, Helvetica, sans-serif;
	} 
    td {
		padding: 4px;
		margin: 0px;
		border: 0;
	}
    th {
        background: #703939;
        background: linear-gradient(#8f4949, #502929);
        color: #fff;
        font-size: 11px;
        text-transform: uppercase;
        padding: 10px 15px;
        vertical-align: middle;
	}
    tbody tr:nth-child(even) {
        background: #f0f0f2;
    }
    #CreationDate {

        font-family: Arial, Helvetica, sans-serif;
        color: #703939;
        font-size: 14px;
        font-weight: bold;
    }
    #Summary {

        font-family: Arial, Helvetica, sans-serif;
        font-size: 14px;
        font-weight: bold;
    }
    </style>
"@
    # Get all inputs for the task
    $input_PSFolder = Get-VstsInput -Name "PSFolder" -Require 
    $input_Recurse = Get-VstsInput -Name "Recurse" -AsBool -Require
    $input_Include = Get-VstsInput -Name "Include"
    $input_Exclude = Get-VstsInput -Name "Exclude"
    $input_ProfilePath = Get-VstsInput -Name "ProfilePath" 
    $input_FailOnError = Get-VstsInput -Name "FailOnError" -AsBool -Require
    $input_ScriptAnalyzerErrors = Get-VstsInput -Name "ScriptAnalyzerErrors" -AsBool
    $input_ScriptAnalyzerWarnings = Get-VstsInput -Name "ScriptAnalyzerWarnings" -AsBool
    $input_ScriptAnalyzerInformation = Get-VstsInput -Name "ScriptAnalyzerInformation" -AsBool
    $input_IncludeRule = Get-VstsInput -Name "IncludeRule"
    $input_ExcludeRule = Get-VstsInput -Name "ExcludeRule"
    #Set current directory
    if($env:BUILD_SOURCESDIRECTORY)
    {
        Set-Location -Path $env:BUILD_SOURCESDIRECTORY
    }
    elseif($env:AGENT_RELEASEDIRECTORY)
    {
        Set-Location -Path $env:AGENT_RELEASEDIRECTORY
    }
    else
    {
        throw "Cannot process because both variables AGENT_SOURCESDIRECTORY and AGENT_RELEASEDIRECTORY are null or empty"
    }
    if($input_ProfilePath -eq (Get-location)){$input_ProfilePath = [string]::Empty}
    # Write input varibles
    Write-Output "input_PSFolder: $input_PSFolder"
    Write-Output "input_Recurse: $input_Recurse"
    Write-Output "input_Include: $input_Include"
    Write-Output "input_Exclude: $input_Exclude"
    Write-Output "input_ScriptAnalyzerErrors: $input_ScriptAnalyzerErrors"
    Write-Output "input_ScriptAnalyzerWarnings: $input_ScriptAnalyzerWarnings"
    Write-Output "input_ScriptAnalyzerInformation: $input_ScriptAnalyzerInformation"
    Write-Output "input_IncludeRule: $input_IncludeRule"
    Write-Output "input_ExcludeRule: $input_ExcludeRule"
    Write-Output "input_ProfilePath: $input_ProfilePath"
    Write-Output "input_FailOnError: $input_FailOnError"
    Write-Output "Powershell: $($psversiontable.PSVersion)"
    Write-Output "Current directory is $(Get-location)"
    Write-Output "Stage Name $env:SYSTEM_STAGENAME"
    #Resolve input Path
    try 
    {
        $param = @{}
        $param.Path = Resolve-Path -Path $input_PSFolder | Select-Object -ExpandProperty ProviderPath
        $param.Recurse = $input_Recurse
        if(![string]::IsNullOrEmpty($input_Include)){$param.Include = $input_Include -split ","}
        if(![string]::IsNullOrEmpty($input_Exclude)){$param.Exclude = $input_Exclude -split ","}       
        if(![string]::IsNullOrEmpty($input_ProfilePath))
        {
            $ProfilePath = Resolve-Path -Path $input_ProfilePath | Select-Object -ExpandProperty ProviderPath
            Write-Output "Profile settings:"
            Write-Output "$(Get-Content -Path $ProfilePath)"  
        }
        $FailOnError = $input_FailOnError
        # Get PsscriptAnalyzer Module
        Import-Module -name "PSScriptAnalyzer"
        Write-Output "PSScriptAnalyzer module was loaded"
        #Asembly avoid TypeNotFound parse error!
        Add-Type -AssemblyName "System.Net.Http"
    }
    catch 
    {
        Write-Error -Message "$($_.Exception.ToString())"
        throw
    }
    $files = Get-ChildItem @param 
    if($files)
    {
        Write-Output "$($files.count) files to process:"
        $files | ForEach-Object {Write-Output "`t$($_.Name)"}
    }
    else 
    {
        Write-Warning "$($files.count) files to process!"
    }        
    if($input_ScriptAnalyzerErrors)
    {
        if($param.Severity)
        {
            if(!($param.Severity | Where-Object {$_ -eq "Error"})){
            $param.Severity.Add("Error")| Out-Null} 
            if(!($param.Severity | Where-Object {$_ -eq "ParseError"})){
                $param.Severity.Add("ParseError")| Out-Null} 
        }
        else 
        {
            $param.Severity = [System.Collections.ArrayList]::new()
            $param.Severity.Add("Error") | Out-Null
            $param.Severity.Add("ParseError") | Out-Null
        }
    }
    if($input_ScriptAnalyzerWarnings)
    {
        if($param.Severity)
        {
            if(!($param.Severity | Where-Object {$_ -eq "Warning"})){
                $param.Severity.Add("Warning") | Out-Null} 
            }
        else 
        {
            $param.Severity = [System.Collections.ArrayList]::new()
            $param.Severity.Add("Warning") | Out-Null
        }
    }
    if($input_ScriptAnalyzerInformation)
    {
        if($param.Severity)
        {
            if(!($param.Severity | Where-Object {$_ -eq "Information"})){
                $param.Severity.Add("Information") | Out-Null} 
            }
        else 
        {
            $param.Severity = [System.Collections.ArrayList]::new()
            $param.Severity.Add("Information") | Out-Null
        }
    }
    if(![string]::IsNullOrEmpty($input_IncludeRule)){$param.IncludeRule = $input_IncludeRule -split ","}
    if(![string]::IsNullOrEmpty($input_ExcludeRule)){$param.ExcludeRule = $input_ExcludeRule -split ","}
    if($ProfilePath)
    {
        Write-Output "Profile file path: $ProfilePath"
        $param.Profile = $ProfilePath
    }
    try 
    {
        New-Item -Path "$(Get-location)\PSScriptAnalyzer" -ItemType Directory | Out-Null
    }
    catch [System.IO.IOException]
    {
        Write-Verbose "Exception caught from task: $($_.Exception.ToString())"
    }
    catch
    {Write-Error -Message "$($_.Exception.ToString())"}
    if($param.Include){$param.Remove("Include")}
    if($param.Exclude){$param.Remove("Exclude")}
    Write-Output "Parameters for Invoke-ScriptAnalyzer:"
    $param | ForEach-Object {Write-Output $_}  
    #Process
    $output = [System.Collections.ArrayList]::new()
    if($files)
    {
        $files | ForEach-Object {
            $param.path = $_.Fullname
            Invoke-ScriptAnalyzer @param | ForEach-Object {if($null -ne $_){$output.Add($_) | Out-Null}}
        }
    }
    $output_Summary = "$($output.count) violations found. Severity distribution: Error = $(($output.severity | Where-Object {$_ -eq "Error" -or $_ -eq "ParseError"}).Count), Warning = $(($output.severity | Where-Object {$_ -eq "Warning"}).Count), Information = $(($output.severity | Where-Object {$_ -eq "Information"}).Count)"
    #Report
    if($Output)
    {
        $report_FilePath = "$(Get-location)\PSScriptAnalyzer\Report$env:SYSTEM_STAGENAME.html"
        $report_Title = "<h1>PSScriptAnalyzer report</h1>"
        $report_Summary = "<h2>Summary</h2>`n<p id='Summary'>$output_Summary</p>"
        $report_AllItem = $output | Select-Object ScriptName,ScriptPath, RuleName, Message, Severity | ConvertTo-html -Fragment -PreContent "<h2>Script Analyzer rules on files</h2>"
        $report = ConvertTo-Html -Head $header -Body "$report_Title $report_Summary $report_AllItem" -Title "PSScriptAnalyzer report" -PostContent "<p id='CreationDate'>Creation Date: $(Get-Date)</p>"
        $report | Out-File $report_FilePath -Force
        Write-Output "New report:$(Get-location)\PSScriptAnalyzer\Report$env:SYSTEM_STAGENAME.html"
        Write-Output "##vso[task.uploadsummary]$(Get-location)\PSScriptAnalyzer\Report$env:SYSTEM_STAGENAME.html"
        try 
        {
            Import-Module -name importexcel
            Write-Output "ImportExcel module was loaded"
            $output | Export-Excel -Path "$(Get-location)\PSScriptAnalyzer\Report$env:SYSTEM_STAGENAME.xlsx" -WorksheetName "PSScriptAnalyzer" -Title "PSScriptAnalyzer" -TitleBold -TableStyle Medium1 -AutoSize
            Write-Output "##vso[task.uploadfile]$(Get-location)\PSScriptAnalyzer\Report$env:SYSTEM_STAGENAME.xlsx"
            Write-Output "New report:$(Get-location)\PSScriptAnalyzer\Report$env:SYSTEM_STAGENAME.xlsx"
        }
        catch 
        {
            Write-Warning "Exception caught from task: $($_.Exception.ToString())"
        }
    }
    if($FailOnError -and $Output)
    {
        Write-Output "FailOnError is set on"
        Write-Output "##vso[task.logissue type=error]$($output_Summary)"
        $output | ForEach-Object {Write-Output "##vso[task.logissue type=error]$([string]::Format("ScriptName:{0,-80}RuleName:{1,-80}Severity:{2,0}",$_.ScriptName,$_.RuleName,$_.Severity ))"}
        Write-Output "##vso[task.complete result=Failed;]"
    }
    elseif(!$FailOnError -and $Output)
    {
        Write-Output "FailOnError is set off"
        Write-Output "##vso[task.logissue type=warning]$($output_Summary)"
        $output | ForEach-Object {Write-Output "##vso[task.logissue type=warning]$([string]::Format("ScriptName:{0,-80}RuleName:{1,-80}Severity:{2,0}",$_.ScriptName,$_.RuleName,$_.Severity ))"}
        Write-Output "##vso[task.complete result=Succeeded;]"
    }
    else 
    {
        Write-Output "$($output_Summary)"
        Write-Output "##vso[task.complete result=Succeeded;]"
    }
} 
catch 
{
    Write-Verbose "Exception caught from task: $($_.Exception.ToString())"
    throw
}
finally 
{
    Trace-VstsLeavingInvocation $MyInvocation
}