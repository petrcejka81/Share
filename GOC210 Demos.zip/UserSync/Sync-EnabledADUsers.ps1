﻿<#
Get-ADUser -Filter * -SearchBase 'OU=Employees,DC=contoso,DC=com' |
    Select-Object -ExpandProperty SamAccountName |
    Out-File -FilePath users.txt -Encoding utf8 -Force
#>

# [string[]] $expectedUsers = Get-Content -Path .\users.txt -Encoding UTF8
# [System.Collections.Specialized.StringCollection]

[System.Collections.Generic.HashSet[string]] $expectedUsers =
    [System.Collections.Generic.HashSet[string]]::new(10000)

Get-Content -Path .\users.txt -Encoding UTF8 | ForEach-Object {
    [void] $expectedUsers.Add($PSItem)
}

[System.Collections.Generic.HashSet[string]] $actualUsers =
    [System.Collections.Generic.HashSet[string]]::new(10000)

Get-ADUser -Filter { Enabled -eq $true} -SearchBase 'OU=Employees,DC=contoso,DC=com' |  ForEach-Object {
    [void] $actualUsers.Add($PSItem.SamAccountName)
}

[System.Collections.Generic.HashSet[string]] $usersToDisable =
    [System.Collections.Generic.HashSet[string]]::new($actualUsers)
$usersToDisable.ExceptWith($expectedUsers)

Get-ADUser -Filter * -SearchBase 'OU=Employees,DC=contoso,DC=com' | ForEach-Object {
    [string] $login = $PSItem.SamAccountName
    [bool] $isEnabled = $PSItem.Enabled
    [bool] $isExpected = $expectedUsers.Contains($login)

    if($isEnabled -and -not $isExpected) {
        Disable-ADAccount -Identity $login -Verbose
    } elseif(-not $isEnabled -and $isExpected) {
        Enable-ADAccount -Identity $login -Verbose
    }
}

$diff = Compare-Object -ReferenceObject ($expectedUsers | Sort-Object) `
               -DifferenceObject ($actualUsers | Sort-Object) `
               -SyncWindow ([int]::MaxValue) `
               -IncludeEqual
$diff | Where-Object SideIndicator -EQ '=>' | Select-Object -ExpandProperty InputObject