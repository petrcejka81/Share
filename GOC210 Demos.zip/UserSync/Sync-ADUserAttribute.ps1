﻿<#
Get-ADUser -Filter * -SearchBase 'OU=Employees,DC=contoso,DC=com' -Properties EmailAddress,DisplayName |
    Select-Object -Property SamAccountName,Enabled,EmailAddress,DisplayName |
    Export-Csv -Path users.csv -Encoding utf8 -Delimiter ',' -NoTypeInformation -Force
#>

[System.Collections.Generic.Dictionary[string,pscustomobject]] $expectedObjects =
    [System.Collections.Generic.Dictionary[string,pscustomobject]]::new(1000)

Import-Csv -Path .\users.csv -Delimiter ',' -Encoding UTF8 | ForEach-Object {
    $expectedObjects.Add($PSItem.SamAccountName, $PSItem)
}


function Sync-ADUserAttribute
{
    param(
        [Microsoft.ActiveDirectory.Management.ADUser] $ADUser,
        [pscustomobject] $ExtectedUser,
        [Parameter(ValueFromPipeline = $true)]
        [string] $AttributeName
    )

    process {
        if($ADUser.$AttributeName -ne $ExtectedUser.$AttributeName) {
            if([string]::IsNullOrEmpty($ExtectedUser.$AttributeName)) {
                Set-ADUser -Identity $ADUser -Clear $AttributeName -Verbose
            } else {
                Set-ADUser -Identity $ADUser -Replace @{ $AttributeName = $expected.$AttributeName } -Verbose
            }
        }
    }
}

Get-ADUser -Filter * -SearchBase 'OU=Employees,DC=contoso,DC=com' -Properties mail,displayName | ForEach-Object {
    [pscustomobject] $expected = $expectedObjects[$PSItem.SamAccountName]

    if($null -ne $expected) {
        'mail','displayName' | Sync-ADUserAttribute -ADUser $PSItem -ExtectedUser $expected
    }
}
