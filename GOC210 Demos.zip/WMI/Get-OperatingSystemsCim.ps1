<#
.SYNOPSIS
Get OS systems

#>

#Requires -Version 3

Param(
    [ValidateNotNullOrEmpty()]
    [string] $PcListPath = 'C:\Users\Administrator\Desktop\pcList.txt'
)

$computers  = Get-Content -Path $PcListPath
Get-CimInstance -Class Win32_OperatingSystem -ComputerName $computers -Property Caption | 
                            Select-Object -Property PSComputerName,Caption | 
                            Sort-Object -Property PSComputerName