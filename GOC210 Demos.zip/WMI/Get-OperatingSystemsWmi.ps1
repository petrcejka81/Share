<#
.SYNOPSIS
Get OS systems

#>

#Requires -Version 3

Param(
    [ValidateNotNullOrEmpty()]
    [string] $PcListPath = 'C:\Users\Administrator\Desktop\pcList.txt'
)

$computers  = Get-Content -Path $PcListPath
Get-WmiObject -Class Win32_OperatingSystem -ComputerName $computers -ThrottleLimit 10 -Property __Server,Caption | 
    Sort-Object -Property PSComputerName |
    Select-Object -Property PSComputerName,Caption
