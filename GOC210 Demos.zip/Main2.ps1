Set-StrictMode -Version Latest
Write-Output $nonexistent


Get-Process

$test = 10
$test += 5
$proc = Get-Process
Get-Process

(Invoke-WebRequest -Uri https://api.ipify.org/ -UseBasicParsing).Content

[string] $ip = Invoke-RestMethod -Uri 'https://api.ipify.org/' -UseBasicParsing
[ipaddress] $ip = Invoke-RestMethod -Uri 'https://api.ipify.org/' -UseBasicParsing


# [hashtable] [array] [string[]]
# Invoke-RestMethod -ur 'https://api.ipify.org/'
# Invoke-RestMethod 'https://api.ipify.org/'
# Invoke-RestMethod -Uri "https://api.ipif`ny.org/$ip"

#Requires -Version 3

<#
.SYNOPSIS
Returns the public IP address of this computer.

.DESCRIPTION

.PARAMETER AsString
If present, returns the IP address as a string.

.EXAMPLE
Get-PublicIpAddress

Returns the public IP address of this computer in the form of an IPAddress object.

.EXAMPLE
Get-PublicIpAddress -AsString

Returns the public IP address of this computer in the form of a string.

#>
function Get-PublicIPAddress
{
    
    [CmdletBinding()]
    [OutputType([ipaddress],[string])]
    param
    (
        [Parameter()]
        [switch]
        $AsString
    )

    [string] $endpoint = 'https://api.ipify.org/'

    try
    {
        [string] $ip = Invoke-RestMethod -Uri $endpoint -UseBasicParsing -ErrorAction Stop
        if($AsString.IsPresent)
        {
            # $ip
            # Write-Output -InputObject $ip
            return $ip
        }
        else
        {
                
            # Default behavior
            return [ipaddress] $ip
        }
    }
    catch [System.Net.WebException]
    {
        # throw $PSItem.Exception
        Write-Error -Message 'Failed getting the public IP.' `
                    -ErrorId GPIA1 `
                    -Category ConnectionError `
                    -Exception $PSItem.Exception
    }
    catch [System.Management.Automation.RuntimeException]
    {
        Write-Error -Message 'Failed parsing the returned IP address.' `
                    -ErrorId GPIA2 `
                    -Category InvalidData `
                    -Exception $PSItem.Exception
    }
}

Get-PublicIpAddress -ErrorAction SilentlyContinue


Get-PublicIpAddress -AsString

Get-Help -Name Get-PublicIpAddress -Full


$ip = Get-PublicIpAddress
$ip.IPAddressToString
$ip.AddressFamily





[ipaddress] '127.0.0.1'
[ipaddress] 'skfjskgj'
$Error[0].Exception.GetType().FullName

[ipaddress]::Parse('skfjskgj')
$Error[0].Exception.GetType().FullName


$endpoint = 'https://api.ip2country.info/ip?5.6.7.8'

$response = Invoke-WebRequest -Uri $endpoint -UseBasicParsing
$response.Content | ConvertFrom-Json | Select-Object -ExpandProperty countryName

Invoke-RestMethod -Uri $endpoint -UseBasicParsing | Select-Object -ExpandProperty countryName



function Get-IPAddressCountry
{
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
        # [ValidateScript( { [ipaddress]::TryParse($PSItem, [ref] $null) } )]
        [ValidateScript( { $PSItem | ForEach-Object {[ipaddress]::TryParse($PSItem, [ref] $null) }} )]
        # [ValidatePattern('^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5]).){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$')]
        [string[]]
        $IPAddress
    )
    process
    {
        foreach($ip in $IPAddress)
        {
            $endpoint = 'https://api.ip2country.info/ip?{0}' -f $ip
            $response = Invoke-RestMethod -Uri $endpoint -UseBasicParsing
            Write-Output -InputObject (New-Object -TypeName PSObject -Property @{
                IPAddress = $ip
                Country = $response.countryName
            })
    
            <#
            Invoke-RestMethod -Uri $endpoint -UseBasicParsing | Select-Object -Property @{ n = 'IPAddress'; e = { $ip } },
                                                                                        @{ n = 'Country'; e = { $PSItem.countryName } }
            #>
        }
    }
    # $endpoint = "https://api.ip2country.info/ip?$IPAddress"
    # $endpoint = 'https://api.ip2country.info/ip?' + $IPAddress
}

Get-IPAddressCountry -IPAddress 8.8.8.8,1.1.1.1,fsfsdf


Get-IPAddressCountry -IPAddress 8.8.8.8
Get-IPAddressCountry -IPAddress 127.0.0.1
Get-IPAddressCountry -IPAddress ksaljfal

Get-IPAddressCountry 8.8.8.8


Get-PublicIPAddress | Get-IPAddressCountry
'8.8.8.8','1.1.1.1' | Get-IPAddressCountry




[ipaddress]::TryParse('8.8.8.8', [ref] $null)

[IPAddress] $ip = $null
[ipaddress]::TryParse('8.8.8.8', [ref] $ip)

IPHelper

<#
PS Function Placement
- In script (function Main?)
- 1 script per function (.\Get-IPAddressCountry.ps1)
- Dot Sourcing (. .\HelperFunctions.ps1)
- Script Module
#>

Get-Module -ListAvailable
$env:PSModulePath -split ';'

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 
Install-PackageProvider -Name NuGet -Scope AllUsers -Force -Proxy -ProxyCredential
Install-Module -Name DSInternals -Scope AllUsers -Proxy -ProxyCredential -Force -RequiredVersion 4.4

Update-Module
Publish-Module -Name IPHelper -NuGetApiKey 4f6sd4f65sd4f56sd4f56sd4f65sd4f5sd6

Register-PackageSource -Name Gopas -Location \\LEKTOR1032\E$\Modules -ProviderName PowerShellGet -Trusted

Get-PackageSource
Publish-Module -Name IPHelper -Repository Gopas -Force
Find-Module -Repository Gopas
Find-Module -Repository Gopas -Name SpeculationControl -AllVersions

Install-Module -Name DSInternals -Repository PSGallery -Force
Publish-Module -Name DSInternals -Repository Gopas -Force



$nextYear = (Get-Date).AddYears(1)
New-SelfSignedCertificate -KeyLength 2048 `
                          -KeyAlgorithm RSA `
                          -Type CodeSigningCert `
                          -NotAfter $nextYear `
                          -Subject 'Code Signing Test' `
                          -HashAlgorithm SHA256 `
                          -CertStoreLocation Cert:\CurrentUser\My `
                          -Provider 'Microsoft Software Key Storage Provider'

$cer = Get-Item -Path Cert:\CurrentUser\My\273205307C9927E320F8076B041346D5864AE794
Set-AuthenticodeSignature -FilePath "E:\Poznamky\IPHelperModule\Scripts\extent.exe" `
                            -Certificate $cer `
                            -TimestampServer 'http://timestamp.digicert.com' `
                            -HashAlgorithm SHA256 `
                            -Force

# TASK: Sign all EXE+DLL files in \\lektor1032\e$\Poznamky\IPHelperModule\Scripts\coverage if they are not signed.
Get-ChildItem
Get-AuthenticodeSignature
Set-AuthenticodeSignature -WhatIf
Where-Object
ForEach-Object


function Set-SignatureInDirectory {
    param (
        [Parameter(Mandatory = $true)]
        [ValidateScript( { Test-Path -Path $PSItem -PathType Container } )]
        [string] $DirectoryPath,

        [Parameter(Mandatory = $true)]
        [System.Security.Cryptography.X509Certificates.X509Certificate2] $Certificate,

        [ValidateSet('.dll','.exe','.ps1','.psm1')]
        [string[]] $Extensions = @('.dll','.exe')
    )

    Get-ChildItem -Path $DirectoryPath -Recurse -File | 
        Where-Object Extension -In $Extensions |
        Get-AuthenticodeSignature |
        Where-Object Status -eq ([System.Management.Automation.SignatureStatus]::NotSigned) |
        Select-Object -ExpandProperty Path |
        Set-AuthenticodeSignature -Certificate $Certificate -WhatIf -Verbose
}

Set-SignatureInDirectory -DirectoryPath 'E:\Poznamky\IPHelperModule\Scripts\coverage' -Certificate $cer -Extensions .exe,.psm1

Add-Type -AssemblyName System.Windows.Forms
$dialog = New-Object -TypeName System.Windows.Forms.FolderBrowserDialog
$dialog.ShowNewFolderButton = $false
$dialog.ShowDialog()
$dialog.SelectedPath

Get-AuthenticodeSignature -FilePath "\\lektor1032\e$\Poznamky\IPHelperModule\Scripts\coverage\ReportGenerator.exe" |
    Select-Object -Property *

Get-Help -Name Get-AuthenticodeSignature -Parameter FilePath
Get-Help -Name Set-AuthenticodeSignature -Parameter FilePath


Get-EventLog -ComputerName localhost -After ([DateTime]::Today) -LogName System -Source 'Service Control Manager' |
    Where-Object EventID -eq 7036 |
    Select-Object -Property @{ n='ComputerName'; e={$PSItem.MachineName} },
                            @{ n='Time'; e={$PSItem.TimeGenerated}},
                            @{ n='ServiceName'; e = {$PSItem.ReplacementStrings[0]} },
                            @{ n='State'; e = {$PSItem.ReplacementStrings[1]}}

Get-WinEvent -ComputerName localhost -FilterHashtable @{
    LogName = 'System'
    ProviderName = 'Service Control Manager'
    Id = 7036
} |
    Select-Object -Property @{n='ComputerName';e={$PSItem.MachineName}},
                            @{n='Date';e={$PSItem.TimeCreated.Date}},
                            @{n='ServiceName';e={$PSItem.Properties.Value[0]}},
                            @{n='State';e={$PSItem.Properties.Value[1]}} |
    Group-Object -Property ServiceName,Date |
    Select-Object -Property @{ n = 'ServiceName'; e = { $PSItem.Group[0].ServiceName } },
                            @{ n = 'Date'; e = { $PSItem.Group[0].Date } },
                            Count |
    Out-GridView
    

# Date, ServiceName, Count
Group-Object

# ComputerName, Time, ServiceName, State
# Log: System, Source: Service Control Manager, ID 7036


Get-ChildItem -Path Cert:\LocalMachine\Root |
    Select-Object -Property ThumbPrint,Subject,NotBefore |
    Export-Csv -Path RootCA.csv -Delimiter ',' -NoTypeInformation

$referenceCertificates = Import-Csv -Path RootCA.csv -Delimiter ','
$currentCertificates = Get-ChildItem -Path Cert:\LocalMachine\Root
Compare-Object -Property ThumbPrint -PassThru -ReferenceObject $referenceCertificates -DifferenceObject $currentCertificates |
    Where-Object SideIndicator -eq '=>' |
    Select-Object -Property Subject,NotBefore
    
$msTrust = 'https://ccadb-public.secure.force.com/microsoft/IncludedCACertificateReportForMSFTCSV'
$msTrustCertificates = Invoke-RestMethod -Uri $msTrust -UseBasicParsing |
                            ConvertFrom-Csv -Delimiter ',' |
                            Add-Member -MemberType AliasProperty -Name ThumbPrint -Value 'SHA-1 Fingerprint' -PassThru
$currentCertificates = Get-ChildItem -Path Cert:\LocalMachine\Root
Compare-Object -Property ThumbPrint -PassThru -ReferenceObject $msTrustCertificates -DifferenceObject $currentCertificates |
    Where-Object SideIndicator -eq '=>' |
    Select-Object -Property Subject,NotBefore

$msTrust = 'https://download.microsoft.com/download/9/b/9/9b9c7b91-fcee-4d8c-bf3c-98f4ed8a8452/TRPRelease.xml'

Invoke-RestMethod -Uri $msTrust -UseBasicParsing | ForEach-Object { $PSItem.trprelease.record }

$xml = Invoke-RestMethod -Uri $msTrust -UseBasicParsing
$xml.trprelease.record.organization
$xml.trprelease.record.friendlyName
$xml.trprelease.record | Select-Object -Property organization,friendlyName

$xml.SelectNodes('//organization')
$xml.SelectNodes('//record')
$xml.SelectNodes('/trprelease/record/organization')
$xml.SelectNodes('/trprelease/record[organization="Entrust"]/friendlyName').InnerText
$xml.SelectNodes('/trprelease/record[organization="Entrust"]') | Select-Object -Property friendlyName,thumbprint



Invoke-WebRequest -Uri $msTrust -UseBasicParsing -OutFile trust.csv


Get-WinEvent -FilterXml @'
<QueryList>
  <Query Id="0" Path="System">
    <Select Path="System">*[System[Provider[@Name='Service Control Manager'] and (EventID=7036)]]</Select>
  </Query>
</QueryList>
'@

Get-WinEvent -FilterXPath "*[System[Provider[@Name='Service Control Manager'] and (EventID=7036)]]" -LogName System

Get-WinEvent -FilterXml @'
<QueryList>
  <Query Id="0" Path="System">
    <Select Path="System">*[System[Provider[@Name='Microsoft-Windows-Hyper-V-Hypervisor']]]</Select>
    <Select Path="Microsoft-Windows-Hyper-V-Config-Admin">*</Select>
    <Select Path="Microsoft-Windows-Hyper-V-High-Availability-Admin">*</Select>
    <Select Path="Microsoft-Windows-Hyper-V-Hypervisor-Admin">*</Select>
    <Select Path="Microsoft-Windows-Hyper-V-Integration-Admin">*</Select>
    <Select Path="Microsoft-Windows-Hyper-V-VID-Admin">*</Select>
    <Select Path="Microsoft-Windows-Hyper-V-VMMS-Admin">*</Select>
    <Select Path="Microsoft-Windows-Hyper-V-VMMS-Networking">*</Select>
    <Select Path="Microsoft-Windows-Hyper-V-VMMS-Storage">*</Select>
    <Select Path="Microsoft-Windows-Hyper-V-Worker-Admin">*</Select>
  </Query>
</QueryList>
'@


$head = @'
<style>
table {
    border: 1px;
}
th {
    align: left;
}
h1 {
    color:red;
}
</style>
'@

$msTrust = 'https://ccadb-public.secure.force.com/microsoft/IncludedCACertificateReportForMSFTCSV'
Invoke-RestMethod -Uri $msTrust -UseBasicParsing |
    ConvertFrom-Csv -Delimiter ',' |
    Select-Object -Property 'CA Owner','SHA-1 Fingerprint','Public Key Algorithm' |
    ConvertTo-Html -Title 'Microsoft Root CA List' -PreContent '<h1>Microsoft Root CA List</h1>' -Head $head |
    Out-File -FilePath RootCA.html -Encoding utf8 -Force

.\RootCA.html

Send-MailMessage -Attachments RootCA.html
Send-MailMessage -Body -BodyAsHtml

<#
$_
$PSItem => #Requires -Version 3
Where-Object
ForEach-Object
Select-Object
Format-List
Format-Table
#>

$excel = New-Object -ComObject Excel.Application
$excel.Visible = $true
$workbook = $excel.Workbooks.Add()
$worksheet = $workbook.Worksheets.Item(1)
$cells = $worksheet.Cells
$cells.Item(1,1) = 'Name'
$cells.Item(1,2) = 'Status'

$blue = 5
$yellow = 44
$range = $worksheet.UsedRange
$range.Interior.ColorIndex = $yellow
$range.Font.ColorIndex = $blue
$range.Font.Bold = $True


Get-Service | ForEach-Object -Begin { $row = 2 } -Process {
	$cells.Item($row,1) = $PSItem.DisplayName
	$cells.Item($row,2) = $PSItem.Status.ToString()
	$row++
}

$excel.Save('services.xlsx')

$sapi = New-Object -ComObject Sapi.SPVoice
$sapi.Speak('Hello World')

Get-CimInstance -ClassName Win32_ClassicCOMClassSetting |
    Select-Object -Property Caption,VersionIndependentProgId |
    Out-GridView

$webClient = New-Object -TypeName System.Net.WebClient
$webClient = [System.Net.WebClient]::new()
# $webClient.DownloadFile(...

[System.Diagnostics.Process]::Start('calc.exe')

[System.Environment]::OSVersion
[System.Environment]::SystemDirectory

[System.IO.FileAccess]::Read

Add-Type -Path 
# [System.Reflection.Assembly]::LoadFile(

        
$code = @'
using System;

namespace HelloWorld
{
    public class Program
    {
        public static void Main(){
            Console.WriteLine("Hello world!");
        }
    }
}
'@
    
Add-Type -TypeDefinition $code -Language CSharp
[HelloWorld.Program]::Main()

class Program {
    [void] Main() {
        Write-Host 'Hello world!'
    }
}

[Program]::new().Main()

enum Colors
{
    Red
    Green
    Blue
}

[Colors]::Red

$signature = @'
[DllImport("kernel32.dll")]
public static extern uint GetPrivateProfileString(
    string lpAppName,
    string lpKeyName,
    string lpDefault,
    StringBuilder lpReturnedString,
    uint nSize,
    string lpFileName);
'@

$type = Add-Type -MemberDefinition $signature `
                 -Name Win32Utils `
                 -Namespace GOC210 `
                 -Using System.Text `
                 -PassThru

$result = [System.Text.StringBuilder]::new()
$result.Capacity = 128 
$numChars = [GOC210.Win32Utils]::GetPrivateProfileString(
    'info',
    'symbolfile',
    'unknown',
    $result,
    128,
    "C:\Windows\INF\usbhub\0409\usbperf.ini"
)
$result.ToString()

echo 'test' | Out-Null
echo 'test' > $null
[void] (echo 'test')
$output = echo 'test'


Get-CimInstance -ClassName Win32_ComputerSystem | Select-Object -Property *
Get-WmiObject -Class Win32_ComputerSystem

# Manufacturer, Model, Name
# STUDENT1032-01 .. STUDENT1032-04

$computers = 1..4 | ForEach-Object { 'STUDENT1032-{0:D2}' -f $PSItem }
$computers = 1..4 | % { 'STUDENT1032-{0:D2}' -f $_ }

Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $computers -Property Manufacturer,Model | Select-Object -Property PSComputerName,Manufacturer,Model

Get-WmiObject -Class Win32_ComputerSystem -ComputerName $computers -Property Manufacturer,Model,__SERVER -ThrottleLimit 10 | Select-Object -Property PSComputerName,Manufacturer,Model

Get-Help -Name Get-CimInstance -Parameter ComputerName
Get-Help -Name Get-WmiObject -Parameter ComputerName


1..4 | Select-Object -Property @{ n = 'ComputerName'; e = { 'STUDENT1032-{0:D2}' -f $PSItem } } |
    Get-CimInstance -ClassName Win32_ComputerSystem -Property Manufacturer,Model |
    Select-Object -Property PSComputerName,Manufacturer,Model


$sessions = New-CimSession -ComputerName $computers -Credential (Get-Credential)
Get-CimInstance -CimSession $sessions -ClassName Win32_ComputerSystem
Remove-CimSession -CimSession $sessions


# Get-WmiObject    OLD   RPC 135 + RND (49152 - 65535) 
# Get-CimInstance  NEW   WS-MAN 5985/5986

Get-CimInstance -ClassName Win32_Product -Filter 'Caption LIKE "%Reader%"' | Invoke-CimMethod -MethodName Uninstall


$command = 'C:\Windows\System32\win32calc.exe'
& $command


$wu = Get-Service -Name wuauserv
if($wu.Status -eq 'Running')
{
    $stav = 'bezi'
}
else
{
    $stav = 'nebezi' 
}

$stav = $wu.Status -eq 'Running' ? 'bezi' : 'nebezi' 



# OpenSSH Server + PS
Get-WindowsCapability -Online -Name 'OpenSSH.Server*' | Add-WindowsCapability -Online
Start-Service -Name sshd
Set-Service -Name sshd -StartupType Automatic
$ps = Get-Command -Name powershell.exe -CommandType Application | Select-Object -ExpandProperty Source
New-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\OpenSSH' `
                 -Name DefaultShell `
                 -Value $ps `
                 -PropertyType String `
                 -Force



function Write-Log([string] $Message, [string] $Level = 'Info')
{
    $logMessage = '{0} {1} {2}' -f $Level,(Get-Date),$Message
    $logMessage >> $script:logFile
    Write-Host $logMessage
}

New-EventLog -LogName Application -Source 'GOC210'
Write-EventLog -LogName Application -Message 'Test' -EntryType Error -EventId 2 -Source GOC210


$VerbosePreference = [System.Management.Automation.ActionPreference]::SilentlyContinue


function  Test-Verbose {
    [CmdletBinding()]
    param ()
    Write-Verbose 'Podrobna sprava'
    $isVerbose = $VerbosePreference -eq [System.Management.Automation.ActionPreference]::Continue
    New-Item -Name test.txt -Force -Verbose:$isVerbose  | Out-Null
    Write-Debug 'Velmi podrobna sprava'
}

Test-Verbose -Verbose -Debug

function Test-ShouldProcess {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param()

    $file = Get-ChildItem './test.txt'
    if($PSCmdlet.ShouldProcess($file.FullName)){
        $file.Delete()
    }
}

Test-ShouldProcess -Confirm:$false


# Task: Create profiles for all enabled local accounts in E:\Profiles and configure ownership.
Get-LocalUser
New-Item
Get-Acl
Set-Acl

#Requires -Modules Microsoft.PowerShell.LocalAccounts -Version 3

function New-UserProfileDirectory
{
    [OutputType([System.IO.DirectoryInfo])]
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ParameterSetName = 'User', Position = 0)]
        [Microsoft.PowerShell.Commands.LocalUser] $User,

        [Parameter(Mandatory = $true, ParameterSetName = 'UserName', ValueFromPipeline = $true, Position = 0)]
        [string] $UserName,

        [Parameter(Mandatory = $true, Position = 1)]
        [string] $Path,

        [switch]
        $PassThru
    )

    process
    {
        # [string] $directoryName = $null
        # [System.Security.Principal.IdentityReference] $owner = $null

        if($PSCmdlet.ParameterSetName -eq 'User')
        {
            [string] $directoryName = $User.Name
            [System.Security.Principal.IdentityReference] $owner = $User.SID
        }
        else
        {
            [string] $directoryName = $UserName
            [System.Security.Principal.IdentityReference] $owner = [System.Security.Principal.NTAccount] $UserName
        }

        # Create user directory
        [System.IO.DirectoryInfo] $userProfile = New-Item -ItemType Directory -Path $Path -Name $directoryName -ErrorAction Stop -Force

        if($PassThru.IsPresent)
        {
            # Send the directory to the next command in the pipeline
            Write-Output -InputObject $userProfile
        }

        # Set directory owner
        Set-DirectoryOwner -Owner $owner -Directory $userProfile
    }
}

function Set-DirectoryOwner
{
    param(
        [Parameter(Mandatory = $true)]
        [System.Security.Principal.IdentityReference]
        $Owner,

        [Parameter(Mandatory = $true)]
        [System.IO.DirectoryInfo]
        $Directory
    )

    [System.Security.AccessControl.DirectorySecurity] $acl = Get-Acl -Path $Directory -ErrorAction Stop
    $acl.SetOwner($Owner)
    Set-Acl -Path $userProfile -AclObject $acl
}


$profilesRoot = New-Item -ItemType Directory -Path E:\Profiles -ErrorAction Stop -Force

Get-LocalUser |
    Where-Object Enabled -eq $true |
    New-UserProfileDirectory -Path $profilesRoot -PassThru

New-UserProfileDirectory Guest E:\Profiles
New-UserProfileDirectory (Get-LocalUser -Name Administrator) E:\Profiles
'Guest' | New-UserProfileDirectory  -Path E:\Profiles



$acl = Get-Acl -Path E:\Profiles

$acl.SetAccessRuleProtection($true, $false)

# $acl.Access | ForEach-Object { $acl.RemoveAccessRule($PSItem) } | Out-Null

foreach($entry in $acl.Access)
{
    [void] $acl.RemoveAccessRule($entry)
}

$owner = [System.Security.AccessControl.FileSystemAccessRule]::new(
    'NT AUTHORITY\CREATOR OWNER',
    [System.Security.AccessControl.FileSystemRights]::Modify,
    [System.Security.AccessControl.InheritanceFlags]::ContainerInherit + [System.Security.AccessControl.InheritanceFlags]::ObjectInherit,
    [System.Security.AccessControl.PropagationFlags]::InheritOnly,
    [System.Security.AccessControl.AccessControlType]::Allow
)

$system = [System.Security.AccessControl.FileSystemAccessRule]::new(
    'NT AUTHORITY\SYSTEM',
    [System.Security.AccessControl.FileSystemRights]::FullControl,
    [System.Security.AccessControl.InheritanceFlags]::ContainerInherit + [System.Security.AccessControl.InheritanceFlags]::ObjectInherit,
    [System.Security.AccessControl.PropagationFlags]::None,
    [System.Security.AccessControl.AccessControlType]::Allow
)

$admins = [System.Security.AccessControl.FileSystemAccessRule]::new(
    'BUILTIN\Administrators',
    [System.Security.AccessControl.FileSystemRights]::FullControl,
    [System.Security.AccessControl.InheritanceFlags]::ContainerInherit + [System.Security.AccessControl.InheritanceFlags]::ObjectInherit,
    [System.Security.AccessControl.PropagationFlags]::None,
    [System.Security.AccessControl.AccessControlType]::Allow
)

$acl.AddAccessRule($owner)
$acl.AddAccessRule($system)
$acl.AddAccessRule($admins)

Set-Acl -Path E:\Profiles -AclObject $acl


$today = ([DateTime]::Today).ToFileTimeUtc()

Get-ADComputer -LDAPFilter "(lastlogon<=$today)" -Properties OperatingSystem, OperatingSystemVersion, LastLogon, LastLogonDate |
    Select-Object -Property Name,
                            @{ n = 'LastLogonTime' ; e = { [DateTime]::FromFileTime($PSItem.LastLogon) } },
                            LastLogonDate,
                            OperatingSystem,
                            OperatingSystemVersion

$yearAgo = (Get-Date).AddYears(-1)
Get-ADComputer -Filter { LastLogonDate -lt $yearAgo }

Get-ADComputer -LDAPFilter '(!(userAccountControl:1.2.840.113556.1.4.803:=2))'
Get-ADComputer -Filter { Enabled -eq $true }

Get-ADUser -LDAPFilter '(mail=*)'
Get-ADUser -LDAPFilter '(!(mail=*))'

Get-ADUser -Filter { EmailAddress -like '*' }
Get-ADUser -Filter { EmailAddress -notlike '*' }
