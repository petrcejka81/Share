<#
.SYNOPSIS
Removes a task that updates all PowerShell modules from the GOC210 repository.

#>

#requires -Version 5 -Modules ScheduledTasks -RunAsAdministrator

Unregister-ScheduledTask -TaskName 'Update GOC210 PowerShell Modules' -Force