<#
.SYNOPSIS
Creates a task that updates all PowerShell modules from the GOC210 repository.

#>

#requires -Version 5 -Modules ScheduledTasks -RunAsAdministrator

$midnight = Get-Date -Hour 0 -Minute 0 -Second 0 -Millisecond 0
$trigger = New-ScheduledTaskTrigger -Daily -At $midnight
$system = New-ScheduledTaskPrincipal -UserId 'System' -RunLevel Highest
$psPath = Get-Command -Name 'powershell.exe' -CommandType Application | Select-Object -ExpandProperty Source
$scriptPath = Join-Path -Path $PSScriptRoot -ChildPath 'Update-AllGOC210Modules.ps1'
$psParams = '-ExecutionPolicy Bypass -NonInteractive -NoProfile -NoLogo -File "{0}"' -f $scriptPath
$action = New-ScheduledTaskAction -Execute $psPath -Argument $psParams
Register-ScheduledTask -TaskName 'Update GOC210 PowerShell Modules' `
                       -Trigger $trigger `
                       -Action $action `
                       -Principal $system `
                       -Force
