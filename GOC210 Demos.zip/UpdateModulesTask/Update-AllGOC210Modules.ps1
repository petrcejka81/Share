<#
.SYNOPSIS
Updates all PowerShell modules from the GOC210 repository.

#>

#requires -Version 5 -Modules PowerShelGet -RunAsAdministrator

Find-Module -Repository GOC210 | Install-Module -Scope AllUsers