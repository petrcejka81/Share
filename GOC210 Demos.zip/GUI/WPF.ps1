Add-Type -AssemblyName PresentationFramework

[string] $absoluteXamlPath = (Resolve-Path -Path .\ComputerWindow.xaml).Path

[System.IO.FileStream] $xaml = [System.IO.File]::OpenRead($absoluteXamlPath)
try {
    [System.Windows.Window] $window = [Windows.Markup.XamlReader]::Load($xaml)
}
finally {
    $xaml.Close()
}

[System.Windows.Controls.TextBox] $computerTextBox =
    $window.Content.Children | Where-Object Name -eq ComputerNameTextBox

[System.Windows.Controls.TextBox] $osTextBox =
    $window.Content.Children | Where-Object Name -eq OSTextBox

[System.Windows.Controls.Button] $reloadButton =
    $window.Content.Children | Where-Object Name -eq ReloadButton

[System.Windows.RoutedEventHandler] $reloadTextBoxes = {
    $computerTextBox.Text = $env:COMPUTERNAME
    $osTextBox.Text = (Get-WmiObject -Class Win32_OperatingSystem).Caption
}

$reloadButton.AddHandler([System.Windows.Controls.Primitives.ButtonBase]::ClickEvent, $reloadTextBoxes)

$window.ShowDialog()