[string] $name = Read-Host -Prompt 'Enter your name'

[securestring] $pass = Read-Host -Prompt 'Enter your password' -AsSecureString

[pscredential] $cred = Get-Credential
$cred.GetNetworkCredential().Password

Get-Process |
    Out-GridView -Title 'Select processes to kill...' -OutputMode Multiple |
    Stop-Process -Verbose