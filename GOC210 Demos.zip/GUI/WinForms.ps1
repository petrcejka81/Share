# Only works in powershell.exe
Add-Type -AssemblyName System.Windows.Forms

# Message Box
[System.Windows.Forms.DialogResult] $result = [System.Windows.Forms.MessageBox]::Show(
    'Do you really want to format your hard drive?',
    'Disk format',
    [System.Windows.Forms.MessageBoxButtons]::YesNo,
    [System.Windows.Forms.MessageBoxIcon]::Question,
    [System.Windows.Forms.MessageBoxDefaultButton]::Button2
)

echo $result

# System Dialog

[System.Windows.Forms.FolderBrowserDialog] $dialog = [System.Windows.Forms.FolderBrowserDialog]::new()
$dialog.ShowNewFolderButton = $false
$dialog.ShowDialog()
$dialog.SelectedPath

# Custom Form

[System.Windows.Forms.Label] $osLabel = [System.Windows.Forms.Label]::new()
$osLabel.Text = 'Operating system:'

[System.Windows.Forms.Label] $computerNameLabel = [System.Windows.Forms.Label]::new()
$computerNameLabel.Text = 'Computer name:'

[System.Windows.Forms.TextBox] $osTextBox = [System.Windows.Forms.TextBox]::new()
$osTextBox.Text = 'Loading...'
$osTextBox.Dock = [System.Windows.Forms.DockStyle]::Fill

[System.Windows.Forms.TextBox] $computerNameTextBox = [System.Windows.Forms.TextBox]::new()
$computerNameTextBox.Text = 'Loading...'
$computerNameTextBox.Dock = [System.Windows.Forms.DockStyle]::Fill

[System.Windows.Forms.Button] $reloadButton = [System.Windows.Forms.Button]::new()
$reloadButton.Text = 'Reload'
$reloadButton.Add_Click({
    $computerNameTextBox.Text = $env:COMPUTERNAME
    $osTextBox.Text = (Get-WmiObject -Class Win32_OperatingSystem).Caption
})

[System.Windows.Forms.TableLayoutPanel] $panel = [System.Windows.Forms.TableLayoutPanel]::new()
$panel.ColumnCount = 2
$panel.RowCount = 3
$panel.Dock = [System.Windows.Forms.DockStyle]::Fill
$panel.Controls.Add($computerNameLabel, 0, 0)
$panel.Controls.Add($osLabel, 0, 1)
$panel.Controls.Add($computerNameTextBox, 1, 0)
$panel.Controls.Add($osTextBox, 1, 1)
$panel.Controls.Add($reloadButton, 0, 2)

[System.Windows.Forms.Form] $computerWindow = [System.Windows.Forms.Form]::new()
$computerWindow.Size = [System.Drawing.Size]::new(500, 150)
$computerWindow.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
$computerWindow.MaximizeBox = $false
$computerWindow.MinimizeBox = $false
$computerWindow.Text = 'Computer information'
$computerWindow.Controls.Add($panel)
$computerWindow.ShowDialog()