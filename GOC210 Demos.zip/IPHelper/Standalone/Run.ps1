#Region Get-IPAddressCountry Test
.\Get-IPAddressCountry.ps1 -IPAddress 8.8.8.8
#Endregion Get-IPAddressCountry Test

#Region Get-PublicIPAddress Test
.\Get-PublicIPAddress -AsString
(.\Get-PublicIPAddress.ps1).AddressFamily

(& '.\Get-PublicIPAddress.ps1').IPAddressToString
#Endregion Get-PublicIPAddress Test

pause