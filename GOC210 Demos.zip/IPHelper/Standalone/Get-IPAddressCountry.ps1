<#
.SYNOPSIS
Gets the country where the provided IP address is located in.

.PARAMETER IPAddress
One or more IP addresses to get the country of.

.EXAMPLE
.\Get-IPAddressCountry.ps1 -IPAddress 8.8.8.8

Gets the country where 8.8.8.8 is located.

.EXAMPLE
.\Get-IPAddressCountry.ps1 8.8.8.8

.EXAMPLE
'212.24.152.82','8.8.8.8' | Get-IPAddressCountry

.LINK
.\Get-PublicIPAddress.ps1

.NOTES
Author: Michael Grafnetter
Version: 2.0

#>

#Requires -Modules Microsoft.PowerShell.Utility -Version 3

param(
    [Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
    [ValidatePattern('^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$')]
    # [ValidateScript({ $PSItem | Foreach-Object { [ipaddress]::TryParse($PSItem, [ref] $null) } })]
    [Alias('IP')]
    [string[]]
    $IPAddress
)

process
{
    foreach ($ip in $IPAddress) {
        [string] $uri = 'https://ip2c.org/?ip={0}' -f $ip
        [string] $response = Invoke-RestMethod -Uri $uri -UseBasicParsing -ErrorAction Stop
        [string] $country = $response.Split(';')[3]

        Write-Output -InputObject ([PSCustomObject]@{
            IPAddress = $ip
            Country = $country
        })
    }
}