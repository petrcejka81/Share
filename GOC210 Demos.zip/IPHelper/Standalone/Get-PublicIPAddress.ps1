
<#PSScriptInfo

.VERSION 1.0

.GUID 3306ccfa-ade3-47a1-b254-511f5139e935

.AUTHOR Michael Grafnetter

.COMPANYNAME 

.COPYRIGHT 

.TAGS 

.LICENSEURI 

.PROJECTURI 

.ICONURI 

.EXTERNALMODULEDEPENDENCIES 
Microsoft.PowerShell.Utility

.REQUIREDSCRIPTS 

.EXTERNALSCRIPTDEPENDENCIES 

.RELEASENOTES

#>

<#
.SYNOPSIS
Returns the public IP address of this computer.

.DESCRIPTION
Gets the public IP address of the computer. 

.PARAMETER AsString
If present, returns the IP address as a string.

.EXAMPLE
Get-PublicIpAddress

Returns the public IP address of this computer in the form of an IPAddress object.

.EXAMPLE
Get-PublicIpAddress -AsString

Returns the public IP address of this computer in the form of a string.

.NOTES
Author: Michael Grafnetter
Version: 1.1

#>

#Requires -Modules Microsoft.PowerShell.Utility -Version 3

[OutputType([ipaddress],[string])]
param(
    [switch] $AsString
)

[string] $endpoint = 'https://api.ipify.org/'
[string] $ip = Invoke-RestMethod -Uri $endpoint -UseBasicParsing

if($AsString.IsPresent)
{
    return $ip
}
else
{
    return [ipaddress] $ip
}


