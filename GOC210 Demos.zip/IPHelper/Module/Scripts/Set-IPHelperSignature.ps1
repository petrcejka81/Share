$cer = Get-ChildItem -Path Cert:\CurrentUser\My -CodeSigningCert |
            Where-Object Subject -Like '*Test*'

$modulePath = Join-Path -Path $PSScriptRoot -ChildPath ..\IPHelper
$filesToSign = Get-ChildItem -Path $modulePath -Recurse -File -Filter '*.psm1' |
                    Select-Object -ExpandProperty FullName

Set-AuthenticodeSignature -FilePath $filesToSign `
                          -Certificate $cer `
                          -HashAlgorithm SHA256 `
                          -Force

# Get-AuthenticodeSignature -FilePath "E:\Poznamky\IPHelperModule\IPHelper\IPHelper.psm1"