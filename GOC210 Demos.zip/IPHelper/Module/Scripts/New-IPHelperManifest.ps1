# New-Guid
# [System.IO.Path]::DirectorySeparatorChar

$manifestPath = Join-Path -Path $PSScriptRoot -ChildPath '..\IPHelper\IPHelper.psd1'

New-ModuleManifest -Guid 91ae40fe-70cf-425c-9023-e77887fc3367 `
                   -RootModule IPHelper.psm1 `
                   -Path $manifestPath `
                   -CompanyName Gopas `
                   -Author 'Michael Grafnetter' `
                   -Copyright '(c) Michael Grafnetter 2021' `
                   -ModuleVersion '1.0' `
                   -PowerShellVersion '5.1' `
                   -FunctionsToExport Get-PublicIPAddress,Get-IPAddressCountry `
                   -AliasesToExport WhatIsMyIp,ip `
                   -CmdletsToExport @() `
                   -VariablesToExport @() `
                   -Description 'IP Helper Module' `
                   -CompatiblePSEditions Core,Desktop



