Import-Module -Name "$PSScriptRoot\IPHelper"

Get-PublicIPAddress