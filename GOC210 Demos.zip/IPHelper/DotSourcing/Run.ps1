. $PSScriptRoot\IPHelper.ps1

Get-IPAddressCountry -IPAddress '8.8.8.8'