﻿# Web Services (SOAP)
New-WebServiceProxy -Uri

# REST API

$uri = 'https://api.github.com/repos/PowerShell/PowerShell/releases'
$headers = @{
    Accept = 'application/vnd.github.v3+json'
}

$result = Invoke-RestMethod -Uri $uri -Method Get -Headers $headers -UseBasicParsing
$result[0].name
$result[0].created_at
$result[0].assets.Length
$result[0].assets[0].name
$result[0].assets[0].download_count

[datetime]::Parse($result[0].assets[0].created_at).AddDays(10)
[datetime]::Parse($result[0].assets[0].created_at).DayOfWeek

# Task 1: Number of downloads of the latest PowerShell release.
#Requires -Version 4

$uri = 'https://api.github.com/repos/PowerShell/PowerShell/releases'
$headers = @{
    Accept = 'application/vnd.github.v3+json'
}

$result = Invoke-RestMethod -Uri $uri -Method Get -Headers $headers -UseBasicParsing 

$result[0].assets | ForEach-Object -Begin { $sum = 0 } -Process { $sum += $PSItem.download_count } -End { $sum }

$result[0].assets | Measure-Object -Property download_count -Sum | Select-Object -ExpandProperty Sum
$result[0].assets | Measure-Object -Property download_count -Sum | ForEach-Object -MemberName Sum
$result[0].assets | Measure-Object -Property download_count -Sum | foreach Sum
$result[0].assets | Measure-Object -Property download_count -Sum | % Sum


Invoke-RestMethod -Uri $uri -Method Get -Headers $headers -UseBasicParsing |
    ForEach-Object { $PSItem[0] } | # Select-Object -First 1
    Select-Object -ExpandProperty assets |
    Measure-Object -Property download_count -Sum |
    Select-Object -ExpandProperty Sum

#Get-ChildItem -Path C:\Windows -File -Recurse | Select-Object -First 3



# Task 2: Number of downloads per PowerShell release.
$releases = Invoke-RestMethod -Uri $uri -Method Get -Headers $headers -UseBasicParsing 

$releases | Select-Object -Property @{ n = 'Release'; e = { $PSItem.name } },
                                    @{ n = 'Downloads'; e = { $PSItem.assets |
                                                              Measure-Object -Property download_count -Sum |
                                                              ForEach-Object -MemberName Sum } }


Invoke-RestMethod -Uri $uri -Method Get -Headers $headers -UseBasicParsing |
    Select-Object -Property @{ n = 'Release'; e = { $PSItem.name } },
                            @{ n = 'Downloads'; e = { $PSItem.assets |
                                                        Measure-Object -Property download_count -Sum |
                                                        ForEach-Object -MemberName Sum } }



# Alternative:
Invoke-WebRequest -Uri $uri -UseBasicParsing | ConvertFrom-Json




function Get-PublicIPAddress
{
    [OutputType([ipaddress],[string])]
    param(
        [switch]
        $AsString
    )

    [string] $uri = 'https://api.ipify.org'
    [string] $ip = Invoke-RestMethod -Uri $uri -UseBasicParsing

    if($AsString.IsPresent)
    {
        return $ip
    }
    else
    {
        return [ipaddress] $ip
    }
}

Get-PublicIPAddress -AsString
(Get-PublicIPAddress).AddressFamily


$uri = 'https://api.ip2country.info/ip?212.24.152.82'
$result = Invoke-RestMethod -Uri $uri -UseBasicParsing
$result.countryName






Function Get-IPAddressCountry {
    param(
        [Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
        # [ValidatePattern('^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$')]
        [ValidateScript({ $PSItem | Foreach-Object { [ipaddress]::TryParse($PSItem, [ref] $null) } })]
        [Alias('IP')]
        [string[]]
        $IPAddress
    )

    process
    {
        foreach ($ip in $IPAddress) {
            $uri = 'https://api.ip2country.info/ip?{0}' -f $ip
            $result = Invoke-RestMethod -Uri $uri -UseBasicParsing
            
            Write-Output -InputObject (New-Object -TypeName PSObject -Property @{
                IPAddress = $ip
                Country = $result.countryName
            })
        }
    }
}

Get-IPAddressCountry -IP '8.8.8.8'

'212.24.152.82','8.8.8.8' | Get-IPAddressCountry | Out-GridView

@'
Hostname;IPAddress
Gopas;212.24.152.82
Google;8.8.8.8
'@ | ConvertFrom-Csv -Delimiter ';' | Get-IPAddressCountry



[ipaddress] $result = $null
[ipaddress]::TryParse('212.24.152.82', [ref] $result)

[ipaddress]::TryParse('212.24.152.82', [ref] $null)
[ipaddress]::TryParse('::1', [ref] $null)
[ipaddress]::TryParse('sklgjsdklgshdghs', [ref] $null)

'212.24.152.82','hskjhgsjkdghsjd' | foreach { [ipaddress]::TryParse($PSItem, [ref] $null) }



Get-IPAddressCountry -IPAddress hskjhgsjkdghsjd
Get-IPAddressCountry -IPAddress 'asfasfasf',212.24.152.82,8.8.8.8





Get-IPAddressCountry -IPAddress 212.24.152.82
Get-IPAddressCountry 212.24.152.82


Get-PublicIPAddress -AsString | Get-IPAddressCountry
212.24.152.82 | Get-IPAddressCountry

$env:PSModulePath -split ';'

Get-WmiObject -Class Win32_Volume


# Port TCP 5985
$session = New-CimSession -ComputerName student928-02
Get-Volume -CimSession $session
Remove-CimSession -CimSession $session