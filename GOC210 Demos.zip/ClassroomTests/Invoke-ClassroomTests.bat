@ECHO OFF

REM Executing the PS script
powershell.exe -NoProfile -NonInteractive -NoLogo -ExecutionPolicy Bypass -File "%~dpn0.ps1"

pause