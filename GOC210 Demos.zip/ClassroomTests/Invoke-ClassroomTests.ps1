#requires -Version 5 -Modules @{ ModuleName = 'Pester'; ModuleVersion = '5.0' }

#region Variables
[string] $testsPath = Join-Path -Path $PSScriptRoot -ChildPath '*.Tests.ps1'
[string] $outputDirectory = Join-Path -Path $PSScriptRoot -ChildPath 'Results'
[string] $xmlResultsPath = Join-Path -Path $outputDirectory -ChildPath 'Results.xml'
[string] $htmlreportPath = Join-Path -Path $outputDirectory -ChildPath 'Results.html'
[string] $extent = Join-Path -Path $PSScriptRoot -ChildPath 'extent.exe'

[string] $htmlHead = @'
<style type="text/css">
    table, th, td {
          border: 1px solid;
          border-spacing: 0px;
    }
</style>
<script
    src="https://code.jquery.com/jquery-3.6.0.slim.min.js"
	integrity="sha256-u7e5khyithlIdTpu22PHhENmPcRdFiHRjhAuHcs05RI="
	crossorigin="anonymous">
</script>
<script>
// Colorize table rows based on Success/Failure using jQuery (does not work in MSIE).
$(document).ready(function() {
    $("td").each(function(){
        if($(this).text() == "Passed"){
            $(this).parent().css("background-color", "#77dd77");
        } else if($(this).text() == "Failed"){
            $(this).parent().css("background-color", "#ff6961");
        } else if($(this).text() == "Inconclusive" || $(this).text() == "Skipped"){
            $(this).parent().css("background-color", "#fdfd96");
        }
    })
});
</script>
<title>Test Results</title>
'@

#endregion Variables

# Create the Reports directory
New-Item -Path $outputDirectory -ItemType Directory -Force | Out-Null

# Prepare test options
[Pester.ContainerInfo] $testParams = New-PesterContainer -Path $testsPath -Data @{
    RoomNumber = 1033
    ComputerCount = 9
}

[PesterConfiguration] $testConfig = New-PesterConfiguration
$testConfig.Run.Container = $testParams
$testConfig.Output.Verbosity = 'Detailed'
$testConfig.TestResult.Enabled = $true
$testConfig.TestResult.OutputFormat = 'NUnitXml'
$testConfig.TestResult.OutputPath = $xmlResultsPath
$testConfig.Run.Exit = $false
$testConfig.Run.PassThru = $true

# Run tests
Invoke-Pester -Configuration $testConfig |
    Select-Object -ExpandProperty Tests | 
    Select-Object -Property @{ n = 'Category'; e = { $PSItem.Path[0] }},
                            @{ n = 'Context';  e = { $PSItem.Path[1] }},
                            ExpandedName,
                            Result,
                            @{ n = 'Error'; e = { $PSItem.ErrorRecord.DisplayErrorMessage } } |
    ConvertTo-Html -PreContent '<h1>Test Results</h1>' -Head $htmlHead |
    Out-File -FilePath $htmlreportPath -Encoding utf8 -Force

# Generate HTML Reports
# Extent homepage: https://github.com/extent-framework/extentreports-dotnet-cli
# Download extent: https://www.nuget.org/packages/ExtentReports/
& $extent -i $xmlResultsPath -o $outputDirectory
