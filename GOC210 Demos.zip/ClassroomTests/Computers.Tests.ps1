#Requires -Modules @{ ModuleName = 'Pester'; ModuleVersion = '5.0' }

param(
    [Parameter(Mandatory = $true)]
    [ValidateRange(900,1050)]
    [uint16] $RoomNumber,

    [Parameter(Mandatory = $false)]
    [ValidateRange(1,20)]
    [byte] $ComputerCount = 12
)

Describe Computers {
    BeforeDiscovery {
        [hashtable[]] $computers = 1..$ComputerCount | ForEach-Object { @{ ComputerName = 'STUDENT{0}-{1:D2}' -f $RoomNumber,$PSItem } }

        foreach($computer in $computers) {
            [bool] $isAvailable = Test-Connection -ComputerName $computer.ComputerName -Count 1 -Quiet
            $computer.Add('Available', $isAvailable)
        }
    }
    Context Connectivity {
        It '<ComputerName> should be available' -ForEach $computers {
            $Available | Should -BeTrue
        }
    }
    Context 'Hyper-V' {
        It '<ComputerName> should have the Hyper-V role installed' -ForEach $computers {
            if(-not $Available) {
                Set-ItResult -Skipped -Because 'the computer is not online'
            } else {
                Get-WindowsFeature -ComputerName $ComputerName -Name Hyper-V |
                    Select-Object -ExpandProperty Installed |
                    Should -BeTrue
            }
        }
    }
}