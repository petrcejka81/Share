<#
.SYNOPSIS
TODO

#>

#Requires -Version 5

[CmdletBinding()]
[OutputType([string])]
param(
    [Parameter(Mandatory = $true)]
    [string] $Path,

    [Parameter(Mandatory = $true)]
    [string] $Section,

    [Parameter(Mandatory = $true)]
    [string] $Key,

    [Parameter(Mandatory = $false)]
    [string] $DefaultValue
)

[string] $signature = @'
[DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
public static extern uint GetPrivateProfileString(
    string lpAppName,
    string lpKeyName,
    string lpDefault,
    StringBuilder lpReturnedString,
    uint nSize,
    string lpFileName);
'@

if (-not ([System.Management.Automation.PSTypeName]'GOC210.Win32Utils').Type)
{
    Add-Type -MemberDefinition $signature `
             -Name Win32Utils `
             -Namespace GOC210 `
             -Using System.Text
}

[string] $absolutePath = Split-Path -Path $Path -Resolve -NoQualifier

[System.Text.StringBuilder] $result = [System.Text.StringBuilder]::new()
$result.Capacity = 128

[UInt32] $numChars = [GOC210.Win32Utils]::GetPrivateProfileString(
    $Section,
    $Key,
    $DefaultValue,
    $result,
    $result.Capacity,
    $absolutePath
)

[int] $resultCode = [System.Runtime.InteropServices.Marshal]::GetLastWin32Error()

if($resultCode -ne 0) {
    [System.Exception] $ex = [System.ComponentModel.Win32Exception]::new($resultCode)
    Write-Error -Exception $ex -ErrorId 1 -Category OpenError -TargetObject $Path
    return
}

return $result.ToString()