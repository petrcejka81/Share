$signature = @'
[DllImport("kernel32.dll")]
public static extern uint GetPrivateProfileString(
    string lpAppName,
    string lpKeyName,
    string lpDefault,
    StringBuilder lpReturnedString,
    uint nSize,
    string lpFileName);
'@

$type = Add-Type -MemberDefinition $signature `
                 -Name Win32Utils `
                 -Namespace GOC210 `
                 -Using System.Text `
                 -PassThru

$absolutePath = Resolve-Path -Path sample.ini

$result = [System.Text.StringBuilder]::new()
$result.Capacity = 128

$resultCode = [GOC210.Win32Utils]::GetPrivateProfileString(
    'database',
    'server',
    'unknown',
    $result,
    $result.Capacity,
    $absolutePath
)

$result.ToString()