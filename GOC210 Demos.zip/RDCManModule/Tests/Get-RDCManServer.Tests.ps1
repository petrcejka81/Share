#Requires -Modules @{ ModuleName = 'Pester'; ModuleVersion = '5.0' }

Describe 'Get-RDCManServer' {
    BeforeAll {
        Import-Module -Name "$PSScriptRoot\..\RDCMan" -ErrorAction Stop

        [string] $tempFile = New-TemporaryFile
        Set-Content -Path $tempFile -Encoding UTF8 -Value @'
<?xml version="1.0" encoding="utf-8"?>
<RDCMan programVersion="2.93" schemaVersion="3">
  <file>
    <properties>
      <expanded>True</expanded>
      <name>HyperV</name>
    </properties>
    <server>
      <properties>
        <displayName>GOC210-DC</displayName>
        <name>GOC210-DC.contoso.com</name>
      </properties>
    </server>
    <server>
      <properties>
        <displayName>GOC210-PC</displayName>
        <name>GOC210-PC.contoso.com</name>
      </properties>
    </server>
  </file>
</RDCMan>
'@
    }

    It 'should return 2 servers' {
        Get-RDCManServer -Path $tempFile | Should -HaveCount 2
    }
}