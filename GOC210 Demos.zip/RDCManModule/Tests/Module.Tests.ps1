#Requires -Modules @{ ModuleName = 'Pester'; ModuleVersion = '5.0' }

Describe 'Module' {
    It 'Manifest must be valid' {
        Test-ModuleManifest -Path "$PSScriptRoot\..\RDCMan\RDCMan.psd1" -ErrorAction Stop
    }

    It 'Must export 3 commands' {
        Test-ModuleManifest -Path "$PSScriptRoot\..\RDCMan\RDCMan.psd1" -ErrorAction SilentlyContinue |
            Select-Object -ExpandProperty ExportedCommands |
            ForEach-Object -MemberName Keys |
            Should -HaveCount 3
    }
}