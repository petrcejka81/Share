#Requires -Modules @{ ModuleName = 'Pester'; ModuleVersion = '5.0' }

Invoke-Pester -Path "$PSScriptRoot\..\Tests" `
              -OutputFile "$PSScriptRoot\..\TestResults\Pester.xml" `
              -OutputFormat NUnit2.5