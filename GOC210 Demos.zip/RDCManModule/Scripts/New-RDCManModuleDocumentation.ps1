#Requires -Modules platyPS
# Install-Module platyps -Force

[string] $modulePath = Join-Path -Path $PSScriptRoot -ChildPath '..\RDCMan'
Import-Module -Name $modulePath -ErrorAction Stop

[string] $docPath = Join-Path -Path $PSScriptRoot -ChildPath '..\Documentation'
New-MarkdownHelp -Module RDCMan -OutputFolder $docPath -WithModulePage -Force

[string] $xmlDocPath = Join-Path -Path $modulePath -ChildPath 'en-US'
New-ExternalHelp -Path $docPath -OutputPath $xmlDocPath -Force

Move-Item -Path "$docPath\RDCMan.md" -Destination "$docPath\README.md" -Force