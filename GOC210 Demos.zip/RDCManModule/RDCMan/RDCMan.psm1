<#
.SYNOPSIS
Lists all server records from an existing Remote Desktop Connection Manager file.

.EXAMPLE
PS> Get-RDCManServer -Path .\HyperV.rdg

#>
function Get-RDCManServer {
    [CmdletBinding()]
    [OutputType([pscustomobject])]
    param(
        [Parameter(Mandatory = $true)]
        [string] $Path
    )

    [hashtable] $nameProperty = @{
        Label = 'Name'
        Expression = { $PSItem.Node.name }
    }
    
    [hashtable] $displayNameProperty = @{
        Name = 'DisplayName'
        Expression = { $PSItem.Node.displayName }
    }
    
    Select-Xml -Path $Path -XPath '/RDCMan/file/server/properties' |
        Select-Object -Property $nameProperty,$displayNameProperty
}

<#
.SYNOPSIS
Adds a server record to an existing Remote Desktop Connection Manager file.

.EXAMPLE
PS> Add-RDCManServer -Path .\HyperV.rdg -Name 'GOC210-SRV1.contoso.com' -DisplayName 'GOC210-SRV1'

.EXAMPLE
PS> 'GOC210-SRV2.contoso.com','GOC210-SRV3.contoso.com' | Add-RDCManServer -Path .\HyperV.rdg

#>
function Add-RDCManServer {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string] $Path,

        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
        [ValidateLength(1, 256)]
        [ValidatePattern('[a-zA-Z0-9\-\.]+')]
        [string] $Name,

        [Parameter(Mandatory = $false, ValueFromPipelineByPropertyName = $true)]
        [ValidateNotNullOrEmpty()]
        [string] $DisplayName
    )

    begin {
        [xml] $rdg = Get-Content -Path $Path -Encoding utf8 -ErrorAction Stop
        [System.Xml.XmlNode] $fileNode = $rdg.SelectSingleNode('/RDCMan/file')
    }
    
    process {
        if([string]::IsNullOrWhiteSpace($DisplayName)) {
            $DisplayName = $Name
        }

        [System.Xml.XmlElement] $server = $rdg.CreateElement('server')
        $server.InnerXml = '<properties><displayName>{0}</displayName><name>{1}</name></properties>' -f $DisplayName,$Name
        $fileNode.AppendChild($server) > $null
    }

    end {
        [System.Management.Automation.PathInfo] $absolutePath = Resolve-Path -Path $Path -ErrorAction Stop
        $rdg.Save($absolutePath.Path)
    }
}

New-Alias -Name grd -Value Get-RDCManServer

Export-ModuleMember -Function Get-RDCManServer,Add-RDCManServer -Alias grd