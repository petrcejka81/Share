---
external help file: RDCMan-help.xml
Module Name: RDCMan
online version:
schema: 2.0.0
---

# Add-RDCManServer

## SYNOPSIS
Adds a server record to an existing Remote Desktop Connection Manager file.

## SYNTAX

```
Add-RDCManServer [-Path] <String> [-Name] <String> [[-DisplayName] <String>] [<CommonParameters>]
```

## DESCRIPTION
{{ Fill in the Description }}

## EXAMPLES

### EXAMPLE 1
```
Add-RDCManServer -Path .\HyperV.rdg -Name 'GOC210-SRV1.contoso.com' -DisplayName 'GOC210-SRV1'
```

### EXAMPLE 2
```
'GOC210-SRV2.contoso.com','GOC210-SRV3.contoso.com' | Add-RDCManServer -Path .\HyperV.rdg
```

## PARAMETERS

### -Path
{{ Fill Path Description }}

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Name
{{ Fill Name Description }}

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 2
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -DisplayName
{{ Fill DisplayName Description }}

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 3
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS
