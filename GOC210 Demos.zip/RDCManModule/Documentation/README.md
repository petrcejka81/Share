---
Module Name: RDCMan
Module Guid: 0485898f-5436-40b0-af15-1f2cfb145689
Download Help Link: {{ Update Download Link }}
Help Version: {{ Please enter version of help manually (X.X.X.X) format }}
Locale: en-US
---

# RDCMan Module
## Description
{{ Fill in the Description }}

## RDCMan Cmdlets
### [Add-RDCManServer](Add-RDCManServer.md)
{{ Fill in the Description }}

### [Get-RDCManServer](Get-RDCManServer.md)
{{ Fill in the Description }}

