﻿<#
.SYNOPSIS
Compare RootCAs with other server

#>

#Requires -Version 3

#scriptblock
$GetRootCAs = {
    Get-ChildItem -Path Cert:\LocalMachine\Root | Select-Object -Property Thumbprint, Subject
}

#params
$localRootCAsDestination = Join-Path -Path $PSScriptRoot -ChildPath 'exportLocalRootCAs.csv'

[string] $remoteComputerName = 'STUDENT926-01'

#get local CAs and save it
$localRootCAs = Invoke-Command -ScriptBlock $GetRootCAs
$localRootCAs | Export-Csv -Path $localRootCAsDestination -NoTypeInformation -Encoding UTF8

#get remote CAs
$remoteRootCAs = Invoke-Command -ComputerName $remoteComputerName -ScriptBlock $GetRootCAs

#compare local and remote CAs
Write-Host "These certs are in addition on remote computer '$($remoteComputerName)':"

$addititionalCerts =
    Compare-Object -ReferenceObject $localRootCAs -DifferenceObject $remoteRootCAs -Property Thumbprint -PassThru | 
    Where-Object SideIndicator -eq '=>' | 
    Select-Object -Property Thumbprint, Subject

if ($null -ne $addititionalCerts)
{
    $addititionalCerts
}
else
{
    Write-Host 'none'
}