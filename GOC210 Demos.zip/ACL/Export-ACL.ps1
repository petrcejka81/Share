<#
.SYNOPSIS
TODO

.EXAMPLE
PS> Get-ACL -Path E:\Test | Export-ACL -OutputPath e:\acl.html

.EXAMPLE
Get-ACL -Path registry::HKEY_LOCAL_MACHINE\SOFTWARE | Export-ACL -OutputPath e:\acl.html

#>

#Requires -Version 5

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
    [System.Security.AccessControl.NativeObjectSecurity] $InputObject,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrWhiteSpace()]
    [string] $OutputPath
)

begin {
    [System.Collections.Generic.List[System.Security.AccessControl.AuthorizationRule]] $accessControlEntries = @()

    [string] $htmlHead = @'
<style type="text/css">
    table, th, td {
          border: 1px solid;
          border-spacing: 0px;
    }
</style>
<title>Permissions</title>
'@

}
process {
    [System.Security.AccessControl.AuthorizationRuleCollection] $currentEntries =
        $InputObject.GetAccessRules($true, $true, [System.Security.Principal.NTAccount])

    [string] $path = Split-Path -Path $InputObject.Path -NoQualifier

    foreach($entry in $currentEntries) {
        Add-Member -InputObject $entry -MemberType NoteProperty -Name Path -Value $path 

        if($entry -is [System.Security.AccessControl.FileSystemAccessRule]) {
            Add-Member -InputObject $entry -MemberType AliasProperty -Name Right -Value FileSystemRights
        } elseif($entry -is [System.Security.AccessControl.RegistryAccessRule]) {
            Add-Member -InputObject $entry -MemberType AliasProperty -Name Right -Value RegistryRights
        }

        [void] $accessControlEntries.Add($entry)
    }
}
end {
    $accessControlEntries |
        Select-Object -Property Path,IsInherited,IdentityReference,Right,AccessControlType |
        ConvertTo-Html -PreContent '<h1>Permissions</h1>' -Head $htmlHead |
        Out-File -FilePath $OutputPath -Encoding utf8 -Force
}
