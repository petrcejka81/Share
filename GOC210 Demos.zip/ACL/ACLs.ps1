[string] $dirPath = 'E:\Test'
New-Item -Path $dirPath -ItemType Directory -Force

[string] $user = 'Admin'
icacls.exe $dirPath /grant "${user}:(OI)(CI)M"

# dsacls.exe

<#
.SYNOPSIS
Adds a new file system ACE to an existing DACL.
#>
function Add-AccessControlEntry {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string] $Identity,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string] $Path,

        [Parameter(Mandatory = $true)]
        [System.Security.AccessControl.FileSystemRights[]] $Right,

        [Parameter(Mandatory = $false)]
        [switch] $ObjectInherit,

        [Parameter(Mandatory = $false)]
        [switch] $ContainerInherit,

        [Parameter(Mandatory = $false)]
        [switch] $InheritOnly,

        [Parameter(Mandatory = $false)]
        [switch] $NoPropagateInherit,

        [Parameter(Mandatory = $false)]
        [System.Security.AccessControl.AccessControlType] $Type = [System.Security.AccessControl.AccessControlType]::Allow
    )

    [System.Security.AccessControl.FileSystemSecurity] $acl = Get-Acl -Path $Path
    
    [System.Security.AccessControl.InheritanceFlags] $inheritance = [System.Security.AccessControl.InheritanceFlags]::None

    if($ObjectInherit.IsPresent) {
        $inheritance += [System.Security.AccessControl.InheritanceFlags]::ObjectInherit
    }

    if($ContainerInherit.IsPresent) {
        $inheritance += [System.Security.AccessControl.InheritanceFlags]::ContainerInherit
    }

    [System.Security.AccessControl.PropagationFlags] $propagation = [System.Security.AccessControl.PropagationFlags]::None

    if($InheritOnly.IsPresent) {
        $propagation += [System.Security.AccessControl.PropagationFlags]::InheritOnly
    }

    if($NoPropagateInherit.IsPresent) {
        $propagation += [System.Security.AccessControl.PropagationFlags]::NoPropagateInherit
    }

    [System.Security.AccessControl.FileSystemRights] $accessFlags = 0

    foreach($flag in $Right) {
        $accessFlags = $accessFlags -bor $flag 
    }

    [System.Security.AccessControl.FileSystemAccessRule] $ace = [System.Security.AccessControl.FileSystemAccessRule]::new(
        $Identity,
        $accessFlags,
        $inheritance,
        $propagation,
        $Type
    )

    $acl.AddAccessRule($ace)
    
    [bool] $verboseIsPresent =  $VerbosePreference -eq [System.Management.Automation.ActionPreference]::Continue
    Set-Acl -Path $Path -AclObject $acl -Verbose:$verboseIsPresent
}

Add-AccessControlEntry -Identity $user -Path $dirPath -Type Allow -Right ChangePermissions,CreateFiles,Delete -ObjectInherit -NoPropagateInherit -WhatIf -Verbose

Show-Command Add-AccessControlEntry
