[string] $oidIsCA = '2.5.29.19'
[string] $oidExtendedKeyUsage = '2.5.29.37'
[string] $oidDocumentEncryption = '1.3.6.1.4.1.311.80.1'
[string] $oidSubjectKeyIdentifier = '2.5.29.14'
[datetime] $now = Get-Date
New-SelfSignedCertificate -Subject 'CN=Test Certificate' `
                          -FriendlyName 'Test Certificate' `
                          -KeyLength 2KB `
                          -KeyAlgorithm RSA `
                          -HashAlgorithm SHA256 `
                          -NotBefore $now `
                          -NotAfter $now.AddYears(2) `
                          -CertStoreLocation 'Microsoft.PowerShell.Security\Certificate::LocalMachine\My' `
                          -Provider 'Microsoft Platform Crypto Provider' `
                          -KeyExportPolicy NonExportable `
                          -KeyUsage DataEncipherment `
                          -Type DocumentEncryptionCert `
                          -TextExtension "$oidIsCA={text}false",
                                         "$oidExtendedKeyUsage={text}$oidDocumentEncryption" `
                          -SuppressOid $oidSubjectKeyIdentifier
                          # -SecurityDescript

Protect-CmsMessage -To 'CN=Test Certificate' -Content Heslo

[System.Security.Cryptography.X509Certificates.X509Certificate2] $verisignOrig =
    Get-ChildItem -Path 'Certificate::LocalMachine\Root' | Where-Object FriendlyName -eq VeriSign

[System.Security.Cryptography.X509Certificates.X509Certificate2] $verisignClone =
    New-SelfSignedCertificate -CloneCert $verisignOrig `
                              -CertStoreLocation 'Certificate::LocalMachine\My'

New-SelfSignedCertificate -Subject 'CN=*.microsoft.com' `
                          -DnsName '*.microsoft.com' `
                          -Type SSLServerAuthentication `
                          -CertStoreLocation 'Certificate::LocalMachine\My' `
                          -Signer $verisignClone