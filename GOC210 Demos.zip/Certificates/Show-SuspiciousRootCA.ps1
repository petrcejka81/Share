param(
    [Parameter(Mandatory = $false)]
    [string] $ReferenceFilePath = 'trust.csv'
)

[System.Collections.Generic.HashSet[string]] $msTrustedHashes = [System.Collections.Generic.HashSet[string]]::new()

Import-Csv -Path $ReferenceFilePath -Delimiter ',' -Encoding UTF8 | ForEach-Object {
    [void] $msTrustedHashes.Add($PSItem.'SHA-1 Fingerprint')
}

[datetime] $now = Get-Date
Get-ChildItem -Path 'certificate::LocalMachine\Root' |
    Where-Object NotAfter -ge $now |
    Where-Object Thumbprint -notin $msTrustedHashes |
    Select-Object -Property Subject,NotBefore,NotAfter,Thumbprint
    Out-GridView -Title 'Custom Root CAs' -Wait