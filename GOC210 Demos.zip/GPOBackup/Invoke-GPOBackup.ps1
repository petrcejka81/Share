<#
.SYNOPSIS
Creates a backup of all GPOs in the C:\GPOBackup directory.

.DESCRIPTION
Author: Michael Grafnetter
Version: 1.0

#>

#requires -Version 5 -Modules GroupPolicy -RunAsAdministrator

# Create the target directory if it does not exist
[string] $backupPath = Join-Path -Path $env:SystemDrive -ChildPath GPOBackup
New-Item -ItemType Directory -Path $backupPath -Force | Out-Null

# Perform the backup
Backup-GPO -Path $backupPath -All | Out-Null