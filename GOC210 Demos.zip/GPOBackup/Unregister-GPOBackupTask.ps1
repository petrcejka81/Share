<#
.SYNOPSIS
Removes the task that creates daily GPO backups.

#>

#requires -Version 5 -Modules ScheduledTasks -RunAsAdministrator

Unregister-ScheduledTask -TaskName 'Backup All GPOs' -Confirm:$false -Verbose