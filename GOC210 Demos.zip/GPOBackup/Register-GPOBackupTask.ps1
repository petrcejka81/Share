<#
.SYNOPSIS
Creates a task that creates daily GPO backups.

#>

#requires -Version 5 -Modules ScheduledTasks -RunAsAdministrator

[datetime] $midnight = Get-Date -Hour 0 -Minute 0 -Second 0 -Millisecond 0
[ciminstance] $trigger = New-ScheduledTaskTrigger -Daily -At $midnight
[ciminstance] $system = New-ScheduledTaskPrincipal -UserId 'System' -RunLevel Highest
[string] $psPath = Get-Command -Name 'powershell.exe' -CommandType Application | Select-Object -ExpandProperty Source
[string] $scriptPath = Join-Path -Path $PSScriptRoot -ChildPath 'Invoke-GPOBackup.ps1'
[string] $psParams = '-ExecutionPolicy Bypass -NonInteractive -NoProfile -NoLogo -File "{0}"' -f $scriptPath
[ciminstance] $action = New-ScheduledTaskAction -Execute $psPath -Argument $psParams
Register-ScheduledTask -TaskName 'Backup All GPOs' `
                       -Trigger $trigger `
                       -Action $action `
                       -Principal $system `
                       -Force
