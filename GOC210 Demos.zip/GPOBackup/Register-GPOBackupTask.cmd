@ECHO OFF
REM Runs the PowerShell script that has the same name as this batch file.
powershell.exe -ExecutionPolicy Bypass -NoProfile -NoLogo -File "%~dpn0.ps1"

REM Press any key to continue
pause