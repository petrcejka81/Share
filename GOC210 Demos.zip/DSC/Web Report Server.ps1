#region Pull Service Query
function Get-DscAgentId
{
    [OutputType([guid])]
    param
    (
        [Parameter(ValueFromPipeline = $true)]
        [ValidateNotNullOrEmpty()]
        [string] $ComputerName = 'localhost'
    )
    
    $session = New-CimSession -ComputerName $ComputerName
    try
    {
        $lcm = Get-DscLocalConfigurationManager -CimSession $session -ErrorAction Stop
        return [guid]$lcm.AgentId
    }
    finally
    {
        Remove-CimSession $session
    }
}

function Get-DscReport
{
    param
    (
        [Parameter(ValueFromPipeline = $true)]
        [ValidateNotNullOrEmpty()]
        [guid] $AgentId = (Get-DscAgentId),

        [ValidateNotNullOrEmpty()]
        [string] $Server = (.\Get-ComputerFQDN),

        [bool] $UseSSL = $true
    )

    
    if($UseSSL)
    {
        $protocol = 'https'
    }
    else
    {
        $protocol = 'http'
    }

    $uri = "{0}://{1}/PSDSCPullServer.svc/Nodes(AgentId='{2}')/Reports" -f $protocol,$Server,$AgentId
    $headers = @{
        Accept = 'application/json'
        ProtocolVersion = '2.0'
    }
    $contentType = 'application/json;odata=minimalmetadata;streaming=true;charset=utf-8'
    $result = Invoke-RestMethod -Uri $uri `
                                -Method Get `
                                -Headers $headers `
                                -ContentType $contentType `
                                -UseBasicParsing
    return $result.value
}

Get-DscAgentId -ComputerName GOC210-SRV3 | Get-DscReport -Server GOC210-SRV1.contoso.com | Out-GridView

Get-DscAgentId -ComputerName GOC210-SRV3 |
    Get-DscReport |
    Select-Object -ExpandProperty StatusData |
    ConvertFrom-Json |
    Out-GridView

#endregion Pull Service Query

#region Direct Database Query
Install-Module DSCPullServerAdmin -Scope AllUsers -Force

Stop-WebAppPool -Name PSWS
[object] $connection = New-DSCPullServerAdminConnection -ESEFilePath "$env:ProgramFiles\WindowsPowerShell\DscService\Devices.edb"
Get-DSCPullServerAdminRegistration -Connection $connection
Get-DSCPullServerAdminStatusReport -Connection $connection -NodeName GOC210-SRV2 -Top 1
Get-DSCPullServerAdminStatusReport -Connection $connection -NodeName GOC210-SRV2 -FromStartTime (Get-Date).AddHours(-1) | Out-GridView
Remove-DSCPullServerAdminConnection -Connection $connection
Start-WebAppPool -Name PSWS

#endregion Direct Database Query

#region Database Contents

Stop-WebAppPool -Name PSWS

# Use Esent Workbench to view the DB contents (C:\Program Files\WindowsPowerShell\DscService\Devices.edb)

Start-WebAppPool -Name PSWS

#endregion Database Contents