@{
    # Node specific data
    AllNodes = @(
       @{
            NodeName = 'GOC210-SRV2'
            Guid     = 'e16daeda-cfb2-43d7-9ee9-93268f6efbf7'
        },
       @{
            NodeName = 'GOC210-SRV3'
            Guid     = '4b7b8f9a-ee7e-429e-b717-311a376ba6cf'
        }
    )
}