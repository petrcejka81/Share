﻿#Requires -Version 5

[DscLocalConfigurationManager()]
Configuration WebClient
{
    param  
    ( 
        [Parameter(Mandatory = $true)]
        [string] $PullServer,

        [Parameter(Mandatory = $true)]
        [string] $RegistrationKey
    )

    Node $AllNodes.NodeName
    {
        Settings
        {
            ConfigurationMode              = 'ApplyAndAutoCorrect'
            RefreshMode                    = 'Pull'
            RebootNodeIfNeeded             = $true
            ActionAfterReboot              = 'ContinueConfiguration'
            ConfigurationModeFrequencyMins = 15
            ConfigurationID                = $null #$Node.Guid
        }

        ConfigurationRepositoryWeb WebRepository
        {
            ServerURL               = "https://$PullServer/PSDSCPullServer.svc"
            RegistrationKey         = $RegistrationKey
            ConfigurationNames      = @($Node.NodeName)
            AllowUnsecureConnection = $false
        }

        ResourceRepositoryWeb WebRepository
        {
            ServerURL               = "https://$PullServer/PSDSCPullServer.svc"
            AllowUnsecureConnection = $false
            RegistrationKey         = $RegistrationKey
        }

        ReportServerWeb WebRepository
        {
            ServerURL               = "https://$PullServer/PSDSCPullServer.svc"
            AllowUnsecureConnection = $false
            RegistrationKey         = $RegistrationKey
        }
    }
}

# Get FQDN of localhost
[string] $serverFQDN = .\Get-ComputerFQDN

# Load the registration key
[string] $registrationKey = Get-Content -Path .\RegistrationKey.txt

# Prepare LCM MOFs
WebClient -ConfigurationData .\Computers.psd1 `
          -PullServer $serverFQDN `
          -RegistrationKey $registrationKey `
          -OutputPath .\MOFClients

# Deploy LCM MOFs
Set-DscLocalConfigurationManager -Path .\MOFClients -Verbose -Force

# Trigger configuration update
[string[]] $computers = (Import-PowerShellDataFile -Path .\Computers.psd1).AllNodes.NodeName
Update-DscConfiguration -ComputerName $computers -Wait -Verbose

# Trigger configuration remediation
Start-DscConfiguration -ComputerName $computers -Wait -Verbose -UseExisting