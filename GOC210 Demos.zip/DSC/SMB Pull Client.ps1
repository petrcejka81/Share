﻿[DscLocalConfigurationManager()]
Configuration SMBClient
{
    param(
        [Parameter(Mandatory = $true)]
        [string] $RepositoryShare
    )

    Node $AllNodes.NodeName
    {
        Settings
        {
            RefreshMode = 'Pull'
            ConfigurationID = $Node.Guid
            ConfigurationMode = 'ApplyAndAutoCorrect'
            ConfigurationModeFrequencyMins = 15
            RefreshFrequencyMins = 30
            RebootNodeIfNeeded = $true
            ActionAfterReboot = 'ContinueConfiguration'
        }

        ConfigurationRepositoryShare SMBRepository
        {
            SourcePath = Join-Path -Path $RepositoryShare -ChildPath Configuration
        }

        ResourceRepositoryShare SMBRepository
        {
            SourcePath = Join-Path -Path $RepositoryShare -ChildPath Modules
        }
    }
}

# Prepare LCM MOFs
[string] $share = '\\{0}\DSCRepository' -f (.\Get-ComputerFQDN.ps1)
SMBClient -RepositoryShare $share -ConfigurationData .\Computers.psd1 -OutputPath .\MOFClients

# Deploy LCM MOFs
Set-DscLocalConfigurationManager -Path .\MOFClients -Verbose -Force

# Trigger configuration update
[string[]] $computers = (Import-PowerShellDataFile -Path .\Computers.psd1).AllNodes.NodeName
Update-DscConfiguration -ComputerName $computers -Wait -Verbose

# Trigger configuration remediation
Start-DscConfiguration -ComputerName $computers -Wait -Verbose -UseExisting

# Check the state
Test-DscConfiguration -ComputerName $computers -Detailed