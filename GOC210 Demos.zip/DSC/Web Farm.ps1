[string[]] $requiredModules = @('xTimeZone', 'NetworkingDsc')
[string[]] $installedModules =
    Get-Module -ListAvailable -Name $requiredModules | 
    Sort-Object -Property Name -Unique |
    Select-Object -ExpandProperty Name

if($requiredModules.Count -gt $installedModules.Count) {
    # Install any missing modules
    Install-PackageProvider -Name NuGet -Scope AllUsers -Force
    Install-Module -Name $requiredModules -Scope AllUsers -Force
}

Configuration WebFarm
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xTimeZone
    Import-DscResource -ModuleName NetworkingDsc

    Node $AllNodes.NodeName
    {
        WindowsFeature IIS
        {
            Ensure = 'Present'
            Name = 'Web-Server'
        }
        
        File HomePage
        {
            DependsOn = '[WindowsFeature]IIS'
            Ensure = 'Present'
            Type = 'File'
            DestinationPath = 'C:\inetpub\wwwroot\index.html'
            Contents = '<h1>Hello World!</h1>'
        }

        Firewall HttpFirewallRule
        {
            Name = 'WebServer-HTTP-In-TCP'
            Ensure = 'Present'
            DisplayName = 'Web Server (HTTP Traffic-In)'
            Protocol = 'TCP'
            LocalPort = 80
            Program = 'System'
            Enabled = 'True'
            Action = 'Allow'
            Profile = 'Public', 'Private', 'Domain'
            Direction = 'Inbound'
        }

        xTimeZone TimeZone
        {
            TimeZone = 'Central Europe Standard Time'
            IsSingleInstance = 'Yes'
        }

        Registry TLS1_2ServerEnabled
        {
            Ensure = 'Present'
            Key = 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server'
            ValueName = 'Enabled'
            ValueData = 1
            ValueType = 'Dword'
        }

        Registry TLS1_2ServerDisabledByDefault
        {
            Ensure = 'Present'
            Key = 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server'
            ValueName = 'DisabledByDefault'
            ValueData = 0
            ValueType = 'Dword'
        }

        Registry SSL2ServerDisabled
        {
            Ensure = 'Present'
            Key = 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server'
            ValueName = 'Enabled'
            ValueData = 0
            ValueType = 'Dword'
        }
    }
}

# Generate MOFs
WebFarm -ConfigurationData .\Computers.psd1 -OutputPath .\MOFClients