﻿#region Break Configuration

# Load the computer list
[string[]] $computers = (Import-PowerShellDataFile -Path .\Computers.psd1).AllNodes.NodeName

Invoke-Command -ComputerName $computers -ScriptBlock {
    # Remove web contents
    Remove-Item -Path C:\inetpub\wwwroot\index.html

    # Remove port 80 firewall rule
    Remove-NetFirewallRule -Name WebServer-HTTP-In-TCP
}

# Uninstall-WindowsFeature -ComputerName $computers[0] -Name Web-Server -IncludeManagementTools -Restart

# Check the status
Test-DscConfiguration -ComputerName $computers -Detailed 

#endregion Break Configuration

#region Remediate

# Repair
Start-DscConfiguration -ComputerName $computers -Wait -Verbose -UseExisting -Force

# Check the status again
Test-DscConfiguration -ComputerName $computers -Detailed 

#endregion Remediate