﻿#Requires -Version 5.1

using namespace System.Security.Cryptography.X509Certificates

[string[]] $publishedModules = @(
    'xTimeZone',
    'NetworkingDsc'
)

[string[]] $requiredModules = $publishedModules + @(
    'xWebAdministration',
    'xPSDesiredStateConfiguration'
)

[string[]] $installedModules =
    Get-Module -ListAvailable -Name $requiredModules | 
    Sort-Object -Property Name -Unique |
    Select-Object -ExpandProperty Name

if($requiredModules.Count -gt $installedModules.Count) {
    # Install any missing modules
    Install-PackageProvider -Name NuGet -Scope AllUsers -Force
    Install-Module -Name $requiredModules -Scope AllUsers -Force
}

[string] $serviceRoot = "$env:SystemDrive\inetpub\PSDSCPullServer"

# DSC Pull Service Configuration
Configuration WebRepository
{
    param  
    ( 
        [Parameter(Mandatory = $true)]
        [string] $CertificateThumbPrint,

        [Parameter(Mandatory = $true)]
        [string] $RegistrationKey,

        [Parameter(Mandatory = $false)]
        [uint16] $HttpsPort = 443,

        [Parameter(Mandatory = $true)]
        [string] $ServiceRoot
    )

    Import-DscResource –ModuleName PSDesiredStateConfiguration
    Import-DSCResource -ModuleName xPSDesiredStateConfiguration 
    Import-DscResource -ModuleName xWebAdministration
    Import-DscResource -ModuleName NetworkingDsc

    Node localhost
    {
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyAndAutoCorrect'
            ConfigurationModeFrequencyMins = 30
            RebootNodeifNeeded = $true
            ActionAfterReboot = 'ContinueConfiguration'
        }
        
        WindowsFeature DSCServiceFeature 
        { 
            Ensure = 'Present'
            Name   = 'DSC-Service'
        }

        WindowsFeature IISManagementConsole
        { 
            Ensure = 'Present'
            Name   = 'Web-Mgmt-Console'
        }

        xWebsite RemoveDefaultWebSite
        {
            DependsOn = '[WindowsFeature]DSCServiceFeature'
            Name = 'Default Web Site'
            Ensure = 'Absent'
        }

        xWebAppPool DSCApplicationPool
        {
            Name = 'PSWS'
            DependsOn =  '[WindowsFeature]DSCServiceFeature'  
            Ensure = 'Present'
            State = 'Started'         
            startMode = 'OnDemand'
            managedPipelineMode = 'Integrated'
            identityType = 'LocalSystem'
            loadUserProfile = $false
            enable32BitAppOnWin64 = $false
            managedRuntimeVersion = 'v4.0'
        }

        xDscWebService PSDSCPullServer 
        {
            DependsOn                    = '[xWebAppPool]DSCApplicationPool'
            Ensure                       = 'Present' 
            EndpointName                 = 'DSCPullServer' 
            Port                         = $HttpsPort
            PhysicalPath                 = $ServiceRoot
            CertificateThumbPrint        = $CertificateThumbPrint
            AcceptSelfSignedCertificates = $false
            State                        = 'Started'
            UseSecurityBestPractices     = $true
            ConfigureFirewall            = $false
            ApplicationPoolName          = 'PSWS'
        } 

        File RegistrationKeyFile
        {
            DependsOn       = '[WindowsFeature]DSCServiceFeature'
            Ensure          = 'Present'
            Type            = 'File'
            DestinationPath = "$env:ProgramFiles\WindowsPowerShell\DscService\RegistrationKeys.txt"
            Contents        = $RegistrationKey
        }

        Firewall HttpsFirewallRule
        {
            Name = 'DSCPullServer-HTTPS-In-TCP'
            Ensure = 'Present'
            DisplayName = 'DSC Pull Server (HTTPS Traffic-In)'
            Protocol = 'TCP'
            LocalPort = $HttpsPort
            Program = 'System'
            Enabled = 'True'
            Action = 'Allow'
            Profile = 'Public', 'Private', 'Domain'
            Direction = 'Inbound'
        }

        Registry TLS1_2ServerEnabled
        {
            Ensure = 'Present'
            Key = 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server'
            ValueName = 'Enabled'
            ValueData = 1
            ValueType = 'Dword'
        }

        Registry TLS1_2ServerDisabledByDefault
        {
            Ensure = 'Present'
            Key = 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server'
            ValueName = 'DisabledByDefault'
            ValueData = 0
            ValueType = 'Dword'
        }

        Registry TLS1_2ClientEnabled
        {
            Ensure = 'Present'
            Key = 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client'
            ValueName = 'Enabled'
            ValueData = 1
            ValueType = 'Dword'
        }

        Registry TLS1_2ClientDisabledByDefault
        {
            Ensure = 'Present'
            Key = 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client'
            ValueName = 'DisabledByDefault'
            ValueData = 0
            ValueType = 'Dword'
        }

        Registry SSL2ServerDisabled
        {
            Ensure = 'Present'
            Key = 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server'
            ValueName = 'Enabled'
            ValueData = 0
            ValueType = 'Dword'
        }
    }
}

# Enroll certificate from CA
Get-Certificate -Template WebServer -DnsName (.\Get-ComputerFQDN.ps1) -CertStoreLocation Cert:\LocalMachine\My

# Generate Pull Server MOF
[X509Certificate2] $cert = Get-ChildItem -Path Cert:\LocalMachine\My -SSLServerAuthentication |
    Sort-Object -Property NotBefore -Descending |
    Select-Object -First 1

[string] $registrationKey = Get-Content -Path .\RegistrationKey.txt

WebRepository -ServiceRoot $serviceRoot `
              -CertificateThumbPrint $cert.Thumbprint `
              -RegistrationKey $registrationKey `
              -OutputPath .\MOFServers

# Apply configuration
Start-DscConfiguration -Path .\MOFServers -Wait -Verbose -Force

# Copy modules to the repository
Get-Module -Name $publishedModules -ListAvailable |
    Publish-ModuleToPullServer -PullServerWebConfig "$serviceRoot\web.config"

# Copy MOFs to the repository
Get-ChildItem -Path .\MOFClients -File -Filter *.mof |
    Where-Object Name -NotLike *.meta.mof |
    Publish-MofToPullServer -PullServerWebConfig "$serviceRoot\web.config"
