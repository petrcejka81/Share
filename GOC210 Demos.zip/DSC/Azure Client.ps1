[DscLocalConfigurationManager()]
Configuration DscMetaConfigs
{
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $RegistrationUrl,

        [Parameter(Mandatory = $true)]
        [string] $RegistrationKey,

        [Parameter(Mandatory = $true)]
        [string[]] $ComputerName
    )

    Node $ComputerName
    {
        Settings
        {
            RefreshFrequencyMins           = 30
            RefreshMode                    = 'Pull'
            ConfigurationMode              = 'ApplyAndAutoCorrect'
            AllowModuleOverwrite           = $true
            RebootNodeIfNeeded             = $true
            ActionAfterReboot              = 'ContinueConfiguration'
            ConfigurationModeFrequencyMins = 15
        }

        ConfigurationRepositoryWeb AzureAutomationStateConfiguration
        {
            ServerUrl          = $RegistrationUrl
            RegistrationKey    = $RegistrationKey
        }

        ResourceRepositoryWeb AzureAutomationStateConfiguration
        {
            ServerUrl       = $RegistrationUrl
            RegistrationKey = $RegistrationKey
        }

        ReportServerWeb AzureAutomationStateConfiguration
        {
            ServerUrl       = $RegistrationUrl
            RegistrationKey = $RegistrationKey
        }
    }
}

# Create the metaconfigurations
[string[]] $computers = @('GOC210-SRV2', 'GOC210-SRV3','GOC210-SRV4')
DscMetaConfigs -RegistrationUrl 'https://XXXXXXXX.azure-automation.net/accounts/XXXXXX' `
               -RegistrationKey 'XXXXXX' `
               -ComputerName $computers

# Deploy LCM MOFs
Set-DscLocalConfigurationManager -Path .\DscMetaConfigs -Verbose -Force

# Force config update and apply
Update-DscConfiguration -ComputerName $computers -Wait -Verbose

# Reapply config
Start-DscConfiguration -ComputerName $computers -UseExisting -Wait -Verbose
