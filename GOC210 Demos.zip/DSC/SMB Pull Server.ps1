﻿#Requires -Version 5.1

[string[]] $publishedModules = @(
    'xTimeZone',
    'NetworkingDsc'
)

[string[]] $requiredModules = $publishedModules + @(
    'xSmbShare',
    'cNtfsAccessControl',
    'xPSDesiredStateConfiguration'
)

[string[]] $installedModules =
    Get-Module -ListAvailable -Name $requiredModules | 
    Sort-Object -Property Name -Unique |
    Select-Object -ExpandProperty Name

if($requiredModules.Count -gt $installedModules.Count) {
    # Install any missing modules
    Install-PackageProvider -Name NuGet -Scope AllUsers -Force
    Install-Module -Name $requiredModules -Scope AllUsers -Force
}

Configuration SMBRepository
{
    param  
    (
        [ValidateNotNullOrEmpty()]
        [string[]] $NodeName = 'localhost', 

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()] 
        [string] $RepositoryPath,

        [ValidateNotNullOrEmpty()] 
        [string] $NodesGroup = 'CONTOSO\Domain Computers'
    )

    Import-DscResource –ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xSMBShare
    Import-DscResource -ModuleName cNtfsAccessControl
    Import-DscResource -ModuleName NetworkingDsc

    Node $NodeName
    {
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyAndAutoCorrect'
            ConfigurationModeFrequencyMins = 30
            RebootNodeifNeeded = $true
            ActionAfterReboot = 'ContinueConfiguration'
        }

        File DSCDirectory
        {
            Type = 'Directory'
            DestinationPath = $RepositoryPath
            Ensure = 'Present'
        }

        File ModulesDirectory
        {
            Type = 'Directory'
            DependsOn = '[File]DSCDirectory'
            DestinationPath = Join-Path -Path $RepositoryPath -ChildPath Modules
            Ensure = 'Present'
        }

        File ConfigurationDirectory
        {
            Type = 'Directory'
            DependsOn = '[File]DSCDirectory'
            DestinationPath =  Join-Path -Path $RepositoryPath -ChildPath Configuration
            Ensure = 'Present'
        }

        xSMBShare DSCShare
        {
            DependsOn = '[File]DSCDirectory'
            Name = 'DSCRepository'
            Path = $RepositoryPath
            FullAccess = 'Everyone'
            Ensure = 'Present'
        }

        cNtfsPermissionEntry DSCDirectoryACE1
        {
            DependsOn = '[File]DSCDirectory'
            Ensure = 'Present'
            Path = $RepositoryPath
            Principal = $NodesGroup
            AccessControlInformation = cNtfsAccessControlInformation {
                AccessControlType = 'Allow'
                FileSystemRights = 'ReadAndExecute'
                Inheritance = 'ThisFolderSubfoldersAndFiles'
                NoPropagateInherit = $false
            }
        }

        cNtfsPermissionEntry DSCDirectoryACE2
        {
            DependsOn = '[File]DSCDirectory'
            Ensure = 'Present'
            Path = $RepositoryPath
            Principal = 'SYSTEM'
            AccessControlInformation = cNtfsAccessControlInformation {
                AccessControlType = 'Allow'
                FileSystemRights = 'FullControl'
                Inheritance = 'ThisFolderSubfoldersAndFiles'
                NoPropagateInherit = $false
            }
        }

        cNtfsPermissionEntry DSCDirectoryACE3
        {
            DependsOn = '[File]DSCDirectory'
            Ensure = 'Present'
            Path = $RepositoryPath
            Principal = 'Administrators'
            AccessControlInformation = cNtfsAccessControlInformation {
                AccessControlType = 'Allow'
                FileSystemRights = 'FullControl'
                Inheritance = 'ThisFolderSubfoldersAndFiles'
                NoPropagateInherit = $false
            }
        }

        cNtfsPermissionsInheritance DSCDirectoryInheritance
        {
            DependsOn = '[cNtfsPermissionEntry]DSCDirectoryACE1',
                        '[cNtfsPermissionEntry]DSCDirectoryACE2',
                        '[cNtfsPermissionEntry]DSCDirectoryACE3'
            Enabled = $false
            Path = $RepositoryPath
            PreserveInherited = $false
        }

        Firewall SMBFirewallRule
        {
            Name = 'DSCShare-SMB-In-TCP'
            Ensure = 'Present'
            DisplayName = 'DSC Pull Server (SMB Traffic-In)'
            Protocol = 'TCP'
            LocalPort = 445
            Program = 'System'
            Enabled = 'True'
            Action = 'Allow'
            Profile = 'Public', 'Private', 'Domain'
            Direction = 'Inbound'
        }
    }
}

# Generate SMB Pull Server MOF
[string] $repositoryBase = (Select-Xml -Path .\SMB.config -XPath '/configuration/appSettings/add[@key="RootPath"]/@value').Node.Value
SMBRepository -RepositoryPath $repositoryBase -OutputPath .\MOFServers

# Apply configuration
Start-DscConfiguration -Path .\MOFServers -Wait -Verbose -Force

# Copy modules to the repository
Get-Module -Name $publishedModules -ListAvailable |
    Publish-ModuleToPullServer -PullServerWebConfig .\SMB.config

# Copy MOFs to the repository
Get-ChildItem -Path .\MOFClients -File -Filter *.mof |
    Where-Object Name -NotLike *.meta.mof |
    Publish-MofToPullServer -PullServerWebConfig .\SMB.config

# Rename MOFs to Node GUIDs
[string] $configDirectory = (Select-Xml -Path .\SMB.config -XPath '/configuration/appSettings/add[@key="ConfigurationPath"]/@value').Node.Value
[hashtable[]] $nodes = (Import-PowerShellDataFile -Path .\Computers.psd1).AllNodes

Push-Location -Path $configDirectory
foreach($node in $nodes)
{
    Move-Item -Path ($node.NodeName + '.mof') -Destination ($node.Guid + '.mof') -Force -Verbose -ErrorAction SilentlyContinue
    Move-Item -Path ($node.NodeName + '.mof.checksum') -Destination ($node.Guid + '.mof.checksum') -Force -Verbose -ErrorAction SilentlyContinue
    Move-Item -Path ($node.NodeName + '.meta.mof') -Destination ($node.Guid + '.meta.mof') -Force -Verbose -ErrorAction SilentlyContinue
    Move-Item -Path ($node.NodeName + '.meta.mof.checksum') -Destination ($node.Guid + '.meta.mof.checksum') -Force -Verbose -ErrorAction SilentlyContinue
}
Pop-Location