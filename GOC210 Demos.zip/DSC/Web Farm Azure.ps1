Configuration WebFarm
{
    param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string] $Text
    )

    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xTimeZone

    Node WebNode
    {
        WindowsFeature IIS
        {
            Ensure = 'Present'
            Name = 'Web-Server'
        }
        
        File HomePage
        {
            DependsOn = '[WindowsFeature]IIS'
            Ensure = 'Present'
            Type = 'File'
            DestinationPath = 'C:\inetpub\wwwroot\index.html'
            Contents = "<h1>$Text</h1>"
        }

        xTimeZone TimeZone
        {
            TimeZone = 'Central Europe Standard Time'
            IsSingleInstance = 'Yes'
        }
    }
}