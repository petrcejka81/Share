[DscLocalConfigurationManager()]
Configuration PushClient
{
    Node $AllNodes.NodeName
    {
        Settings
        {
            RefreshMode = 'Push'
            ConfigurationMode = 'ApplyAndAutoCorrect'
            ConfigurationModeFrequencyMins = 15
            RebootNodeIfNeeded = $true
            ActionAfterReboot = 'ContinueConfiguration'
        }
    }
}

# Prepare LCM MOFs
PushClient -ConfigurationData .\Computers.psd1 -OutputPath .\MOFClients

# Deploy LCM MOFs
Set-DscLocalConfigurationManager -Path .\MOFClients

# Install Modules
$config = Import-PowerShellDataFile -Path .\Computers.psd1
Invoke-Command -ComputerName $config.AllNodes.NodeName -ScriptBlock {
    Install-PackageProvider -Name NuGet -Scope AllUsers -Force
    Install-Module -Name xTimeZone,NetworkingDsc -Scope AllUsers -Force
}

# Push MOFs to target nodes
Start-DscConfiguration -Path .\MOFClients -Wait -Force -Verbose

# Check the state
Test-DscConfiguration -Path .\MOFClients