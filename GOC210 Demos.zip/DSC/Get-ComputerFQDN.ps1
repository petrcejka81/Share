[OutputType([string])]
param(
    [Parameter(ValueFromPipeline = $true)]
    [ValidateNotNullOrEmpty()]
    [string] $ComputerName = 'localhost'
)

$computer = Get-WmiObject -Class Win32_ComputerSystem -Property DnsHostName,Domain -ComputerName $ComputerName -ErrorAction Stop
return '{0}.{1}' -f $computer.DnsHostName, $computer.Domain