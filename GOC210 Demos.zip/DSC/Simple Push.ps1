Configuration FileServer
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node localhost
    {
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyAndAutoCorrect'
            ConfigurationModeFrequencyMins = 30
        }

        WindowsFeatureSet FileServerFeatures
        {
            Ensure = 'Present'
            Name = 'FS-FileServer', 'FS-Data-Deduplication'
        }

        WindowsFeature DisableSMB1
        {
            Ensure = 'Absent'
            Name = 'FS-SMB1'
        }

        Registry DisableShortNameCreation
        {
            Ensure = 'Present'
            Key = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\FileSystem'
            ValueName = 'NtfsDisable8dot3NameCreation'
            ValueData = 1
            ValueType = 'Dword'
            Force = $true
        }
    }
}

# Generate MOF
FileServer

# Push MOF
Start-DscConfiguration -Path .\FileServer -Wait -Verbose -Force

Test-DscConfiguration -Detailed