# Operational logs
Get-WinEvent -LogName 'Microsoft-Windows-Dsc/Operational'

# Analytic and debug logs (must be enabled first)
wevtutil.exe set-log "Microsoft-Windows-Dsc/Analytic" /q:true /e:true

# Group by JobId
$dscLogs = @('Microsoft-Windows-Dsc/Analytic',
             'Microsoft-Windows-Dsc/Debug',
             'Microsoft-Windows-Dsc/Operational')

$eventsByJob = Get-WinEvent -LogName $dscLogs -Oldest | Group-Object -Property { $PSItem.Properties[0].Value }
$eventsByJob[1].Group
$eventsByJob[1].Group.Message
$eventsByJob | Where-Object { $PSItem.Group.LevelDisplayName -contains 'Error' }


# A better solution
Install-Module -Name xDscDiagnostics -Scope AllUsers -Force

Update-xDscEventLogStatus -Channel Operational -Status Enabled
Update-xDscEventLogStatus -Channel Analytic -Status Enabled
Update-xDscEventLogStatus -Channel Debug -Status Enabled

Get-xDscOperation
Get-DscConfigurationStatus | Get-xDscConfigurationDetail

# Trace-xDscOperation -SequenceID 2