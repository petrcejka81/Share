<#
.SYNOPSIS
Gopas GOC210 Demo Code

.AUTHOR
Michael Grafnetter

.VERSION
1.0

#>

#Requires -ShellId 'DO_NOT_RUN_THE_ENTIRE_SCRIPT!!!'

#region PowerShell 101

# Cmdlets
Get-Process

# Parameters
Start-Process -FilePath notepad
Get-Process -Name notepad

# Switches
Start-Process -FilePath notepad -Wait

# Quotes

# Multiple Values

# Parameter Sets

# Help System

#endregion PowerShell 101

#region PowerShell Pipeline

# Console Output
Get-Process | Out-Host -Paging

#endregion PowerShell Pipeline

