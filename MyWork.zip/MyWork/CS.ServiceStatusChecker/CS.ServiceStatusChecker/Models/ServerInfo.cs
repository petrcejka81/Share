﻿namespace CS.ServiceStatusChecker.Models
{
    // ServerInfo.cs
    using System;

    public class ServerInfo
    {
        public static string GetServerName()
        {
            return Environment.MachineName;
        }
    }
}
