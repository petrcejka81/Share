﻿namespace CS.ServiceStatusChecker.Models
{
    using System.ServiceProcess;
    public class ServiceStatusCheck    
    {
        /// <summary>
        /// Checks if a Windows service is running.
        /// </summary>
        /// <param name="serviceName">The service name (not display name).</param>
        /// <returns>True if running, false otherwise.</returns>
        public static bool IsServiceRunning(string serviceName)
        {
            try
            {
                using var sc = new ServiceController(serviceName);
                return sc.Status == ServiceControllerStatus.Running;
            }
            catch
            {
                // Service not found or error occurred
                return false;
            }
        }
    }
}
