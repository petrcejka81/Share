﻿namespace CS.ServiceStatusChecker
{
    public class AppSettings
    {
        public string WindowsServiceName { get; set; }
    }
}
