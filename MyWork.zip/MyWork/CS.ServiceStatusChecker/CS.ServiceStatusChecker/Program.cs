using CS.ServiceStatusChecker;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
builder.Services.Configure<AppSettings>(builder.Configuration.GetSection("AppSettings"));

var app = builder.Build();
app.MapControllerRoute(
        name: "default",
        pattern: "{action=Index}",
        defaults: new { controller = "Home" });
app.Run();
