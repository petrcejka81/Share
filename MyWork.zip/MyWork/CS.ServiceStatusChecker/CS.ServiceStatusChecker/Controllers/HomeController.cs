﻿using Microsoft.AspNetCore.Mvc;
using CS.ServiceStatusChecker.Models;
using Microsoft.Extensions.Options;

namespace CS.ServiceStatusChecker.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppSettings _appSettings;
        public HomeController(IOptions<AppSettings> appSettings)
        {
            _appSettings = appSettings.Value;
        }

        public IActionResult Index()
        {
            ViewBag.SericeName = _appSettings.WindowsServiceName;
            ViewBag.ServiceStatus = ServiceStatusCheck.IsServiceRunning(ViewBag.SericeName);
            return View();
        }
        public IActionResult WhoAmI()
        {
            ViewBag.ServiceName = _appSettings.WindowsServiceName;
            ViewBag.ServerName = ServerInfo.GetServerName();
            ViewBag.ServiceStatus = ServiceStatusCheck.IsServiceRunning(ViewBag.ServiceName);
            return View();
        }

    }
}
