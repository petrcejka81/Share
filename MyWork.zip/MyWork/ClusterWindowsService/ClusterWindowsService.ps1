
<#PSScriptInfo

.VERSION 1.0.0.4

.GUID 685d6d73-a83d-4ba6-afd4-d0185b131725

.AUTHOR petr_cejka@kb.cz; a5320net@ds.kb.cz

.COMPANYNAME KB, a.s. - .NET MWS Team

.COPYRIGHT

.TAGS

.LICENSEURI

.PROJECTURI

.ICONURI

.EXTERNALMODULEDEPENDENCIES 

.REQUIREDSCRIPTS

.EXTERNALSCRIPTDEPENDENCIES

.RELEASENOTES

.PRIVATEDATA

#>
#Requires -PSEdition Core 
<# 
.DESCRIPTION 
 The script is used to manage Windows services in a cluster environment 
#> 

Param(
    # Config File Name
    [ValidateNotNull()]
    [ValidateNotNullOrEmpty()]
    [ValidateScript({Test-Path -Path "$(Join-Path -Path $PSScriptRoot -ChildPath $ConfigFileName)"})]
    [string]$ConfigFileName = "Config.json"
)
#Main
function Main()
{
    try 
    {
        #Varibles
        [string]$UriLocal = "https://{0}:{1}/" -f $NodeLocal_DNSName, $port
        [string]$UriRemote = "https://{0}:{1}/" -f $NodeRemote_DNSName, $port
        [bool]$WindowsServiceRemote = $false
        [bool]$WindowsServiceLocal = $false 
        [byte]$Quorum = 0
        [string]$localHostName = (Get-CimInstance -ClassName "Win32_ComputerSystem").Name
        #Main
        $log.WriteLog("Minimum quorum is 2", [Severity]::Information)
        $log.WriteLog("Quorum:$Quorum Minimum Quorum is $(if($Quorum -eq 2) {"achieved"} else {"not achieved"})", [Severity]::Information)
        if(Test-Path -Path $FileShareWitness)
        {
            New-Item -Path $FileShareWitness -ItemType File -Name "$([datetime]::now.ToString("yyyy_MM_dd-mm-ss"))_$localHostName" -Value "$([datetime]::now.ToString("yyyy_MM_dd-mm-ss"))_TEST" -Force | ForEach-Object {
                $log.WriteLog("File: $($PSItem.FullName) has been created.", [Severity]::Information)
                Remove-Item -Path $PSItem.FullName -Force
                $log.WriteLog("File: $($PSItem.FullName) has been removed.", [Severity]::Information)
            }
            $Quorum++
            $log.WriteLog("File share witness is available.", [Severity]::Information)
            $log.WriteLog("Quorum:$Quorum Minimum Quorum is $(if($Quorum -ge 2) {"achieved"} else {"not achieved"})")
        }
        try 
        {
            [Bool]::TryParse(((Invoke-WebRequest -uri $UriLocal -SkipCertificateCheck -TimeoutSec $Timeoutsec).Content),[ref]$WindowsServiceLocal)
            if($WindowsServiceLocal)
            {
                $log.WriteLog("Local Windows service: $WindowsServiceName status: Running", [Severity]::Information)
                $Quorum++
                $log.WriteLog("Quorum:$Quorum Minimum Quorum is $(if($Quorum -ge 2) {"achieved"} else {"not achieved"})", [Severity]::Information)  
            }
            else
            {
                $log.WriteLog("Local Windows service: $WindowsServiceName status: Stopped", [Severity]::Warning)
                $Quorum++
                $log.WriteLog("Quorum:$Quorum Minimum Quorum is $(if($Quorum -ge 2) {"achieved"} else {"not achieved"})", [Severity]::Information)
            }
        }
        catch 
        {
            $log.WriteLog("Local Windows service: An error occurred: $PSItem", [Severity]::Warning)
        }
        try 
        {
            if((Test-NetConnection -ComputerName $NodeRemote_DNSName).PingSucceeded)
            {
                [Bool]::TryParse(((Invoke-WebRequest -uri $UriRemote -SkipCertificateCheck -TimeoutSec $Timeoutsec).Content),[ref]$WindowsServiceRemote)
                if($WindowsServiceRemote)
                {
                    $Quorum++
                    $log.WriteLog("Quorum:$Quorum Minimum Quorum is $(if($Quorum -ge 2) {"achieved"} else {"not achieved"})", [Severity]::Information)
                    $log.WriteLog("Remote Windows service: $WindowsServiceName status: Running", [Severity]::Information)
                }
                else 
                {
                    $Quorum++
                    $log.WriteLog("Quorum:$Quorum Minimum Quorum is $(if($Quorum -ge 2) {"achieved"} else {"not achieved"})", [Severity]::Information)
                    $log.WriteLog("Remote Windows service: $WindowsServiceName status: Stopped", [Severity]::Warning)
                }
            }
            else
            {
                $log.WriteLog("Remote Windows service: $WindowsServiceName is not reachable.", [Severity]::Warning)
            }
        }
        catch 
        {
            $log.WriteLog("Remote Windows service: An error occurred: $PSItem", [Severity]::Warning)
        }

        if($Quorum -ge 2 -and !$WindowsServiceRemote -and !$WindowsServiceLocal)
        {
            $log.WriteLog("Quorum:$Quorum Minimum Quorum is $(if($Quorum -ge 2) {"achieved"} else {"not achieved"})", [Severity]::Information)
            Get-Service -Name $WindowsServiceName | Start-Service
            $log.WriteLog("Windows service: $WindowsServiceName has been started.", [Severity]::Information)
        }
        elseif($Quorum -lt 2 -and $WindowsServiceLocal) 
        {
            $log.WriteLog("Quorum:$Quorum Minimum Quorum is $(if($Quorum -ge 2) {"achieved"} else {"not achieved"})", [Severity]::Information)
            Get-Service -Name $WindowsServiceName | Stop-Service
            $log.WriteLog("Windows service: $WindowsServiceName has been stopped.", [Severity]::Information)
        }
        elseif($Quorum -ge 2 -and $WindowsServiceRemote -and $WindowsServiceLocal)
        {
            
            $log.WriteLog("Quorum:$Quorum Minimum Quorum is $(if($Quorum -ge 2) {"achieved"} else {"not achieved"})", [Severity]::Information)
            Get-Service -Name $WindowsServiceName | Stop-Service
            $log.WriteLog("Windows service: $WindowsServiceName has been stopped.", [Severity]::Information)
            $log.WriteLog("Windows service: Split-brain scenario detected.", [Severity]::Warning)
        }
        else 
        {
            $log.WriteLog("Quorum:$Quorum Minimum Quorum is $(if($Quorum -ge 2) {"achieved"} else {"not achieved"})", [Severity]::Information)
            $log.WriteLog("Windows service: $WindowsServiceName has not been started.", [Severity]::Information)
        }
    }
    catch 
    {
        $log.WriteLog("An error occurred: $PSItem", [Severity]::Error)
    }
}
#Global Config
$ErrorActionPreference = "Stop"
#InputConfigVariables
try {
    [string]$ConfigFilePath =Join-Path -Path $PSScriptRoot -ChildPath $ConfigFileName
    $config = Get-Content -Path $ConfigFilePath | ConvertFrom-Json
    # Log folder name
    [string]$logFolderRootPath = $config.param.LogFolderRootPath
    # Log File name
    [string]$logFileName = $config.param.LogFileName
    # Local Node name
    [string]$NodeLocal_DNSName = $config.param.NodeLocal_DNSName
    # Remote Node FQDN
    [string]$NodeRemote_DNSName = $config.param.NodeRemote_DNSName
    # Remote Node Port
    [Int16]$port = $config.param.port
    [Int16]$Timeoutsec = $config.param.Timeoutsec
    # Windows Service name
    [string]$WindowsServiceName = $config.param.WindowsServiceName
    # UNC Path to share witness
    [string]$FileShareWitness = $config.param.FileShareWitness
}
catch 
{
    throw "An error occurred while loading configuration variables: $PSItem"
}

#MyLogclass
try 
{
    Enum Severity
    {
        Error
        Information
        Warning
    }
    class Log 
    {
        [string]$logFolderPath
        [string]$logFileName
        Log([string]$logFolderPath,[string]$logFileName)
        {
            $this.logFileName = $logFileName
            $this.logFolderPath = $logFolderPath
            try
            {
                if(!(Test-Path -Path $this.logFolderPath))
                {
                    New-item -Path $this.logFolderPath -ItemType Directory
                }
                if(!(Test-Path -Path (Join-Path -Path $($this.logFolderPath) -ChildPath "$([datetime]::now.ToString("yyyy_MM_dd"))_$($this.LogFilename)")))
                {
                    New-Item -Path (Join-Path -Path $($this.logFolderPath) -ChildPath "$([datetime]::now.ToString("yyyy_MM_dd"))_$($this.LogFilename)") -ItemType File
                } 
            }
            catch
            {
                Throw "An error occurred while initializing the log class: $PSItem"
            }
        }
        WriteLog([String]$message,[severity]$severity)
        {
            Add-Content -Path "$($this.logFolderPath)\$([datetime]::now.ToString("yyyy_MM_dd"))_$($this.LogFilename)" -Value ([string]::Format("{0};[{1}];[{2}];{3}",[datetime]::Now.ToString("dd.MM.yyyy HH:mm:ss"), [System.Security.Principal.WindowsIdentity]::GetCurrent().Name,$severity,$message))
            switch ($severity) {
                "error" {Write-Error "$([string]::Format("{0};[{1}];[{2}];{3}",[datetime]::Now.ToString("dd.MM.yyyy HH:mm:ss"), [System.Security.Principal.WindowsIdentity]::GetCurrent().Name,$severity,$message))"}
                "warning" {Write-Warning "$([string]::Format("{0};[{1}];[{2}];{3}",[datetime]::Now.ToString("dd.MM.yyyy HH:mm:ss"), [System.Security.Principal.WindowsIdentity]::GetCurrent().Name,$severity,$message))"}
                Default {[System.Console]::WriteLine("$([string]::Format("{0};[{1}];[{2}];{3}",[datetime]::Now.ToString("dd.MM.yyyy HH:mm:ss"), [System.Security.Principal.WindowsIdentity]::GetCurrent().Name,$severity,$message))")}
            }
        }
        WriteLog([String]$message)
        {
            Add-Content -Path "$($this.logFolderPath)\$([datetime]::now.ToString("yyyy_MM_dd"))_$($this.LogFilename)" -Value $message
            [System.Console]::WriteLine("$message")
        }
        WriteLog([String]$message,[severity]$severity,[string]$server)
        {
            Add-Content -Path "$($this.logFolderPath)\$([datetime]::now.ToString("yyyy_MM_dd"))_$($this.LogFilename)" -Value ([string]::Format("{0};[{1}];[{2}];{4};{3}",[datetime]::Now.ToString("dd.MM.yyyy HH:mm:ss"), [System.Security.Principal.WindowsIdentity]::GetCurrent().Name,$severity,$message,$server))
            switch ($severity) {
                "error" {Write-Error "$([string]::Format("{0};[{1}];[{2}];{4};{3}",[datetime]::Now.ToString("dd.MM.yyyy HH:mm:ss"), [System.Security.Principal.WindowsIdentity]::GetCurrent().Name,$severity,$message,$server))" }
                "warning" {Write-Warning "$([string]::Format("{0};[{1}];[{2}];{4};{3}",[datetime]::Now.ToString("dd.MM.yyyy HH:mm:ss"), [System.Security.Principal.WindowsIdentity]::GetCurrent().Name,$severity,$message,$server))"}
                Default {[System.Console]::WriteLine("$([string]::Format("{0};[{1}];[{2}];{4};{3}",[datetime]::Now.ToString("dd.MM.yyyy HH:mm:ss"), [System.Security.Principal.WindowsIdentity]::GetCurrent().Name,$severity,$message,$server))")}
            }
        }
    }
    $log = [log]::new($logFolderRootPath,$LogFileName)
    $log.WriteLog("Start processing ClusterWindowsService scipt!",[severity]::Information) 
    $log.WriteLog("Loging class instance LOG was set successfully!",[severity]::Information) 
}
catch 
{
    throw "An error occurred while processing the script: $PSItem"
}
# Main Function
try 
{
    main
}
catch 
{
    $log.WriteLog("An error occurred: $PSItem", [Severity]::Error)
}